# ANALISTA TÁTICO PRO — v2.0.0

Estúdio de análise tática de Free Fire. É uma PWA instalável (Android, iPhone, tablet e PC) que funciona offline. Opcionalmente, sincroniza com o Firebase.

## Arquivos
| Arquivo | Função |
|---|---|
| `index.html`, `css/app.css`, `js/app.js` | Aplicativo |
| `standalone.html` | Versão em arquivo único, sem nuvem configurada |
| `firebase-config.js` | Configuração **pública** do app Web do Firebase. Preencha antes de publicar |
| `manifest.json`, `service-worker.js`, `sw.js`, `icons/` | PWA. O `sw.js` mantém a compatibilidade com quem instalou a v1 |
| `firestore.rules`, `storage.rules`, `firebase.json`, `firestore.indexes.json` | Regras de segurança e deploy |
| `cors.json` | CORS do bucket, para baixar imagens sincronizadas no navegador |
| `testes/` | Testes automatizados executados (Playwright) e a nuvem simulada |

## Atualizar da v1
Substitua os arquivos no GitHub Pages. Os dados locais (projetos, mapas, gravações) são preservados: o banco local é atualizado da versão 1 para a 2 sem apagar nada.

## Configurar o Firebase (opcional: login, sincronização e links públicos)
1. Em console.firebase.google.com, crie um projeto e adicione um **app Web**.
2. Em **Authentication**, ative os métodos E-mail/senha e Google. Em *Authorized domains*, adicione `SEU-USUARIO.github.io`.
3. Crie o **Firestore Database** (modo produção) e ative o **Storage**.
4. Publique as regras com a Firebase CLI: `npm i -g firebase-tools`, `firebase login`, `firebase use SEU-PROJETO` e depois `firebase deploy --only firestore:rules,storage`.
   Se preferir, cole o conteúdo de `firestore.rules` e de `storage.rules` nos editores de regras do console.
5. CORS do Storage (necessário para baixar as imagens de mapas sincronizadas): edite `cors.json` com o seu domínio e rode `gsutil cors set cors.json gs://SEU-BUCKET`.
6. Copie o `firebaseConfig` do app Web para o `firebase-config.js` e publique o site.
7. No app, vá em **Configurações → Conta e nuvem**, crie a conta, entre e confirme **Ativar sincronização**. Esse passo envia os dados locais sem apagar nada.

A `apiKey` do Firebase não é um segredo. Quem protege os dados são as regras. **Nunca** coloque no site chaves de conta de serviço ou credenciais administrativas.

## Instalar e gerar o APK
- Android: Chrome → ⋮ → "Instalar app". No iPhone: Compartilhar → "Adicionar à Tela de Início".
- APK: www.pwabuilder.com, informando a URL publicada, ou Capacitor (`www/` = todos os arquivos deste pacote).

## Limitações conhecidas
- **Mapas oficiais:** as imagens não estão incluídas, porque não há arquivo com licença de uso. Importe as imagens de uma fonte autorizada. Elas ficam offline e entram no histórico de versões.
- **Personagens e armas:** os nomes já vêm cadastrados, mas efeitos e estatísticas são preenchidos pelo analista, com a versão do jogo indicada. Nenhum dado de jogo é inventado.
- **Áudio interno do jogo:** não é capturado no celular. No computador, só é gravado se o navegador oferecer "compartilhar áudio" na captura de tela (MODE_07).
- **Celular em segundo plano:** o app pausa a gravação, porque o celular congela a aba.
- **Exportação no editor:** é em tempo real.
- **PDF:** é gerado pelo diálogo de impressão do navegador.
- **Vídeos:** não são sincronizados automaticamente. Só são enviados quando você os anexa a um link público.
