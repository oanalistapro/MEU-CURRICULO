// Adaptador de testes: mesma interface do FirebaseBackend, falando com mockcloud.py (NÃO é o Firebase real)
window.__ATP_BACKEND = (() => {
  const B = 'http://127.0.0.1:8790'; let user = null; const subs = [];
  const err = async r => { const j = await r.json().catch(() => ({})); const e = new Error(j.message || j.code || ('HTTP ' + r.status)); e.code = j.code; return e; };
  const call = async (method, path, body, raw) => {
    const r = await fetch(B + path, { method, headers: { 'X-Uid': user?.uid || '', ...(raw ? { 'Content-Type': raw.type || 'application/octet-stream' } : { 'Content-Type': 'application/json' }) }, body: raw || (body ? JSON.stringify(body) : undefined) });
    if (!r.ok) throw await err(r); return r;
  };
  const setUser = u => { user = u; try { u ? localStorage.setItem('mockUser', JSON.stringify(u)) : localStorage.removeItem('mockUser'); } catch { } subs.forEach(f => f(u)); };
  return {
    name: 'mock',
    async init() { try { user = JSON.parse(localStorage.getItem('mockUser')); } catch { } },
    hasStorage() { return true; },
    onAuth(cb) { subs.push(cb); setTimeout(() => cb(user), 0); return () => { }; },
    async signIn(email, pw) { setUser(await (await call('POST', '/auth/signin', { email, pw })).json()); },
    async signUp(email, pw) { setUser(await (await call('POST', '/auth/signup', { email, pw })).json()); },
    async google() { throw Object.assign(new Error('não disponível no simulador'), { code: 'auth/operation-not-allowed' }); },
    async signOut() { setUser(null); },
    async reset() { },
    async tx(uid, key, payload, expected) { return (await call('POST', '/tx', { uid, key, payload, expected })).json(); },
    async since(uid, t) { return (await call('GET', `/since?uid=${uid}&t=${t}`)).json(); },
    watch(uid, t, cb, onErr) {
      let last = t, stop = false;
      const tick = async () => { if (stop) return; try { const d = await this.since(uid, last); if (d.length) { last = Math.max(...d.map(x => x.serverTime)); await cb(d); } } catch (e) { if (navigator.onLine) onErr?.(e); } setTimeout(tick, 400); };
      tick(); return () => stop = true;
    },
    async upload(path, blob) { await call('PUT', '/st?path=' + encodeURIComponent(path), null, blob); },
    async download(path) { return (await call('GET', '/st?path=' + encodeURIComponent(path))).blob(); },
    async remove(path) { await call('DELETE', '/st?path=' + encodeURIComponent(path)); },
    async url(path) { return B + '/st?path=' + encodeURIComponent(path) + '&auth=' + (user?.uid || ''); },
    async shareCreate(doc) { return (await (await call('POST', '/share/create', doc)).json()).id; },
    async shareUpdate(id, patch) { await call('POST', '/share/update', { id, patch }); },
    async shareGet(id) { return (await call('GET', '/share/get?id=' + id)).json(); },
    async shareList(uid) { return (await call('GET', '/share/list?uid=' + uid)).json(); }
  };
})();
window.FIREBASE_CONFIG = { apiKey: 'mock', authDomain: 'mock.local', projectId: 'mock-projeto', storageBucket: 'mock' };
