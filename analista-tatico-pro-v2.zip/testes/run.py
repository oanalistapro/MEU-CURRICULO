import asyncio, subprocess, sys, os, json
from playwright.async_api import async_playwright
DIST = '/home/claude/dist'; T = '/home/claude/test'
results = []
def ok(name, cond, info=''):
    results.append((name, bool(cond), info)); print(('PASS ' if cond else 'FAIL ') + name, info, flush=True)

async def main():
    srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8765', '-d', DIST], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    await asyncio.sleep(1)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--autoplay-policy=no-user-gesture-required', '--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 1366, 'height': 820}, permissions=['microphone', 'camera'], accept_downloads=True)
        pg = await ctx.new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('console', lambda m: m.type == 'error' and errs.append(m.text))
        await pg.goto('http://localhost:8765/index.html'); await pg.wait_for_timeout(1500)
        ok('boot sem erros', not errs, errs[:3])
        # navegação por todos os módulos
        for v in ['inicio','mapas','estudio','video','vod','queda','personagens','armas','estrategias','relatorios','config']:
            await pg.evaluate(f"go('{v}')"); await pg.wait_for_timeout(250)
            vis = await pg.is_visible(f'#v-{v}')
            ok('view '+v, vis and not errs, errs[-1:] if errs else '')
        # importar mapa
        await pg.evaluate("go('mapas')"); await pg.wait_for_timeout(300)
        async with pg.expect_file_chooser() as fc:
            await pg.click('[data-imp="bermuda"]')
        await (await fc.value).set_files(f'{T}/map.png'); await pg.wait_for_timeout(400)
        await pg.fill('#mpIn', 'Teste T1'); await pg.click('[data-ok]'); await pg.wait_for_timeout(800)
        st = await pg.evaluate("Maps.status(Maps.get('bermuda'))"); ok('importar mapa (offline/IDB)', st == 'ok', st)
        await pg.click('[data-open="bermuda"]'); await pg.wait_for_timeout(600)
        w = await pg.evaluate("Studio.world"); ok('mapa aberto no estúdio', w['w'] == 1600, w)
        box = await pg.locator('#stage').bounding_box(); cx, cy = box['x'] + box['width']/2, box['y'] + box['height']/2
        async def drag(tool, x1, y1, x2, y2):
            await pg.evaluate(f"Studio.setTool('{tool}')")
            await pg.mouse.move(x1, y1); await pg.mouse.down(); await pg.mouse.move((x1+x2)/2, (y1+y2)/2, steps=4); await pg.mouse.move(x2, y2, steps=4); await pg.mouse.up()
        tools = ['pen','line','arrow','carrow','aarrow','circle','rect','zdanger','zsafe','zcontrol']
        for i, t in enumerate(tools):
            await drag(t, cx - 300 + i*20, cy - 200 + i*25, cx - 150 + i*30, cy - 120 + i*20)
        n = await pg.evaluate("Studio.p.objects.length"); ok('ferramentas de arraste criam objetos', n == len(tools), n)
        for t in ['i-enemy','i-coin','i-shop','i-vehicle','i-ice','i-cover','i-high','step','step']:
            await pg.evaluate(f"Studio.setTool('{t}')"); await pg.mouse.click(cx + 100, cy + 100 + len(t)); await pg.wait_for_timeout(50)
        n2 = await pg.evaluate("Studio.p.objects.length"); ok('ícones e numeração', n2 == n + 9, n2)
        # rota
        await pg.evaluate("Studio.setTool('r-main')")
        for k in range(4): await pg.mouse.click(cx - 200 + k*60, cy + 150 - k*30)
        await pg.click('#cxDone'); n3 = await pg.evaluate("Studio.p.objects.filter(o=>o.type==='route').length"); ok('rota principal', n3 == 1, n3)
        # texto
        await pg.evaluate("Studio.setTool('text')"); await pg.mouse.click(cx, cy - 250); await pg.fill('#mpIn', 'ENTRADA'); await pg.click('[data-ok]'); await pg.wait_for_timeout(200)
        ok('texto', await pg.evaluate("Studio.p.objects.some(o=>o.type==='text'&&o.text==='ENTRADA')"))
        # undo/redo
        before = await pg.evaluate("Studio.p.objects.length"); await pg.click('#bUndo'); a = await pg.evaluate("Studio.p.objects.length"); await pg.click('#bRedo'); r = await pg.evaluate("Studio.p.objects.length")
        ok('desfazer/refazer', a == before - 1 and r == before, (before, a, r))
        # borracha
        await pg.evaluate("Studio.setTool('eraser')"); tp = await pg.evaluate("(()=>{const o=Studio.p.objects.find(o=>o.type==='text');return {x:o.p.x*Studio.view.s+Studio.view.ox,y:o.p.y*Studio.view.s+Studio.view.oy}})()")
        await pg.mouse.click(box['x'] + tp['x'] + 5, box['y'] + tp['y']); ok('borracha', not await pg.evaluate("Studio.p.objects.some(o=>o.type==='text')"))
        # jogadores + keyframes
        await pg.evaluate("Studio.setTool('select')")
        p0 = await pg.evaluate("(()=>{const q=Studio.posAt(Studio.p.players[0],0);return {x:q.x*Studio.view.s+Studio.view.ox,y:q.y*Studio.view.s+Studio.view.oy}})()")
        await pg.mouse.move(box['x']+p0['x'], box['y']+p0['y']); await pg.mouse.down(); await pg.mouse.move(box['x']+p0['x']-120, box['y']+p0['y']-80, steps=5); await pg.mouse.up()
        moved = await pg.evaluate("Studio.p.players[0].x"); ok('arrastar jogador R1', abs(moved - 800) > 40, moved)
        await pg.evaluate("Studio.selPlayer=null"); await pg.click('#bKf')
        await pg.evaluate("Studio.t=10"); await pg.evaluate("Studio.selPlayer='R1'");
        await pg.evaluate("Studio.setKey(Studio.p.players[0], 300, 300)")
        await pg.evaluate("Studio.t=5"); mid = await pg.evaluate("Studio.posAt(Studio.p.players[0],5)")
        ok('keyframes e interpolação', 300 < mid['x'] < moved, mid)
        await pg.evaluate("Studio.t=0"); await pg.click('#bPlay'); await pg.wait_for_timeout(700); t = await pg.evaluate("Studio.t"); await pg.click('#bPlay')
        ok('reprodução da animação', t > 0.3, t)
        # pinça/zoom
        s0 = await pg.evaluate("Studio.view.s"); await pg.click('#zIn'); s1 = await pg.evaluate("Studio.view.s"); ok('zoom', s1 > s0)
        await pg.click('#zFit')
        # salvar
        await pg.fill('#projName', 'Teste Bermuda'); await pg.click('#bSave'); await pg.wait_for_timeout(400)
        ok('salvar projeto', await pg.evaluate("DB.get('projects', Studio.p.id).then(p=>!!p&&p.history.length===1&&p.objects.length>10)"))
        # exportar PNG
        async with pg.expect_download() as dl: await pg.click('#bPng')
        d = await dl.value; path = await d.path(); ok('exportar imagem PNG', os.path.getsize(path) > 10000, os.path.getsize(path))
        # gravação mode 2 (mapa+voz+câmera)
        await pg.click('#bRecOpen'); await pg.wait_for_timeout(300)
        await pg.select_option('#rcMode', '2'); await pg.wait_for_timeout(1200)
        ok('câmera ativa (fake)', await pg.evaluate("!!Studio.cam && Studio.cam.video.readyState>=2"))
        await pg.click('#rcStart'); await pg.wait_for_timeout(3000 + 3000)
        ok('gravando', await pg.evaluate("Recorder.active"))
        await pg.click('#bRecStop'); await pg.wait_for_timeout(1500)
        info = await pg.evaluate("(async()=>{const v=document.querySelector('#resV'); if(!v) return null; await new Promise(r=>setTimeout(r,1500)); return {d:v.duration,w:v.videoWidth,h:v.videoHeight}})()")
        recs = await pg.evaluate("Media.list('rec').then(l=>l.map(r=>({s:r.size,t:r.mime})))")
        ok('gravação gerou vídeo com imagem', info and info['w'] > 0 and recs and recs[0]['s'] > 20000, (info, recs))
        tracks = await pg.evaluate("""(async()=>{const r=(await Media.list('rec'))[0]; const v=document.createElement('video'); v.src=URL.createObjectURL(r.blob); v.muted=true; await new Promise(x=>v.onloadedmetadata=x);
          await v.play(); await new Promise(x=>setTimeout(x,800)); return {audio: v.webkitAudioDecodedByteCount||0, mime:r.mime}})()""")
        ok('gravação contém áudio (microfone)', tracks['audio'] > 0, tracks)
        async with pg.expect_download() as dl: await pg.click('#resD')
        ok('baixar vídeo', (await dl.value) is not None)
        # enviar ao editor
        await pg.click('#resE'); await pg.wait_for_timeout(1500)
        nclips = await pg.evaluate("VEditor.d.clips.length"); ok('vídeo enviado ao editor', nclips == 1, nclips)
        await pg.click('#veTxt'); await pg.click('#veArr')
        await pg.evaluate("VEditor.seek(1)"); await pg.click('#veSplit'); ok('dividir clipe', await pg.evaluate("VEditor.d.clips.length") == 2)
        await pg.evaluate("VEditor.d.clips[1].speed=2; VEditor.save(); VEditor.render()")
        tot = await pg.evaluate("VEditor.total()"); ok('timeline/velocidade', tot > 2, tot)
        await pg.evaluate("VEditor.seek(0)"); await pg.click('#vePlay'); await pg.wait_for_timeout(1200); tT = await pg.evaluate("VEditor.T"); await pg.click('#vePlay')
        ok('reprodução do editor', tT > 0.5, tT)
        # exportar edição
        await pg.click('#veExp'); await pg.click('[data-ok]')
        await pg.wait_for_function("document.querySelector('#resV')", timeout=int(tot*1000)+15000)
        await pg.wait_for_timeout(1500)
        ex = await pg.evaluate("Media.list('rec').then(l=>({n:l.length,s:l[0].size,name:l[0].name}))"); ok('exportar edição', ex['n'] == 2 and ex['s'] > 10000, ex)
        await pg.click('#mbox [data-x]')
        # VOD
        await pg.evaluate("go('vod')"); await pg.wait_for_timeout(300)
        async with pg.expect_file_chooser() as fc: await pg.click('#vdImp')
        await (await fc.value).set_files(f'{T}/match.webm'); await pg.wait_for_timeout(300); await pg.click('[data-ok]'); await pg.wait_for_timeout(1200)
        await pg.evaluate("Vod.video.currentTime=2"); await pg.wait_for_timeout(400)
        await pg.select_option('#anK', 'erro'); await pg.select_option('#anC', 'ROTACAO'); await pg.select_option('#anP', 'R1'); await pg.fill('#anTx', 'Rotação tardia'); await pg.click('#anAdd'); await pg.wait_for_timeout(300)
        ann = await pg.evaluate("DB.all('vods').then(v=>v[0].annotations)"); ok('anotação de VOD com tempo', ann and abs(ann[0]['t'] - 2) < 0.2 and ann[0]['player'] == 'R1', ann)
        await pg.click('[data-sk="0.0333"]'); await pg.wait_for_timeout(200); ft = await pg.evaluate("Vod.video.currentTime"); ok('avanço quadro a quadro', 2.0 < ft < 2.1, ft)
        # VOD -> estudio (modo 05)
        await pg.click('#vdStudio'); await pg.wait_for_timeout(1000)
        ok('vídeo de partida como fundo do estúdio', await pg.evaluate("!!Studio.bgVideo && Studio.world.w===640"))
        await pg.evaluate("Studio.stopBgVideo(); Recorder.toggleCam()")
        # bibliotecas
        await pg.evaluate("go('personagens')"); await pg.wait_for_timeout(400)
        nch = await pg.evaluate("DB.all('chars').then(l=>l.length)"); ok('biblioteca de personagens semeada (sem dados inventados)', nch == 12 and await pg.evaluate("DB.all('chars').then(l=>l.every(c=>!c.effect&&!c.verified))"), nch)
        await pg.evaluate("""(async()=>{const l=await DB.all('chars'); const set=(n,t,o)=>Object.assign(l.find(c=>c.name===n),{type:t,version:'T1',verified:true,...o});
          set('Oscar','ativa',{}); set('Joseph','passiva',{synergies:'Moco'}); set('Moco','passiva',{}); set('Nero','passiva',{incompat:'Joseph'}); set('Olivia','passiva',{}); for(const c of l) await DB.put('chars',c);})()""")
        await pg.evaluate("Views.personagens.render()"); await pg.wait_for_timeout(400)
        ids = await pg.evaluate("DB.all('chars').then(l=>Object.fromEntries(l.map(c=>[c.name,c.id])))")
        await pg.select_option('#cbA', ids['Oscar']); await pg.select_option('[data-cbp="0"]', ids['Joseph']); await pg.select_option('[data-cbp="1"]', ids['Moco']); await pg.select_option('[data-cbp="2"]', ids['Nero'])
        await pg.fill('#cbV', 'T1'); await pg.dispatch_event('#cbV', 'change')
        out = await pg.inner_text('#cbOut'); ok('validação de incompatibilidade', 'inválida' in out, out[:80])
        await pg.select_option('[data-cbp="2"]', ids['Olivia']); out = await pg.inner_text('#cbOut'); ok('combinação válida + sinergia', 'válida' in out and 'Joseph ↔ Moco' in out, out[:120])
        await pg.evaluate("go('armas')"); await pg.wait_for_timeout(400); ok('catálogo de armas', await pg.evaluate("DB.all('weapons').then(l=>l.length)") == 10)
        # economia
        await pg.evaluate("go('queda')"); await pg.wait_for_timeout(300)
        await pg.click('#qAdd'); await pg.fill('#mpIn', 'Rádio'); await pg.click('[data-ok]'); await pg.wait_for_timeout(400)
        await pg.fill('[data-ic]', '1500'); await pg.dispatch_event('[data-ic]', 'change'); await pg.wait_for_timeout(300)
        await pg.fill('[data-co="R1"]', '1000'); await pg.dispatch_event('[data-co="R1"]', 'change'); await pg.wait_for_timeout(300)
        await pg.check('[data-by^="R1|"]'); await pg.wait_for_timeout(300)
        txt = await pg.inner_text('#v-queda'); ok('calculadora de economia', '-500' in txt, '')
        # relatórios
        await pg.evaluate("go('relatorios')"); await pg.wait_for_timeout(300)
        await pg.evaluate("DB.kv('scoring',[{id:'m1',name:'Liga',kill:1,place:[12,9,8,7,6,5,4,3,2,1,0,0]}])"); await pg.evaluate("Views.relatorios.render()"); await pg.wait_for_timeout(300)
        await pg.click('#rpNew'); await pg.fill('#mE', 'Liga X'); await pg.fill('#mM', 'Bermuda'); await pg.fill('#mP', '1'); await pg.select_option('#mMd', 'm1'); await pg.fill('[data-m="kills.R1"]', '5'); await pg.fill('[data-m="kills.R2"]', '3')
        await pg.click('[data-ok]'); await pg.wait_for_timeout(400)
        kp = await pg.inner_text('#v-relatorios'); ok('relatório com pontuação (12+8=20)', '20' in kp and 'Liga X' in kp)
        # projetos: duplicar / exportar / importar
        await pg.evaluate("go('estrategias')"); await pg.wait_for_timeout(300)
        await pg.click('[data-du]'); await pg.wait_for_timeout(300); ok('duplicar projeto', await pg.evaluate("DB.all('projects').then(l=>l.length)") == 2)
        async with pg.expect_download() as dl: await pg.locator('[data-ex]').first.click()
        pj = await (await dl.value).path()
        async with pg.expect_file_chooser() as fc: await pg.click('#psImp')
        await (await fc.value).set_files(pj); await pg.wait_for_timeout(500); await pg.click('#mbox [data-ok]'); await pg.wait_for_timeout(500)
        ok('exportar/importar projeto', await pg.evaluate("DB.all('projects').then(l=>l.length)") == 3)
        # backup
        await pg.evaluate("go('config')"); await pg.wait_for_timeout(400)
        async with pg.expect_download() as dl: await pg.click('#cfBk')
        bk = json.load(open(await (await dl.value).path())); ok('backup completo', len(bk['stores']['projects']) == 3 and len(bk['stores']['chars']) == 12)
        # SW + offline
        await pg.wait_for_timeout(800); await pg.reload(); await pg.wait_for_timeout(1500)
        ok('service worker ativo', await pg.evaluate("!!navigator.serviceWorker.controller"))
        await ctx.set_offline(True); await pg.reload(); await pg.wait_for_timeout(1500)
        ok('funciona offline + dados preservados', await pg.evaluate("Maps.status(Maps.get('bermuda'))==='ok' && Studio.p.name==='Teste Bermuda'"))
        await ctx.set_offline(False)
        await pg.evaluate("go('estudio')"); await pg.wait_for_timeout(800); await pg.screenshot(path=f'{T}/desk_studio.png')
        await pg.evaluate("go('inicio')"); await pg.wait_for_timeout(400); await pg.screenshot(path=f'{T}/desk_home.png')
        ok('sem erros no console ao final', not errs, errs[:5])
        # mobile
        m = await b.new_context(viewport={'width': 390, 'height': 844}, has_touch=True, is_mobile=True, device_scale_factor=3)
        mp = await m.new_page(); merr = []; mp.on('pageerror', lambda e: merr.append(str(e)))
        await mp.goto('http://localhost:8765/index.html#estudio'); await mp.wait_for_timeout(1500)
        await mp.screenshot(path=f'{T}/mob_studio.png')
        await mp.evaluate("Studio.setTool('arrow')"); bb = await mp.locator('#stage').bounding_box()
        cdp = await m.new_cdp_session(mp)
        x, y = bb['x'] + 100, bb['y'] + 150
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': x, 'y': y}]})
        for k in range(1, 6): await cdp.send('Input.dispatchTouchEvent', {'type': 'touchMove', 'touchPoints': [{'x': x + k*25, 'y': y + k*15}]})
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchEnd', 'touchPoints': []})
        await mp.wait_for_timeout(300)
        ok('toque desenha seta (mobile)', await mp.evaluate("Studio.p.objects.filter(o=>o.type==='arrow').length") == 1)
        s0 = await mp.evaluate("Studio.view.s")
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': x, 'y': y, 'id': 1}, {'x': x + 40, 'y': y + 40, 'id': 2}]})
        for k in range(1, 6): await cdp.send('Input.dispatchTouchEvent', {'type': 'touchMove', 'touchPoints': [{'x': x - k*15, 'y': y - k*15, 'id': 1}, {'x': x + 40 + k*15, 'y': y + 40 + k*15, 'id': 2}]})
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchEnd', 'touchPoints': []})
        await mp.wait_for_timeout(200); s1 = await mp.evaluate("Studio.view.s")
        ok('pinça para zoom (mobile)', s1 > s0 * 1.3 and await mp.evaluate("Studio.p.objects.filter(o=>o.type==='arrow').length") == 1, (s0, s1))
        await mp.evaluate("go('inicio')"); await mp.wait_for_timeout(300); await mp.screenshot(path=f'{T}/mob_home.png')
        await mp.evaluate("go('video')"); await mp.wait_for_timeout(500); await mp.screenshot(path=f'{T}/mob_video.png')
        ok('mobile sem erros', not merr, merr[:3])
        await b.close()
    srv.terminate()
    f = [r for r in results if not r[1]]; print(f'\n{len(results)-len(f)}/{len(results)} passaram'); [print('FALHOU:', r) for r in f]
asyncio.run(main())
