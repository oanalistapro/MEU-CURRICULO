"""Testes V4 — ANALISTA TÁTICO PRO. Executados em Google Chrome (headless) com Playwright.
A nuvem é SIMULADA por mockcloud.py (mesma interface do adaptador Firebase); o Firebase real não é acessível neste ambiente."""
import asyncio, subprocess, sys, os, json, time
from playwright.async_api import async_playwright
T = '/home/claude/test'; V2 = '/home/claude/dist'; V1 = '/tmp/v1/dist'; SITE = '/tmp/site'; URL = 'http://localhost:8765/index.html'
R = []
def ok(name, cond, info=''):
    R.append((name, bool(cond), info)); print(('PASS ' if cond else 'FAIL ') + name, '' if cond else info, flush=True)
def link(target):
    if os.path.islink(SITE): os.unlink(SITE)
    os.symlink(target, SITE)
MOCK = open(f'{T}/mockbackend.js').read()
ARGS = ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--autoplay-policy=no-user-gesture-required', '--no-sandbox', '--auto-select-desktop-capture-source=Entire screen']

async def newctx(b, mock=False, mobile=False):
    kw = dict(viewport={'width': 390, 'height': 844}, has_touch=True, is_mobile=True, device_scale_factor=2) if mobile else dict(viewport={'width': 1366, 'height': 820})
    c = await b.new_context(permissions=['microphone', 'camera', 'clipboard-read', 'clipboard-write'], accept_downloads=True, **kw)
    if mock: await c.add_init_script(MOCK)
    return c
async def newpage(c, url=URL):
    p = await c.new_page(); p.errs = []
    p.on('pageerror', lambda e: p.errs.append(str(e)))
    await p.goto(url); await p.wait_for_function('typeof Studio!=="undefined" && Studio.cv && Maps.list.length>0', timeout=15000); await p.wait_for_timeout(600)
    return p
async def toast(p): return await p.inner_text('#toast')
async def close_modals(p):
    for _ in range(4):
        if not await p.evaluate("document.querySelector('#modal').classList.contains('on')"): return
        await p.keyboard.press('Escape'); await p.wait_for_timeout(150)
async def pick(p, sel, path, click_ok=None):
    async with p.expect_file_chooser() as fc: await p.click(sel)
    await (await fc.value).set_files(path); await p.wait_for_timeout(500)

async def main():
    link(V1)
    srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8765', '-d', SITE], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    cloud = subprocess.Popen([sys.executable, f'{T}/mockcloud.py'])
    await asyncio.sleep(1.2)
    async with async_playwright() as pw:
        b = await pw.chromium.launch(executable_path='/usr/bin/google-chrome', args=ARGS)
        # ================= 1. ATUALIZAÇÃO v1 → v2 SEM PERDA DE DADOS =================
        c0 = await newctx(b); p = await p_v1(c0)
        await p.evaluate("go('mapas')"); await p.wait_for_timeout(300)
        await pick(p, '[data-imp="bermuda"]', f'{T}/map800.png'); await p.fill('#mpIn', 'T1'); await p.click('[data-ok]'); await p.wait_for_timeout(800)
        await p.evaluate("""(async()=>{const m=Maps.get('bermuda'); m.regions.push({id:'r1',x:400,y:200,name:'CLOCK'}); await DB.put('maps',m);
          await Studio.setMap('bermuda'); Studio.p.objects.push({id:'o1',type:'arrow',layer:'tatica',color:'#fff',w:4,alpha:1,dash:'solid',a:{x:100,y:100},b:{x:400,y:400}});
          document.querySelector('#projName').value='Projeto v1'; await Studio.saveProject(true);
          await Media.save(new Blob(['x'.repeat(5000)],{type:'video/webm'}),{kind:'rec',name:'gravacao_v1.webm'});})()""")
        before = await p.evaluate("(async()=>({p:(await DB.all('projects')).length, m:(await DB.all('media')).length, ch:(await DB.all('chars')).length}))()")
        await p.close(); link(V2)
        p = await newpage(c0, URL + '?nocache=2')
        after = await p.evaluate("""(async()=>{const pr=(await DB.all('projects')).find(x=>x.name==='Projeto v1'); const m=Maps.get('bermuda');
          return {p:(await DB.all('projects')).length, m:(await DB.all('media')).length, ch:(await DB.all('chars')).length, ver:DB.db.version, obj:pr&&pr.objects.length, reg:m.regions[0], mv:m.versions.length, rec:(await Media.list('rec')).length}})()""")
        ok('upgrade v1→v2: banco migrado para versão 2', after['ver'] == 2, after)
        ok('upgrade: projetos, mídias e biblioteca preservados', after['p'] == before['p'] and after['m'] == before['m'] and after['ch'] == before['ch'] and after['obj'] == 1 and after['rec'] == 1, (before, after))
        ok('upgrade: regiões convertidas para coordenadas relativas', abs(after['reg']['nx'] - 0.5) < 1e-6 and abs(after['reg']['ny'] - 0.25) < 1e-6, after['reg'])
        ok('upgrade sem erros', not p.errs, p.errs[:3])
        # ================= 2. MAPAS =================
        await p.evaluate("go('mapas')"); await p.wait_for_timeout(300)
        await p.click('[data-reg="bermuda"]'); await p.fill('#rgN', 'PEAK'); await p.click('#rgA'); await p.wait_for_timeout(200)
        await p.click('#mbox [data-x]'); await p.wait_for_timeout(200)
        await p.click('[data-open="bermuda"]'); await p.wait_for_timeout(500)
        await p.evaluate("Studio.setTool('region')"); bb = await p.locator('#stage').bounding_box()
        await p.mouse.click(bb['x'] + bb['width'] / 2, bb['y'] + bb['height'] / 2); await p.wait_for_timeout(300)
        btns = await p.locator('[data-rp]').all_inner_texts(); ok('ferramenta Região oferece nomes cadastrados sem posição', 'PEAK' in btns, btns)
        await p.click('[data-rp]'); await p.wait_for_timeout(300)
        reg = await p.evaluate("Maps.get('bermuda').regions.find(r=>r.name==='PEAK')"); ok('região posicionada (coordenada relativa salva)', reg['nx'] is not None and 0.3 < reg['nx'] < 0.7, reg)
        await p.evaluate("Studio.setTool('select')")
        o0 = await p.evaluate("Studio.p.objects.find(o=>o.id==='o1').b")
        await p.evaluate("go('mapas')"); await p.wait_for_timeout(300)
        await pick(p, '[data-imp="bermuda"]', f'{T}/map.png'); await p.fill('#mpIn', 'T2-1600px'); await p.click('[data-ok]'); await p.wait_for_timeout(900)
        await p.evaluate("Studio.setMap('bermuda')"); await p.wait_for_timeout(400)
        o1 = await p.evaluate("Studio.p.objects.find(o=>o.id==='o1').b"); w = await p.evaluate("Studio.world.w")
        ok('nova versão do mapa (800→1600px): marcações reescaladas e alinhadas', w == 1600 and abs(o1['x'] - o0['x'] * 2) < 0.01, (o0, o1, w))
        reg2 = await p.evaluate("Maps.get('bermuda').regions.find(r=>r.name==='PEAK')"); ok('regiões continuam alinhadas após trocar versão', reg2['nx'] == reg['nx'])
        await p.evaluate("go('mapas')"); await p.wait_for_timeout(300)
        await pick(p, '[data-imp="kalahari"]', f'{T}/map_big.png'); await p.fill('#mpIn', 'grande'); await p.click('[data-ok]'); await p.wait_for_timeout(2500)
        kv = await p.evaluate("Maps.activeVersion(Maps.get('kalahari'))"); ok('imagem 5000px reduzida ao limite (4096px) para economizar memória', kv and kv['w'] == 4096, kv)
        await close_modals(p)
        # ================= 3. PERSONAGENS E ARMAS =================
        await p.evaluate("go('armas')"); await p.wait_for_timeout(400)
        await p.click('[data-ed="w-ump"]'); await p.wait_for_timeout(200)
        labels = await p.locator('#mbox label.f').all_inner_texts(); lt = ' '.join(labels)
        ok('arma: campos Dano/Alcance/Cadência/Precisão/Vantagens/Desvantagens', all(x in lt for x in ['Dano', 'Alcance', 'Cadência', 'Precisão', 'Vantagens', 'Desvantagens']), lt[:200])
        await p.fill('[data-k="damage"]', '40'); await p.fill('[data-k="version"]', 'T1'); await p.click('#mbox [data-ok]'); await p.wait_for_timeout(300)
        ok('arma salva sem estatística pré-preenchida pelo app', await p.evaluate("DB.get('weapons','w-ump').then(w=>w.damage==='40' && (DB.get('weapons','w-mp5').then(x=>!x.damage)))"))
        async with p.expect_download() as dl: await p.click('#lbExp')
        cat = json.load(open(await (await dl.value).path()))
        ok('exportar catálogo', cat['type'] == 'catalog' and len(cat['items']) == 10)
        cat['items'][0]['traits'] = 'alterado'; cat['items'].append({'id': 'w-novo', 'name': 'NOVA ARMA', 'category': 'AR', 'version': 'T1', '__proto__': {'polluted': 1}, 'evil': '<img src=x onerror=alert(1)>'})
        cat['items'].append({'id': 'w-bad'})
        json.dump(cat, open(f'{T}/cat.json', 'w'))
        await pick(p, '#lbImp', f'{T}/cat.json'); prev = await p.inner_text('#mbox')
        ok('importação de catálogo: pré-visualização (1 novo, 1 alterado, inválido descartado)', '1 novos' in prev and '1 já existentes' in prev and '11 item' in prev, prev[:200])
        await p.click('#ciNew'); await p.wait_for_timeout(400)
        st = await p.evaluate("(async()=>({n:!!await DB.get('weapons','w-novo'), ch:(await DB.get('weapons','w-ak')||{}).traits, ev:(await DB.get('weapons','w-novo')).evil, pol:({}).polluted}))()")
        ok('“só novos” não sobrescreve existentes; campos desconhecidos e __proto__ descartados', st['n'] and st.get('ev') is None and st.get('pol') is None, st)
        bad = {'app': 'analista-tatico-pro', 'type': 'catalog', 'store': 'chars', 'items': []}; json.dump(bad, open(f'{T}/cat_bad.json', 'w'))
        await pick(p, '#lbImp', f'{T}/cat_bad.json'); ok('catálogo do tipo errado é rejeitado', 'inválido' in await toast(p))
        await p.evaluate("""(async()=>{const set=async(id,o)=>{const c=await DB.get('chars',id); Object.assign(c,o); delete c.seed; await DB.put('chars',c);};
          await set('c-oscar',{type:'ativa',version:'T1',verified:true,roles:['R1']}); await set('c-joseph',{type:'passiva',version:'T1',verified:true,roles:['R1']});
          await set('c-moco',{type:'passiva',version:'T1',verified:true}); await set('c-olivia',{type:'passiva',version:'T1',verified:true}); await set('c-nero',{type:'passiva',version:'T2',verified:true});
          Settings.data.strictVersion=true; await Settings.save();})()""")
        await p.evaluate("go('personagens')"); await p.wait_for_timeout(500)
        await p.select_option('#cbA', 'c-oscar'); await p.select_option('[data-cbp="0"]', 'c-joseph'); await p.select_option('[data-cbp="1"]', 'c-moco'); await p.select_option('[data-cbp="2"]', 'c-nero')
        await p.fill('#cbV', 'T1'); await p.dispatch_event('#cbV', 'change'); await p.select_option('#cbR', 'R1')
        out = await p.inner_text('#cbOut'); ok('modo estrito bloqueia personagem de outra versão do jogo', 'inválida' in out and 'T2' in out, out[:150])
        await p.select_option('[data-cbp="2"]', 'c-olivia'); out = await p.inner_text('#cbOut'); ok('combinação na versão selecionada é válida', 'válida' in out and 'inválida' not in out, out[:150])
        await p.click('#cbSave'); await p.wait_for_timeout(500)
        cid = await p.evaluate("DB.kv('combos').then(c=>c[0].id)"); await p.select_option('[data-sq="R1"]', cid); await p.wait_for_timeout(200)
        await p.click('#sqApply'); await p.wait_for_timeout(200)
        pl = await p.evaluate("Studio.p.players[0]"); ok('composição do squad aplicada ao R1 do projeto', pl['char'] == 'Oscar' and 'Joseph' in pl['passives'], (pl['char'], pl['passives']))
        await p.click('[data-ed="c-oscar"]'); await p.click('#liDup'); await p.fill('#mpIn', 'T3'); await p.click('#mbox [data-ok]'); await p.wait_for_timeout(500)
        ok('duplicar personagem para nova versão do jogo', await p.evaluate("DB.all('chars').then(l=>l.some(c=>c.name==='Oscar'&&c.version==='T3'&&!c.verified))"))
        await close_modals(p)
        # ================= 4. BACKUP E SEGURANÇA =================
        await p.evaluate("go('config')"); await p.wait_for_timeout(500)
        async with p.expect_download() as dl: await p.click('#cfBk')
        bk = json.load(open(await (await dl.value).path())); ok('backup completo (formato 2, sem metadados de sync)', bk['format'] == 2 and 'sync' not in bk['stores'] and len(bk['stores']['projects']) >= 1, bk.get('counts'))
        for name, data, expect in [('wrong', {'app': 'outro'}, 'não é um backup'), ('future', dict(bk, format=99), 'mais novo')]:
            json.dump(data, open(f'{T}/bk_{name}.json', 'w')); await pick(p, '#cfRs', f'{T}/bk_{name}.json')
            ok(f'backup rejeitado ({name})', expect in await toast(p), await toast(p))
        open(f'{T}/bk_broken.json', 'w').write('{"app": "analista-tatico-pro", "type": "backup", "stores": {')
        await pick(p, '#cfRs', f'{T}/bk_broken.json'); ok('JSON corrompido rejeitado sem travar', 'inválido' in await toast(p))
        m = json.loads(json.dumps(bk)); pr = m['stores']['projects'][0]; orig_name = pr['name']; pr['name'] = 'NOME DO BACKUP'
        new = json.loads(json.dumps(pr)); new['id'] = 'p-novo'; new['name'] = 'Projeto novo do backup'; m['stores']['projects'].append(new)
        m['stores']['projects'].append({'id': 'p-ruim', 'name': 'sem jogadores', 'mapId': 'x', 'objects': [], 'players': [], 'keyframes': {}})
        m['stores']['kv'].append({'id': 'evil', 'v': 1, '__proto__': {'polluted': True}})
        m['stores']['media'] = [{'id': 'mx', 'kind': 'rec', 'blob': 'data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=='}]
        json.dump(m, open(f'{T}/bk_mod.json', 'w')); await pick(p, '#cfRs', f'{T}/bk_mod.json')
        prev = await p.inner_text('#mbox'); ok('pré-visualização do backup lista novos/diferentes e inválidos', 'Pré-visualização' in prev and 'inválido' in prev and 'mídia com formato não permitido' in prev and 'projeto deve ter 4 jogadores' in prev, prev[:300])
        await p.click('#rsNew'); await p.wait_for_timeout(1200)
        st = await p.evaluate(f"(async()=>({{nw:!!await DB.get('projects','p-novo'), keep:(await DB.get('projects','{pr['id']}')).name, bad:!!await DB.get('projects','p-ruim'), mx:!!await DB.get('media','mx'), pol:({{}}).polluted}}))()")
        ok('“só novos”: existente não sobrescrito; inválidos e mídia perigosa ignorados; sem poluição de protótipo', st['nw'] and st['keep'] == orig_name and not st['bad'] and not st['mx'] and st.get('pol') is None, st)
        await p.evaluate("go('config')"); await p.wait_for_timeout(400); await p.click('#cfUndo'); await p.click('#mbox [data-ok]'); await p.wait_for_timeout(800)
        ok('desfazer última importação remove o que foi adicionado', not await p.evaluate("DB.get('projects','p-novo').then(Boolean)"))
        await p.evaluate("go('config')"); await p.wait_for_timeout(400)
        await pick(p, '#cfRs', f'{T}/bk_mod.json'); await p.click('#rsAll'); await p.click('#mbox [data-ok]'); await p.wait_for_timeout(1200)
        nm = await p.evaluate(f"DB.get('projects','{pr['id']}').then(x=>x.name)"); ok('substituir exige confirmação e aplica', nm == 'NOME DO BACKUP', nm)
        await p.evaluate("go('config')"); await p.wait_for_timeout(400); await p.click('#cfUndo'); await p.click('#mbox [data-ok]'); await p.wait_for_timeout(800)
        nm = await p.evaluate(f"DB.get('projects','{pr['id']}').then(x=>x.name)"); ok('ponto de restauração devolve o dado substituído', nm == orig_name, nm)
        # ================= 5. GRAVAÇÃO =================
        await p.evaluate("go('estudio')"); await p.wait_for_timeout(400)
        await p.evaluate("Recorder.toggleCam()"); await p.wait_for_timeout(1200)
        f1 = await p.evaluate("({on:!!Studio.cam, mirror:Studio.cam&&Studio.cam.mirror})")
        await p.evaluate("Recorder.facing='environment'; Recorder.toggleCam().then(()=>Recorder.toggleCam())"); await p.wait_for_timeout(1500)
        f2 = await p.evaluate("({on:!!Studio.cam, mirror:Studio.cam&&Studio.cam.mirror, devs:Recorder.devices.cams.length})")
        ok('câmera frontal espelhada / traseira sem espelho, troca sem erro', f1['on'] and f1['mirror'] and f2['on'] and not f2['mirror'], (f1, f2))
        await p.evaluate("Recorder.toggleCam()")
        mime = await p.evaluate("""(()=>{const O=window.MediaRecorder; class F extends O{constructor(s,o){ if(o&&o.mimeType&&!/vp8/.test(o.mimeType)) throw new DOMException('no','NotSupportedError'); super(s,o);} }
          F.isTypeSupported=O.isTypeSupported; window.MediaRecorder=F; const r=Recorder.makeRecorder(Studio.cv.captureStream(5)); window.MediaRecorder=O; return Recorder.mime})()""")
        ok('fallback de codec: recusa de formatos → usa o próximo compatível', 'vp8' in mime, mime)
        await p.evaluate("Studio.panTab='gravar'; document.querySelector('#panel').classList.remove('closed'); Studio.renderPanel(); Recorder.mode='1'")
        await p.click('#rcStart'); await p.wait_for_timeout(2600 + 3500)
        rec = await p.evaluate("({a:Recorder.active, parts:0})"); parts = await p.evaluate("DB.all('media').then(l=>l.filter(m=>m.kind==='recpart').length)")
        ok('pedaços da gravação salvos durante a captura (proteção contra travamento)', rec['a'] and parts >= 2, parts)
        await p.evaluate("Object.defineProperty(document,'hidden',{configurable:true,get:()=>true}); document.dispatchEvent(new Event('visibilitychange'))")
        ok('app em segundo plano pausa a gravação', await p.evaluate("Recorder.paused"))
        await p.evaluate("Object.defineProperty(document,'hidden',{configurable:true,get:()=>false}); document.dispatchEvent(new Event('visibilitychange'))"); await p.wait_for_timeout(300)
        await p.evaluate("Recorder.togglePause()"); await p.wait_for_timeout(1500)
        nrec0 = await p.evaluate("Media.list('rec').then(l=>l.length)")
        await p.reload(); await p.wait_for_timeout(2500)  # simula fechamento abrupto durante a gravação
        txt = await p.inner_text('#mbox'); ok('após fechamento abrupto o app oferece recuperar a gravação', 'interrompida' in txt, txt[:120])
        await p.click('#mbox [data-ok]'); await p.wait_for_timeout(1500)
        info = await p.evaluate("""(async()=>{const l=await Media.list('rec'); const r=l.find(x=>x.recovered); if(!r) return null; const v=document.createElement('video'); v.muted=true; v.src=URL.createObjectURL(r.blob);
          await new Promise(x=>{v.onloadedmetadata=x; v.onerror=x; setTimeout(x,4000)}); return {size:r.size, w:v.videoWidth, parts:(await DB.all('media')).filter(m=>m.kind==='recpart').length}})()""")
        ok('gravação recuperada é reproduzível e os pedaços são limpos', info and info['size'] > 10000 and info['w'] > 0 and info['parts'] == 0, info)
        await close_modals(p)
        b_noperm = await pw.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox', '--use-fake-device-for-media-stream'])
        cn = await b_noperm.new_context(); pn = await newpage(cn)
        await pn.evaluate("go('estudio')"); await pn.evaluate("Recorder.toggleCam()"); await pn.wait_for_timeout(1500)
        t = await toast(pn); ok('permissão de câmera negada → mensagem clara, app continua funcionando', 'negada' in t or 'Permissão' in t, t)
        await b_noperm.close()
        try:
            await p.evaluate("go('estudio'); Recorder.mode='7'"); r7 = await p.evaluate("Recorder.startScreen().then(()=>({ok:!!Studio.bgVideo&&!!Studio.bgVideo.srcObject})).catch(e=>({err:e.message}))")
            ok('MODE_07 captura de tela (computador)', r7.get('ok'), r7)
            await p.evaluate("Recorder.stopScreen()")
        except Exception as e: ok('MODE_07 captura de tela (computador)', False, str(e)[:100])
        await c0.close()
        # ================= 6. NUVEM (simulada) — login, migração, sync, conflito, offline, links =================
        cA = await newctx(b, mock=True); A = await newpage(cA)
        await A.evaluate("go('config')"); await A.wait_for_timeout(600)
        ok('nuvem configurada detectada (firebase-config.js)', 'mock-projeto' in await A.inner_text('#cloudBox'))
        await A.fill('#fbEm', 'analista@time.com'); await A.fill('#fbPw', '123'); await A.click('#fbUp'); await A.wait_for_timeout(500)
        ok('validação de senha fraca no cadastro', 'fraca' in await toast(A) or 'weak' in await toast(A), await toast(A))
        await A.fill('#fbPw', 'segredo123'); await A.click('#fbUp'); await A.wait_for_timeout(1200)
        ok('cadastro/login → diálogo de migração dos dados locais', 'Ativar sincronização' in await A.inner_text('#mbox'))
        await A.evaluate("""(async()=>{Studio.p.objects.push({id:'a1',type:'line',layer:'tatica',color:'#fff',w:4,alpha:1,dash:'solid',a:{x:10,y:10},b:{x:500,y:500}});
          document.querySelector('#projName').value='Rush Peak'; await Studio.saveProject(true);})()""")
        await A.click('#mgGo'); await A.wait_for_timeout(3000)
        srvst = await A.evaluate("fetch('http://127.0.0.1:8790/admin/state').then(r=>r.json())")
        pid = await A.evaluate("Studio.p.id")
        ok('migração envia dados locais para a nuvem sem apagar', srvst['items'] >= 20 and await A.evaluate("DB.all('projects').then(l=>l.length)") >= 1, srvst['items'])
        cB = await newctx(b, mock=True); B = await newpage(cB)
        await B.evaluate("go('config')"); await B.wait_for_timeout(600)
        await B.fill('#fbEm', 'analista@time.com'); await B.fill('#fbPw', 'errada'); await B.click('#fbIn'); await B.wait_for_timeout(500)
        ok('senha errada → mensagem em português', 'incorretos' in await toast(B), await toast(B))
        await B.fill('#fbPw', 'segredo123'); await B.click('#fbIn'); await B.wait_for_timeout(1200); await B.click('#mgGo'); await B.wait_for_timeout(3500)
        gotB = await B.evaluate(f"DB.get('projects','{pid}').then(p=>p&&p.objects.length)")
        ok('segundo aparelho recebe o projeto do primeiro', gotB == 1, gotB)
        clog = await B.evaluate("DB.kv('conflictLog').then(l=>(l||[]).map(c=>c.store+':'+(c.rec&&c.rec.id)))"); ok('itens de fábrica idênticos não geram conflitos falsos', len(clog) == 0, clog)
        await B.evaluate(f"(async()=>{{await Studio.loadProject(await DB.get('projects','{pid}')); go('estudio');}})()")
        await A.evaluate("(async()=>{Studio.p.objects.push({id:'a2',type:'line',layer:'tatica',color:'#f00',w:4,alpha:1,dash:'solid',a:{x:20,y:20},b:{x:600,y:300}}); await Studio.saveProject(true);})()")
        await B.wait_for_timeout(3500)
        ok('sincronização em tempo real: edição no aparelho A aparece no B', await B.evaluate("Studio.p.objects.length") == 2, await B.evaluate("Studio.p.objects.length"))
        await cB.set_offline(True); await B.evaluate("window.dispatchEvent(new Event('offline'))")
        await B.evaluate("(async()=>{Studio.p.objects.push({id:'b1',type:'circle',layer:'tatica',color:'#0f0',w:4,alpha:1,dash:'solid',a:{x:300,y:300},b:{x:350,y:300}}); await Studio.saveProject(true);})()")
        await B.wait_for_timeout(2500); pend = await B.evaluate("Cloud.pending()")
        ok('offline: alteração fica na fila de pendências', pend >= 1, pend)
        await A.evaluate("(async()=>{Studio.p.objects.push({id:'a3',type:'line',layer:'tatica',color:'#00f',w:4,alpha:1,dash:'solid',a:{x:5,y:600},b:{x:600,y:5}}); await Studio.saveProject(true);})()")
        await A.wait_for_timeout(2500)
        await cB.set_offline(False); await B.evaluate("window.dispatchEvent(new Event('online'))"); await B.wait_for_timeout(6000)
        st = await B.evaluate(f"""(async()=>{{const l=await DB.all('projects'); const o=l.find(p=>p.id==='{pid}'); const c=l.find(p=>/conflito/.test(p.name));
          return {{orig:o&&o.objects.map(x=>x.id), copy:c&&c.objects.map(x=>x.id), studio:Studio.p.name, pend:await Cloud.pending()}}}})()""")
        ok('conflito: versão da nuvem mantida e versão local salva como cópia (nada perdido)', st['orig'] and 'a3' in st['orig'] and st['copy'] and 'b1' in st['copy'], st)
        ok('reenvio automático das pendências ao voltar a conexão', st['pend'] == 0, st)
        await A.wait_for_timeout(2500)
        ok('cópia de conflito também chega ao outro aparelho', await A.evaluate("DB.all('projects').then(l=>l.some(p=>/conflito/.test(p.name)))"))
        await A.evaluate("go('mapas')"); await A.wait_for_timeout(300)
        await pick(A, '[data-imp="purgatorio"]', f'{T}/map800.png'); await A.fill('#mpIn', 'T1'); await A.click('[data-ok]'); await A.wait_for_timeout(4000)
        mb = await B.evaluate("(async()=>{const m=(await DB.get('maps','purgatorio')); const v=m.versions[0]; return {v:m.versions.length, img:!!(v&&await DB.get('media',v.mediaId))}})()")
        ok('imagem de mapa sincronizada para o outro aparelho (Storage)', mb['v'] == 1 and mb['img'], mb)
        await A.evaluate("(async()=>{const p=await DB.get('projects',Studio.p.id); const c={...p,id:'tmp-del',name:'Apagar teste'}; await DB.put('projects',c);})()"); await A.wait_for_timeout(3000)
        await A.evaluate("DB.del('projects','tmp-del')"); await A.wait_for_timeout(3500)
        dl_ = await B.evaluate("DB.get('projects','tmp-del').then(p=>p&&{a:p.archived,n:p.name})")
        ok('exclusão em outro aparelho arquiva (não apaga) neste', dl_ and dl_['a'] and 'excluído' in dl_['n'], dl_)
        # links públicos
        await A.evaluate("go('estudio'); Recorder.mode='1'; Recorder.mic=false; Studio.panTab='gravar'; document.querySelector('#panel').classList.remove('closed'); Studio.renderPanel()")
        await A.click('#rcStart'); await A.wait_for_timeout(2600 + 2000); await A.click('#bRecStop'); await A.wait_for_timeout(1500); await close_modals(A)
        await A.evaluate("(async()=>{await Studio.setMap('purgatorio'); await Studio.saveProject(true);})()")
        await A.click('#bSharePng'); await A.click('#shLink'); await A.wait_for_timeout(800)
        opts = await A.locator('#shVid option').count(); await A.select_option('#shVid', index=1); await A.click('#shCreate'); await A.wait_for_timeout(3500)
        shares = await A.evaluate("Cloud.be.shareList(Cloud.user.uid)"); s1 = shares[0]; lnk = await A.evaluate(f"Cloud.linkFor('{s1['id']}')")
        clip = await A.evaluate("navigator.clipboard.readText().catch(()=>'')")
        ok('link público criado, com mapa e vídeo, e copiado', s1['ready'] and 'map' in s1['files'] and 'video' in s1['files'] and clip == lnk, (s1.get('files'), clip[:60]))
        cC = await newctx(b, mock=True); C = await cC.new_page(); C.errs = []; C.on('pageerror', lambda e: C.errs.append(str(e)))
        await C.goto(lnk); await C.wait_for_timeout(4000)
        v = await C.evaluate("({W:Studio.W, ro:document.body.classList.contains('ro'), title:document.querySelector('#roTitle').textContent, objs:Studio.p.objects.length, img:!!Studio.bgImg&&Studio.bgImg.naturalWidth, vid:[...document.querySelectorAll('.topbar button')].some(b=>/vídeo/.test(b.textContent)), nprojects:0})")
        await C.screenshot(path=f'{T}/v4_viewer.png')
        ok('visitante sem login abre o link: somente leitura, mapa, marcações e vídeo', v['W'] > 300 and v['ro'] and v['objs'] >= 3 and v['img'] and v['vid'], v)
        ok('visitante não grava nada no aparelho', await C.evaluate("DB.all('projects').then(l=>l.length)") == 0)
        await C.evaluate("Studio.setTool && (Studio.tool='pen')"); bb = await C.locator('#stage').bounding_box(); n0 = await C.evaluate("Studio.p.objects.length")
        await C.mouse.move(bb['x'] + 100, bb['y'] + 100); await C.mouse.down(); await C.mouse.move(bb['x'] + 200, bb['y'] + 200, steps=4); await C.mouse.up()
        ok('modo somente leitura impede edição', await C.evaluate("Studio.p.objects.length") == n0)
        await A.click('#mbox [data-x]') if await A.evaluate("document.querySelector('#modal').classList.contains('on')") else None
        await A.click('#bSharePng'); await A.click('#shLink'); await A.wait_for_timeout(600)
        await A.select_option('#shVis', 'emails'); await A.fill('#shEm', 'coach@time.com'); await A.click('#shCreate'); await A.wait_for_timeout(2500)
        shares = await A.evaluate("Cloud.be.shareList(Cloud.user.uid)"); s2 = [s for s in shares if s['visibility'] == 'emails'][0]
        await C.goto(await A.evaluate(f"Cloud.linkFor('{s2['id']}')")); await C.wait_for_timeout(3000)
        ok('link restrito exige login do e-mail autorizado', 'Acesso restrito' in await C.inner_text('#mbox') and await C.locator('#slE').count() == 1)
        st0 = await A.evaluate("fetch('http://127.0.0.1:8790/admin/state').then(r=>r.json())")
        await close_modals(A); await A.evaluate(f"Cloud.revoke((await Cloud.be.shareList(Cloud.user.uid)).find(s=>s.id==='{s1['id']}'))") if False else await A.evaluate(f"(async()=>{{const l=await Cloud.be.shareList(Cloud.user.uid); await Cloud.revoke(l.find(s=>s.id==='{s1['id']}'));}})()")
        await A.wait_for_timeout(800); st1 = await A.evaluate("fetch('http://127.0.0.1:8790/admin/state').then(r=>r.json())")
        await C.goto(lnk); await C.wait_for_timeout(3000)
        ok('revogar: link deixa de abrir e arquivos públicos são apagados', 'revogado' in await C.inner_text('#mbox') and not any(f.startswith(f"public/{s1['id']}/") for f in st1['files']) and any(f.startswith(f"public/{s1['id']}/") for f in st0['files']), (await C.inner_text('#mbox'))[:80])
        ok('nuvem sem erros de página', not A.errs and not B.errs and not C.errs, (A.errs[:2], B.errs[:2], C.errs[:2]))
        await A.evaluate("go('estudio')"); await A.wait_for_timeout(500); await A.screenshot(path=f'{T}/v4_desk_studio.png')
        await A.evaluate("go('config')"); await A.wait_for_timeout(700); await A.screenshot(path=f'{T}/v4_desk_config.png', full_page=True)
        # ================= 7. INTERFACE, ACESSIBILIDADE, ESTABILIDADE =================
        unnamed = await A.evaluate("""(async()=>{const out={}; for(const [id] of VIEWS){ go(id); await new Promise(r=>setTimeout(r,350));
          const bs=[...document.querySelectorAll('#v-'+id+' button, #nav button')].filter(b=>b.offsetParent && !(b.textContent.trim()||b.getAttribute('aria-label')||b.title)); if(bs.length) out[id]=bs.map(b=>b.outerHTML.slice(0,80)); } return out})()""")
        ok('acessibilidade: todos os botões visíveis têm nome acessível', not unnamed, unnamed)
        monkey = await A.evaluate("""(async()=>{ const errs=[]; window.addEventListener('error',e=>errs.push(e.message)); let n=0;
          const skip=/fbOut|fbForget|rcStart|bRecOpen|hRec|fbIn|fbUp|fbG|fbRs|mgGo|shCreate|cfPers|cfInst|veExp|veNar|psNew|bNew|resX|liDel|mDel|vdDel/;
          for(const [id] of VIEWS){ go(id); await new Promise(r=>setTimeout(r,400));
            const bs=[...document.querySelectorAll('#v-'+id+' button')].filter(b=>b.offsetParent && !b.disabled && !skip.test(b.id) && !/Excluir|Revogar|Limpar|Remover|Sair|Desfazer/.test(b.textContent));
            for(const b of bs.slice(0,40)){ try{ b.click(); n++; }catch(e){errs.push(id+': '+e.message)} await new Promise(r=>setTimeout(r,120));
              for(let i=0;i<3&&document.querySelector('#modal').classList.contains('on');i++){ const x=document.querySelector('#mbox [data-x]'); x?x.click():Modal.close(); await new Promise(r=>setTimeout(r,60)); } } }
          return {n, errs} })()""")
        await A.wait_for_timeout(1000)
        ok(f"teste de todos os botões ({monkey['n']} cliques em {await A.evaluate('VIEWS.length')} módulos) sem erro", not monkey['errs'] and not A.errs, (monkey['errs'][:5], A.errs[:5]))
        M = await newpage(await newctx(b, mobile=True))
        await M.evaluate("go('inicio')"); await M.click('#mobMore'); nb = await M.locator('#mbox [data-go]').count()
        await M.click('#mbox [data-go="relatorios"]'); await M.wait_for_timeout(300)
        ok('mobile: menu "Mais" dá acesso a todos os módulos', nb == 7 and await M.evaluate("currentView") == 'relatorios', nb)
        await M.evaluate("go('estudio')"); await M.wait_for_timeout(500)
        vis1 = await M.evaluate("[...document.querySelectorAll('#tools .tool')].filter(b=>b.offsetParent).map(b=>b.dataset.tool)")
        await M.click('[data-tg="2"]'); vis2 = await M.evaluate("[...document.querySelectorAll('#tools .tool')].filter(b=>b.offsetParent).map(b=>b.dataset.tool)")
        ok('mobile: ferramentas organizadas por grupo', 'pen' in vis1 and 'zsafe' not in vis1 and 'zsafe' in vis2 and 'pen' not in vis2, (vis1, vis2))
        await M.click('[data-tg="1"]'); await M.screenshot(path=f'{T}/v4_mob_studio.png')
        await M.evaluate("go('inicio')"); await M.wait_for_timeout(300); await M.click('#mobMore'); await M.wait_for_timeout(200); await M.screenshot(path=f'{T}/v4_mob_more.png')
        perf = await M.evaluate("({dcl:Math.round(performance.getEntriesByType('navigation')[0].domContentLoadedEventEnd), load:Math.round(performance.getEntriesByType('navigation')[0].loadEventEnd), heap:performance.memory?Math.round(performance.memory.usedJSHeapSize/1048576):null})")
        ok('desempenho medido (carregamento e memória)', perf['dcl'] > 0, perf); print('   PERF', perf)
        ok('mobile sem erros', not M.errs, M.errs[:3])
        await b.close()
    srv.terminate(); cloud.terminate()
    f = [r for r in R if not r[1]]; print(f'\n{len(R) - len(f)}/{len(R)} passaram')
    for r in f: print('FALHOU:', r[0], '|', str(r[2])[:300])
    json.dump([{'teste': n, 'ok': o} for n, o, _ in R], open(f'{T}/resultado_v4.json', 'w'), ensure_ascii=False, indent=1)

async def p_v1(c):
    p = await c.new_page(); p.errs = []; p.on('pageerror', lambda e: p.errs.append(str(e)))
    await p.goto(URL); await p.wait_for_timeout(1500); return p
asyncio.run(main())
