module.exports = [{
  files: ['**/*.js'],
  languageOptions: { ecmaVersion: 2022, sourceType: 'script', globals: {
    window: 'readonly', document: 'readonly', navigator: 'readonly', location: 'readonly', history: 'readonly', console: 'readonly', setTimeout: 'readonly', clearTimeout: 'readonly', setInterval: 'readonly', clearInterval: 'readonly',
    requestAnimationFrame: 'readonly', cancelAnimationFrame: 'readonly', performance: 'readonly', indexedDB: 'readonly', localStorage: 'readonly', URL: 'readonly', URLSearchParams: 'readonly', Blob: 'readonly', File: 'readonly', FileReader: 'readonly',
    Image: 'readonly', HTMLCanvasElement: 'readonly', MediaRecorder: 'readonly', MediaStream: 'readonly', ResizeObserver: 'readonly', matchMedia: 'readonly', fetch: 'readonly', atob: 'readonly', btoa: 'readonly', Response: 'readonly',
    caches: 'readonly', self: 'readonly', importScripts: 'readonly', Uint8Array: 'readonly', getComputedStyle: 'readonly' } },
  rules: { 'no-undef': 'error', 'no-dupe-keys': 'error', 'no-unreachable': 'error', 'no-redeclare': 'error', 'no-unused-vars': ['warn', { args: 'none', varsIgnorePattern: '^(Views|FB_VER)$' }], 'no-const-assign': 'error', 'no-self-assign': 'error', 'no-dupe-else-if': 'error', 'no-unsafe-finally': 'error' }
}];
