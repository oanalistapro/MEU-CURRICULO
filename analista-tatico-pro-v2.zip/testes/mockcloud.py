# Nuvem simulada para testes: imita a semântica usada do Firebase (auth, transação com rev, consultas por serverTime,
# Storage e regras de acesso de shares). NÃO é o Firebase real.
import json, time, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
S = {'users': {}, 'items': {}, 'shares': {}, 'files': {}, 'clock': 0, 'log': []}
L = threading.Lock()
def now():
    S['clock'] = max(S['clock'] + 1, int(time.time() * 1000)); return S['clock']
def can_view(s, uid):
    u = S['users'].get(uid) if uid else None
    if uid and s['owner'] == uid: return True
    if s['revoked']: return False
    if s.get('expiresAt') and s['expiresAt'] < time.time() * 1000: return False
    if s['visibility'] == 'public': return True
    return bool(u and u.get('verified') and u['email'].lower() in s['emails'])
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def cors(self):
        self.send_header('Access-Control-Allow-Origin', '*'); self.send_header('Access-Control-Allow-Headers', '*'); self.send_header('Access-Control-Allow-Methods', '*')
    def do_OPTIONS(self): self.send_response(204); self.cors(); self.end_headers()
    def out(self, code, obj=None, raw=None, ct='application/json'):
        self.send_response(code); self.cors(); self.send_header('Content-Type', ct); self.end_headers()
        self.wfile.write(raw if raw is not None else json.dumps(obj).encode())
    def body(self):
        n = int(self.headers.get('Content-Length', 0)); return self.rfile.read(n) if n else b''
    def uid(self, q): return self.headers.get('X-Uid') or (q.get('auth', [None])[0])
    def deny(self): self.out(403, {'code': 'permission-denied', 'message': 'Missing or insufficient permissions.'})
    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query); uid = self.uid(q)
        with L:
            if u.path == '/since':
                if q['uid'][0] != uid: return self.deny()
                t = int(float(q['t'][0])); docs = [dict(d, key=k) for (o, k), d in S['items'].items() if o == uid and d['serverTime'] > t]
                return self.out(200, docs)
            if u.path == '/share/get':
                s = S['shares'].get(q['id'][0])
                if not s: return self.out(200, None)
                if not can_view(s, uid): return self.deny()
                return self.out(200, s)
            if u.path == '/share/list':
                if q['uid'][0] != uid: return self.deny()
                return self.out(200, [s for s in S['shares'].values() if s['owner'] == uid])
            if u.path == '/st':
                p = q['path'][0]; f = S['files'].get(p)
                if p.startswith('users/') and p.split('/')[1] != uid: return self.deny()
                if p.startswith('public/'):
                    s = S['shares'].get(p.split('/')[1])
                    if not s or not can_view(s, uid): return self.deny()
                if not f: return self.out(404, {'code': 'storage/object-not-found'})
                return self.out(200, raw=f[1], ct=f[0])
            if u.path == '/admin/state': return self.out(200, {'items': len(S['items']), 'shares': len(S['shares']), 'files': list(S['files'].keys()), 'log': S['log'][-50:]})
        self.out(404, {})
    def do_DELETE(self):
        u = urlparse(self.path); q = parse_qs(u.query); uid = self.uid(q); p = q['path'][0]
        with L:
            if p.startswith('users/') and p.split('/')[1] != uid: return self.deny()
            if p.startswith('public/') and S['shares'].get(p.split('/')[1], {}).get('owner') != uid: return self.deny()
            S['files'].pop(p, None); self.out(200, {})
    def do_PUT(self):
        u = urlparse(self.path); q = parse_qs(u.query); uid = self.uid(q); p = q['path'][0]; b = self.body()
        with L:
            if p.startswith('users/') and p.split('/')[1] != uid: return self.deny()
            if p.startswith('public/'):
                s = S['shares'].get(p.split('/')[1])
                if not s or s['owner'] != uid or s['revoked'] or p.split('/')[2] not in ('map', 'video', 'project.json'): return self.deny()
            S['files'][p] = (self.headers.get('Content-Type', 'application/octet-stream'), b); self.out(200, {})
    def do_POST(self):
        u = urlparse(self.path); q = parse_qs(u.query); uid = self.uid(q); j = json.loads(self.body() or b'{}')
        with L:
            if u.path == '/auth/signup':
                if any(x['email'] == j['email'] for x in S['users'].values()): return self.out(400, {'code': 'auth/email-already-in-use'})
                if len(j['pw']) < 6: return self.out(400, {'code': 'auth/weak-password'})
                nid = 'u%d' % (len(S['users']) + 1); S['users'][nid] = {'email': j['email'], 'pw': j['pw'], 'verified': True}; return self.out(200, {'uid': nid, 'email': j['email']})
            if u.path == '/auth/signin':
                for k, x in S['users'].items():
                    if x['email'] == j['email'] and x['pw'] == j['pw']: return self.out(200, {'uid': k, 'email': x['email']})
                return self.out(400, {'code': 'auth/invalid-credential'})
            if u.path == '/tx':
                if j['uid'] != uid: return self.deny()
                k = (uid, j['key']); cur = S['items'].get(k); rev = cur['rev'] if cur else 0
                if rev != j['expected']: return self.out(200, {'ok': False, 'remote': dict(cur, key=j['key']) if cur else None})
                pl = j['payload']
                if set(pl) - {'store', 'id', 'deviceId', 'deleted', 'json', 'storagePath', 'size'}: return self.deny()
                if j['key'] != pl['store'] + '~' + pl['id']: return self.deny()
                S['items'][k] = dict(pl, rev=rev + 1, serverTime=now()); S['log'].append(('tx', j['key'], rev + 1)); return self.out(200, {'ok': True, 'rev': rev + 1})
            if u.path == '/share/create':
                if j.get('owner') != uid or j.get('revoked') is not False: return self.deny()
                sid = 's%d' % (len(S['shares']) + 1); S['shares'][sid] = dict(j, id=sid, createdAt=now()); return self.out(200, {'id': sid})
            if u.path == '/share/update':
                s = S['shares'].get(j['id'])
                if not s or s['owner'] != uid: return self.deny()
                if s['revoked'] and j['patch'].get('revoked') is False: return self.deny()
                if 'owner' in j['patch'] and j['patch']['owner'] != uid: return self.deny()
                s.update(j['patch']); return self.out(200, {})
        self.out(404, {})
ThreadingHTTPServer(('127.0.0.1', 8790), H).serve_forever()
