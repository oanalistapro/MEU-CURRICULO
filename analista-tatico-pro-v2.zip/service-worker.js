/* ANALISTA TÁTICO PRO — service worker
   Rede primeiro (recebe atualizações), cache como reserva offline.
   Os dados do usuário ficam no IndexedDB e NÃO são tocados por atualizações. */
const CACHE = 'atp-shell-v2.0.0';
const SHELL = ['./', './index.html', './css/app.css', './js/app.js', './firebase-config.js', './manifest.json',
  './icons/icon.svg', './icons/icon-192.png', './icons/icon-512.png', './icons/maskable-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('atp-shell-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin) return; // Firebase e CDNs não passam pelo cache
  const key = r.mode === 'navigate' ? './index.html' : r;
  e.respondWith(fetch(r).then(res => {
    if (res.ok && res.type === 'basic') { const c = res.clone(); caches.open(CACHE).then(x => x.put(key, c)); }
    return res;
  }).catch(() => caches.match(key, { ignoreSearch: true }).then(hit => hit || (r.mode === 'navigate' ? caches.match('./index.html') : Response.error()))));
});
