importScripts('./service-worker.js'); // compatibilidade com instalações da v1
