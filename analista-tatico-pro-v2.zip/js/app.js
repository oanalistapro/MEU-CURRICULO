/* ANALISTA TÁTICO PRO — app.js (gerado) */
'use strict';
/* ==========================================================
   ANALISTA TÁTICO PRO — núcleo: utilidades, IndexedDB, navegação
   ========================================================== */
const APP_VERSION = '2.0.0';
const BACKUP_FORMAT = 2; // versão do formato de backup
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const fmtT = s => { s = Math.max(0, s || 0); const m = Math.floor(s / 60), x = Math.floor(s % 60); return String(m).padStart(2, '0') + ':' + String(x).padStart(2, '0'); };
const fmtDate = t => t ? new Date(t).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '—';
const fmtBytes = b => b > 1e9 ? (b / 1e9).toFixed(2) + ' GB' : b > 1e6 ? (b / 1e6).toFixed(1) + ' MB' : (b / 1e3).toFixed(0) + ' KB';
const deep = o => JSON.parse(JSON.stringify(o));

function toast(msg, err) {
  const d = document.createElement('div'); d.textContent = msg; if (err) d.className = 'e';
  $('#toast').appendChild(d); setTimeout(() => d.remove(), err ? 5200 : 2800);
}
window.addEventListener('error', e => { console.error(e.error || e.message); toast('Erro: ' + (e.message || 'inesperado'), true); });
window.addEventListener('unhandledrejection', e => { console.error(e.reason); toast('Erro: ' + (e.reason?.message || e.reason), true); });

/* ---------- Modal (substitui alert/confirm/prompt) ---------- */
const Modal = {
  open(html, onMount) { this.prev = document.activeElement; $('#mbox').innerHTML = html; $('#modal').classList.add('on'); onMount && onMount($('#mbox')); const f = $('#mbox').querySelector('input,select,textarea,button'); f && f.focus({ preventScroll: true }); },
  close() { $('#modal').classList.remove('on'); $('#mbox').innerHTML = ''; this.prev?.focus?.({ preventScroll: true }); },
  confirm(msg, okLabel = 'Confirmar', danger) {
    return new Promise(res => {
      Modal.open(`<p>${esc(msg)}</p><div class="row" style="justify-content:flex-end"><button class="btn" data-x>Cancelar</button>
        <button class="btn ${danger ? 'red' : 'pri'}" data-ok>${esc(okLabel)}</button></div>`, b => {
        b.querySelector('[data-x]').onclick = () => { Modal.close(); res(false); };
        b.querySelector('[data-ok]').onclick = () => { Modal.close(); res(true); };
      });
    });
  },
  prompt(msg, val = '') {
    return new Promise(res => {
      Modal.open(`<label class="f">${esc(msg)}<input class="in" id="mpIn" value="${esc(val)}"></label>
        <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn" data-x>Cancelar</button><button class="btn pri" data-ok>OK</button></div>`, b => {
        const i = b.querySelector('#mpIn'); i.focus(); i.select();
        const ok = () => { const v = i.value; Modal.close(); res(v); };
        i.onkeydown = e => { if (e.key === 'Enter') ok(); };
        b.querySelector('[data-x]').onclick = () => { Modal.close(); res(null); };
        b.querySelector('[data-ok]').onclick = ok;
      });
    });
  }
};
$('#modal').addEventListener('pointerdown', e => { if (e.target.id === 'modal') Modal.close(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('#modal').classList.contains('on')) { const x = $('#mbox [data-x]'); x ? x.click() : Modal.close(); } });

/* ---------- Seletor de arquivos ---------- */
function pickFile(accept, multiple = false) {
  return new Promise(res => {
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = accept; inp.multiple = multiple;
    inp.onchange = () => res(multiple ? [...inp.files] : inp.files[0] || null);
    inp.click();
  });
}

/* ---------- IndexedDB ---------- */
const DB = {
  db: null, name: 'analista-tatico-pro', ver: 2,
  stores: ['kv', 'maps', 'projects', 'media', 'chars', 'weapons', 'vods', 'matches', 'sync'],
  hooks: [], // observadores de alteração (sincronização em nuvem)
  open() {
    return new Promise((res, rej) => {
      if (!('indexedDB' in window)) return rej(new Error('IndexedDB indisponível neste navegador'));
      const r = indexedDB.open(this.name, this.ver);
      r.onupgradeneeded = () => { // só cria o que falta — nunca apaga dados existentes
        const d = r.result; this.stores.forEach(s => { if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: 'id' }); });
      };
      r.onsuccess = () => { this.db = r.result; this.db.onversionchange = () => { this.db.close(); toast('Nova versão do app aberta em outra aba — recarregue esta página.', true); }; res(); };
      r.onerror = () => rej(r.error);
      r.onblocked = () => toast('Feche outras abas do app para concluir a atualização do banco local.', true);
    });
  },
  tx(store, mode, fn) {
    return new Promise((res, rej) => {
      const t = this.db.transaction(store, mode), s = t.objectStore(store); let out;
      const r = fn(s); if (r) r.onsuccess = () => out = r.result;
      t.oncomplete = () => res(out); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error || new Error('Transação abortada (espaço insuficiente?)'));
    });
  },
  get(s, id) { return this.tx(s, 'readonly', st => st.get(id)); },
  all(s) { return this.tx(s, 'readonly', st => st.getAll()); },
  async put(s, v, o = {}) { const r = await this.tx(s, 'readwrite', st => st.put(v)); if (!o.silent) this.hooks.forEach(h => h(s, v.id, 'put')); return r; },
  async del(s, id, o = {}) { const r = await this.tx(s, 'readwrite', st => st.delete(id)); if (!o.silent) this.hooks.forEach(h => h(s, id, 'del')); return r; },
  async kv(k, v) { if (v === undefined) return (await this.get('kv', k))?.v; return this.put('kv', { id: k, v }); }
};

/* ---------- JSON seguro e sanitização (backups, projetos, nuvem) ---------- */
const BAD_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
function safeParse(text) { return JSON.parse(text, (k, v) => BAD_KEYS.has(k) ? undefined : v); }
function sanitize(v, depth = 0) {
  if (depth > 24) throw new Error('estrutura aninhada demais');
  if (v === null) return null;
  if (typeof v === 'string') return v.length > 200000 && !v.startsWith('data:') ? v.slice(0, 200000) : v;
  if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
  if (typeof v === 'boolean') return v;
  if (Array.isArray(v)) { if (v.length > 500000) throw new Error('lista grande demais'); return v.map(x => sanitize(x, depth + 1)); }
  if (typeof v === 'object') { const o = {}; for (const [k, x] of Object.entries(v)) { if (BAD_KEYS.has(k) || x === undefined || typeof x === 'function') continue; o[String(k).slice(0, 200)] = sanitize(x, depth + 1); } return o; }
  return undefined;
}
const SCHEMA = { // validação estrutural mínima por coleção
  projects: { id: 'string', name: 'string', mapId: 'string', objects: 'array', players: 'array', keyframes: 'object' },
  maps: { id: 'string', name: 'string', versions: 'array', regions: 'array' },
  chars: { id: 'string', name: 'string' }, weapons: { id: 'string', name: 'string' },
  matches: { id: 'string', date: 'number' }, vods: { id: 'string', name: 'string', annotations: 'array' },
  media: { id: 'string', kind: 'string' }, kv: { id: 'string' }
};
function validateRecord(store, r) {
  const sc = SCHEMA[store]; if (!sc) return 'coleção desconhecida';
  if (!r || typeof r !== 'object' || Array.isArray(r)) return 'registro não é um objeto';
  for (const [k, t] of Object.entries(sc)) {
    const v = r[k], ok = t === 'array' ? Array.isArray(v) : t === 'object' ? v && typeof v === 'object' && !Array.isArray(v) : typeof v === t;
    if (!ok) return `campo "${k}" ausente ou inválido`;
  }
  if (typeof r.id === 'string' && (r.id.length > 200 || /[\/\u0000]/.test(r.id))) return 'identificador inválido';
  if (store === 'projects' && r.players.length !== 4) return 'projeto deve ter 4 jogadores';
  if (store === 'media' && r.blob != null && !(typeof r.blob === 'string' && /^data:(image|video|audio)\/[\w.+-]+(;[\w=.+-]+)*;base64,/.test(r.blob))) return 'mídia com formato não permitido';
  return null;
}
/* ---------- Download / compartilhamento ---------- */
function download(blob, name) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 30000);
}
async function shareFile(blob, name, title = 'ANALISTA TÁTICO PRO') {
  const file = new File([blob], name, { type: blob.type });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try { await navigator.share({ files: [file], title, text: title }); return true; }
    catch (e) { if (e.name === 'AbortError') return false; toast('Compartilhamento falhou: ' + e.message, true); }
  } else toast('Este navegador não compartilha arquivos. O arquivo foi baixado — envie pelo WhatsApp/Discord/Telegram.', true);
  download(blob, name); return false;
}

/* ---------- Navegação ---------- */
const ICON = {
  home: 'M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z',
  map: 'M9 3L3 6v15l6-3 6 3 6-3V3l-6 3-6-3zM9 3v15M15 6v15',
  studio: 'M4 20l4-1 11-11-3-3L5 16l-1 4zM14 6l3 3',
  video: 'M3 6h12v12H3zM15 10l6-4v12l-6-4',
  vod: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM10 8l6 4-6 4z',
  drop: 'M12 2v13M7 10l5 5 5-5M4 21h16',
  user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
  gun: 'M2 9h16l3 2v2h-6l-1 4h-4l1-4H2z',
  book: 'M4 4h11a3 3 0 0 1 3 3v13H7a3 3 0 0 1-3-3zM18 20h2V7',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19 12l2-1-2-4-2 1-2-2V4h-4v2L9 8 7 7 5 11l2 1v0l-2 1 2 4 2-1 2 2v2h4v-2l2-2 2 1 2-4z'
};
const svgI = p => `<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="${p}"/></svg>`;
const VIEWS = [
  ['inicio', 'Início', 'home'], ['mapas', 'Mapas', 'map'], ['estudio', 'Estúdio Tático', 'studio'],
  ['video', 'Editor de Vídeo', 'video'], ['vod', 'Análise de Partidas', 'vod'], ['queda', 'Queda & Economia', 'drop'],
  ['personagens', 'Personagens', 'user'], ['armas', 'Armas', 'gun'], ['estrategias', 'Estratégias & Projetos', 'book'],
  ['relatorios', 'Relatórios', 'chart'], ['config', 'Configurações', 'gear']
];
const Views = {}; // cada módulo registra {render()}
let currentView = 'inicio';
const MOB_MAIN = ['inicio', 'mapas', 'estudio', 'video'];
function buildNav() {
  $('#nav').innerHTML = VIEWS.map(([id, n, i]) => `<button data-v="${id}">${svgI(ICON[i])}<span>${n}</span></button>`).join('');
  $('#mobnav').innerHTML = VIEWS.filter(v => MOB_MAIN.includes(v[0])).map(([id, n, i]) => `<button data-v="${id}">${svgI(ICON[i])}<span>${n.split(' ')[0]}</span></button>`).join('')
    + `<button id="mobMore" aria-label="Mais módulos">${svgI('M4 6h16M4 12h16M4 18h16')}<span>Mais</span></button>`;
  $$('[data-v]').forEach(b => b.onclick = () => go(b.dataset.v));
  $('#mobMore').onclick = () => Modal.open(`<h3>Módulos</h3><div class="grid" style="grid-template-columns:1fr 1fr;gap:8px">${VIEWS.filter(v => !MOB_MAIN.includes(v[0])).map(([id, n, i]) => `<button class="btn" data-go="${id}" style="justify-content:flex-start;padding:12px">${svgI(ICON[i])}${n}</button>`).join('')}</div>
    <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn" data-x>Fechar</button></div>`, b => {
    b.querySelector('[data-x]').onclick = () => Modal.close(); $$('[data-go]', b).forEach(x => x.onclick = () => { Modal.close(); go(x.dataset.go); });
  });
}
function go(id) {
  if (!Views[id]) id = 'inicio';
  currentView = id;
  $$('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + id));
  $$('[data-v]').forEach(b => { b.classList.toggle('on', b.dataset.v === id); b.toggleAttribute('aria-current', b.dataset.v === id); });
  $('#mobMore')?.classList.toggle('on', !MOB_MAIN.includes(id));
  if (location.hash !== '#' + id) history.replaceState(null, '', '#' + id);
  try { Views[id].render && Views[id].render(); } catch (e) { console.error(e); toast('Falha ao abrir módulo: ' + e.message, true); }
}
window.addEventListener('hashchange', () => { const h = location.hash.slice(1); if (h && h !== currentView) go(h); });

/* ---------- Configurações globais ---------- */
const Settings = {
  data: { gameVersion: '', metersPerUnit: 0, speedFoot: 0, speedVehicle: 0, team: '', recFps: 30, recQuality: 'alta', strictVersion: false, autoSave: true, maxMapPx: 4096 },
  async load() { const s = await DB.kv('settings'); if (s) Object.assign(this.data, s); },
  save() { return DB.kv('settings', this.data); }
};
/* ==========================================================
   BIBLIOTECA DE MAPAS
   Nenhuma imagem oficial é embutida: os arquivos precisam ser
   importados pelo analista (fonte autorizada). Enquanto isso o
   mapa fica marcado como PENDENTE e o editor usa uma grade tática.
   ========================================================== */
const BUILTIN_MAPS = [
  { id: 'bermuda', name: 'Bermuda' }, { id: 'purgatorio', name: 'Purgatório' }, { id: 'kalahari', name: 'Kalahari' },
  { id: 'novaterra', name: 'Nova Terra (Nexterra)' }, { id: 'solara', name: 'Solara' },
  { id: 'alpine', name: 'Alpine (histórico)' }, { id: 'bermuda-remaster', name: 'Bermuda Remasterizado' }
];
const Maps = {
  list: [], imgCache: {},
  async load() {
    const saved = await DB.all('maps');
    for (const b of BUILTIN_MAPS) if (!saved.find(m => m.id === b.id)) {
      const m = { id: b.id, name: b.name, builtin: true, versions: [], active: null, regions: [], created: 0 };
      await DB.put('maps', m); saved.push(m);
    }
    // migração v1→v2: regiões passam a usar coordenadas normalizadas (0–1), estáveis entre versões do mapa
    for (const m of saved) if (m.regions.some(r => r.nx == null)) {
      const v = this.activeVersion(m), w = v?.w || 2000, h = v?.h || 2000;
      m.regions = m.regions.map(r => r.nx == null ? { id: r.id || uid(), name: r.name, nx: r.x / w, ny: r.y / h } : r);
      await DB.put('maps', m, { silent: true });
    }
    this.list = saved.sort((a, b) => (b.builtin - a.builtin) || a.name.localeCompare(b.name));
  },
  get(id) { return this.list.find(m => m.id === id); },
  activeVersion(m) { return m && m.versions.find(v => v.vid === m.active); },
  status(m) { return m.versions.length ? 'ok' : 'pendente'; },
  async image(m) { // retorna HTMLImageElement da versão ativa ou null
    const v = this.activeVersion(m); if (!v) return null;
    if (this.imgCache[v.mediaId]) return this.imgCache[v.mediaId];
    const rec = await DB.get('media', v.mediaId); if (!rec) return null;
    const img = new Image(); img.src = URL.createObjectURL(rec.blob);
    await img.decode().catch(() => { });
    this.imgCache[v.mediaId] = img; return img;
  },
  async importImage(m, file) {
    let f = file || await pickFile('image/*'); if (!f) return;
    if (!f.type.startsWith('image/')) return toast('Arquivo não é uma imagem.', true);
    if (f.size > 80e6) return toast('Imagem acima de 80 MB — reduza antes de importar.', true);
    const label = await Modal.prompt('Identificação desta versão do mapa (ex.: temporada / atualização do jogo):', Settings.data.gameVersion || '');
    if (label === null) return;
    let img = new Image(); img.src = URL.createObjectURL(f);
    try { await img.decode(); } catch { return toast('Não foi possível ler a imagem (formato não suportado?).', true); }
    const max = Settings.data.maxMapPx || 4096, big = Math.max(img.naturalWidth, img.naturalHeight);
    if (big > max) { // reduz imagens enormes para economizar memória (principalmente em celulares)
      const k = max / big, c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(img.src);
      const b = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.92)); if (!b) return toast('Falha ao processar a imagem.', true);
      f = new File([b], f.name.replace(/\.[^.]+$/, '') + '.jpg', { type: 'image/jpeg' }); img = new Image(); img.src = URL.createObjectURL(f); await img.decode();
      toast(`Imagem reduzida de ${big}px para ${max}px (limite em Configurações).`);
    }
    const mediaId = 'mapimg-' + uid();
    await DB.put('media', { id: mediaId, kind: 'mapimg', name: f.name, blob: f, mime: f.type, size: f.size, date: Date.now() });
    const v = { vid: uid(), label: label || f.name, mediaId, w: img.naturalWidth, h: img.naturalHeight, file: f.name, date: Date.now() };
    m.versions.push(v); m.active = v.vid; m.updated = Date.now();
    this.imgCache[mediaId] = img;
    await DB.put('maps', m); toast(`Mapa ${m.name} importado (${v.w}×${v.h}px) e salvo para uso offline.`);
    Views.mapas.render();
  },
  async newCustom() {
    const name = await Modal.prompt('Nome do mapa personalizado:'); if (!name) return;
    const m = { id: 'custom-' + uid(), name, builtin: false, versions: [], active: null, regions: [], created: Date.now() };
    await DB.put('maps', m); this.list.push(m); await this.importImage(m); Views.mapas.render();
  },
  async removeVersion(m, vid) {
    const v = m.versions.find(x => x.vid === vid); if (!v) return;
    if (!await Modal.confirm(`Remover a versão "${v.label}" do mapa ${m.name}? A imagem será apagada deste aparelho.`, 'Remover', true)) return;
    m.versions = m.versions.filter(x => x.vid !== vid); await DB.del('media', v.mediaId);
    if (m.active === vid) m.active = m.versions.at(-1)?.vid || null;
    await DB.put('maps', m); Views.mapas.render();
  },
  async removeCustom(m) {
    if (m.builtin) return;
    if (!await Modal.confirm(`Excluir o mapa personalizado "${m.name}" e suas imagens? Projetos que usam este mapa continuarão salvos.`, 'Excluir', true)) return;
    for (const v of m.versions) await DB.del('media', v.mediaId);
    await DB.del('maps', m.id); this.list = this.list.filter(x => x.id !== m.id); Views.mapas.render();
  }
};

Views.mapas = {
  regions(m) {
    const draw = () => Modal.open(`<h3>Regiões — ${esc(m.name)}</h3><p class="small muted">Cadastre os nomes oficiais das regiões (lista por mapa). Itens sem posição aparecem para escolha na ferramenta Região do Estúdio. Você também pode exportar/importar a lista para compartilhar com outro analista.</p>
      <div class="row"><input class="in" id="rgN" placeholder="Nome da região" style="flex:1"><button class="btn pri" id="rgA">Adicionar</button></div>
      <div style="max-height:40vh;overflow:auto;margin-top:8px">${m.regions.map(r => `<div class="row pcard small"><b>${esc(r.name)}</b><span class="tag ${r.nx == null ? 'warn' : 'ok'}">${r.nx == null ? 'sem posição' : 'posicionada'}</span><span class="sp"></span><button class="btn sm" data-rd="${r.id}" aria-label="Remover ${esc(r.name)}">✕</button></div>`).join('') || '<div class="empty small">Nenhuma região.</div>'}</div>
      <div class="row" style="margin-top:10px"><button class="btn sm" id="rgE">Exportar lista</button><button class="btn sm" id="rgI">Importar lista</button><span class="sp"></span><button class="btn" data-x>Fechar</button></div>`, b => {
      const save = async () => { await DB.put('maps', m); draw(); Studio.dirty = true; };
      b.querySelector('[data-x]').onclick = () => { Modal.close(); this.render(); };
      const add = () => { const n = $('#rgN').value.trim().slice(0, 80); if (!n) return; m.regions.push({ id: uid(), name: n, nx: null, ny: null }); save(); };
      $('#rgA').onclick = add; $('#rgN').onkeydown = e => e.key === 'Enter' && add();
      $$('[data-rd]', b).forEach(x => x.onclick = () => { m.regions = m.regions.filter(r => r.id !== x.dataset.rd); save(); });
      $('#rgE').onclick = () => download(new Blob([JSON.stringify({ app: 'analista-tatico-pro', type: 'regions', map: m.name, regions: m.regions.map(r => ({ name: r.name, nx: r.nx, ny: r.ny })) }, null, 1)], { type: 'application/json' }), `regioes_${m.id}.json`);
      $('#rgI').onclick = async () => { const f = await pickFile('.json,application/json'); if (!f) return;
        try { if (f.size > 2e6) throw new Error('arquivo grande demais'); const j = sanitize(safeParse(await f.text())); if (j.type !== 'regions' || !Array.isArray(j.regions)) throw new Error('não é uma lista de regiões');
          let n = 0; for (const r of j.regions.slice(0, 500)) { if (typeof r.name !== 'string' || !r.name.trim()) continue; if (m.regions.some(x => x.name.toLowerCase() === r.name.trim().toLowerCase())) continue;
            const ok = typeof r.nx === 'number' && typeof r.ny === 'number' && r.nx >= 0 && r.nx <= 1 && r.ny >= 0 && r.ny <= 1; m.regions.push({ id: uid(), name: r.name.trim().slice(0, 80), nx: ok ? r.nx : null, ny: ok ? r.ny : null }); n++; }
          toast(n + ' região(ões) importada(s).'); save(); } catch (e) { toast('Lista inválida: ' + e.message, true); } };
    });
    draw();
  },
  async render() {
    const el = $('#v-mapas');
    const cards = [];
    for (const m of Maps.list) {
      const v = Maps.activeVersion(m); let thumb = '';
      if (v) { const img = await Maps.image(m); if (img) thumb = `style="background-image:url('${img.src}')"`; }
      cards.push(`<div class="glass card">
        <div class="mapthumb" ${thumb}>${v ? '' : 'Imagem pendente'}</div>
        <div class="row"><b>${esc(m.name)}</b><span class="sp"></span>${v ? '<span class="tag ok">Offline ✓</span>' : '<span class="tag warn">Pendente</span>'}</div>
        <div class="small muted" style="margin:6px 0">${v ? `Versão ativa: ${esc(v.label)} · ${v.w}×${v.h}px · ${m.regions.length} regiões nomeadas` : 'Arquivo oficial não incluído. Importe uma imagem de fonte autorizada.'}</div>
        ${m.versions.length > 1 ? `<select class="in" data-ver="${m.id}" style="width:100%;margin-bottom:6px">${m.versions.map(x => `<option value="${x.vid}" ${x.vid === m.active ? 'selected' : ''}>${esc(x.label)} — ${fmtDate(x.date)}</option>`).join('')}</select>` : ''}
        <div class="row">
          <button class="btn sm pri" data-open="${m.id}">Abrir no Estúdio</button>
          <button class="btn sm" data-reg="${m.id}">Regiões (${m.regions.length})</button>
          <button class="btn sm" data-imp="${m.id}">${v ? 'Nova versão' : 'Importar imagem'}</button>
          ${v ? `<button class="btn sm" data-rmv="${m.id}">Remover versão</button>` : ''}
          ${m.builtin ? '' : `<button class="btn sm" data-rmm="${m.id}">Excluir</button>`}
        </div></div>`);
    }
    el.innerHTML = `<div class="row" style="margin-bottom:14px"><h2 style="margin:0">Biblioteca de mapas</h2><span class="sp"></span>
      <button class="btn org" id="bCustomMap">+ Mapa personalizado</button></div>
      <div class="glass card small muted" style="margin-bottom:14px">As imagens oficiais dos mapas não acompanham o aplicativo porque não há arquivo com autorização de uso incluído no projeto.
      Importe uma vez a imagem (vista de cima, alta resolução) de uma fonte autorizada: ela fica salva neste aparelho e funciona offline.
      Cada mapa aceita várias versões (temporadas / atualizações) e mantém o histórico. Os nomes das regiões são cadastrados em <b>Regiões</b> e posicionados no Estúdio com a ferramenta <b>Região</b>; posições ficam em coordenadas relativas e continuam alinhadas quando você troca a versão da imagem. Também é possível arrastar a imagem para o cartão do mapa.</div>
      <div class="grid g3">${cards.join('')}</div>`;
    $('#bCustomMap').onclick = () => Maps.newCustom();
    $$('[data-reg]', el).forEach(b => b.onclick = () => this.regions(Maps.get(b.dataset.reg)));
    $$('.glass.card', el).forEach((c, i) => { const m = Maps.list[i]; if (!m) return;
      c.addEventListener('dragover', e => { e.preventDefault(); c.style.borderColor = 'var(--blue)'; });
      c.addEventListener('dragleave', () => c.style.borderColor = '');
      c.addEventListener('drop', e => { e.preventDefault(); c.style.borderColor = ''; const f = e.dataTransfer.files[0]; if (f) Maps.importImage(m, f); }); });
    $$('[data-open]', el).forEach(b => b.onclick = () => { Studio.setMap(b.dataset.open); go('estudio'); });
    $$('[data-imp]', el).forEach(b => b.onclick = () => Maps.importImage(Maps.get(b.dataset.imp)));
    $$('[data-rmv]', el).forEach(b => b.onclick = () => { const m = Maps.get(b.dataset.rmv); Maps.removeVersion(m, m.active); });
    $$('[data-rmm]', el).forEach(b => b.onclick = () => Maps.removeCustom(Maps.get(b.dataset.rmm)));
    $$('[data-ver]', el).forEach(s => s.onchange = async () => { const m = Maps.get(s.dataset.ver); m.active = s.value; await DB.put('maps', m); this.render(); if (Studio.p.mapId === m.id) Studio.setMap(m.id); });
  }
};
/* ==========================================================
   ESTÚDIO TÁTICO — canvas, ferramentas, jogadores, keyframes
   ========================================================== */
const ROLES = [
  { id: 'R1', role: 'Primeiro Rush', color: '#FF4D6A' }, { id: 'R2', role: 'Segundo Rush', color: '#FF8A30' },
  { id: 'GR', role: 'Granadeiro', color: '#FFD23F' }, { id: 'SUP', role: 'Suporte', color: '#3CE6A0' }
];
const COLORS = ['#00C8FF', '#FF8A30', '#FF4D6A', '#3CE6A0', '#FFD23F', '#B98CFF', '#FFFFFF', '#0B0F18'];
// [id, nome, ícone(path), grupo]
const TOOLS = [
  ['select', 'Selecionar / mover', 'M5 3l14 8-6 2-2 6z', 0], ['pan', 'Mover mapa', 'M12 2v20M2 12h20M5 9l-3 3 3 3M19 9l3 3-3 3M9 5l3-3 3 3M9 19l3 3 3-3', 0],
  ['pen', 'Caneta livre', 'M4 20l4-1 11-11-3-3L5 16z', 1], ['line', 'Linha reta', 'M4 20L20 4', 1], ['arrow', 'Seta simples', 'M4 20L20 4M11 4h9v9', 1],
  ['carrow', 'Seta curva', 'M4 20C4 9 12 5 20 5M14 2l6 3-4 5', 1], ['aarrow', 'Seta animada', 'M3 21l3-3M8 16l3-3M13 11l3-3M14 4h6v6', 1],
  ['circle', 'Círculo', 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z', 1], ['rect', 'Retângulo', 'M4 5h16v14H4z', 1],
  ['zdanger', 'Zona de perigo', 'M12 3L2 20h20zM12 10v4M12 17v.5', 2], ['zsafe', 'Zona segura (safe)', 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM8 12l3 3 5-6', 2],
  ['zcontrol', 'Área de controle', 'M4 4h16v16H4zM4 10l6-6M4 16L16 4M8 20L20 8M14 20l6-6', 2],
  ['i-enemy', 'Inimigo', 'M12 2l3 7h7l-6 5 2 8-6-5-6 5 2-8-6-5h7z', 3], ['i-coin', 'Moedas', 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v10M9 9h5a2 2 0 0 1 0 4h-4a2 2 0 0 0 0 4h5', 3],
  ['i-shop', 'Máquina de compras', 'M5 3h14v18H5zM8 7h8v5H8zM10 16h4', 3], ['i-vehicle', 'Veículo', 'M3 13l2-6h14l2 6v5H3zM7 18v2M17 18v2M3 13h18', 3],
  ['i-ice', 'Parede de gelo', 'M3 8h18v8H3zM7 8v8M12 8v8M17 8v8', 3], ['i-cover', 'Ponto de cobertura', 'M12 2l8 4v6c0 5-4 8-8 10-4-2-8-5-8-10V6z', 3],
  ['i-high', 'Ponto elevado', 'M2 20l7-12 4 6 3-4 6 10z', 3],
  ['r-main', 'Rota principal', 'M3 18c4-8 8 2 12-6l6-6', 4], ['r-alt', 'Rota alternativa', 'M3 18c4-8 8 2 12-6l6-6', 4], ['r-emer', 'Rota de emergência', 'M3 18c4-8 8 2 12-6l6-6', 4],
  ['text', 'Texto', 'M5 5h14M12 5v15', 5], ['step', 'Numeração de etapas', 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM10 9l2-1v8', 5],
  ['region', 'Nome de região (do mapa)', 'M12 21s-7-6-7-12a7 7 0 0 1 14 0c0 6-7 12-7 12zM12 7v4', 5],
  ['measure', 'Medir distância / tempo', 'M3 17L17 3l4 4L7 21zM7 13l2 2M10 10l2 2M13 7l2 2', 5],
  ['eraser', 'Borracha', 'M16 3l5 5-11 11H5l-3-3zM9 20h12', 6]
];
const ROUTE_STYLE = { 'r-main': { color: '#00C8FF', dash: [], w: 5 }, 'r-alt': { color: '#FFD23F', dash: [14, 10], w: 4 }, 'r-emer': { color: '#FF4D6A', dash: [4, 8], w: 4 } };
const ICON_COLOR = { 'i-enemy': '#FF4D6A', 'i-coin': '#FFD23F', 'i-shop': '#B98CFF', 'i-vehicle': '#00C8FF', 'i-ice': '#BFEFFF', 'i-cover': '#3CE6A0', 'i-high': '#FF8A30' };
const ICON_LETTER = { 'i-enemy': '✕', 'i-coin': '$', 'i-shop': 'M', 'i-vehicle': 'V', 'i-ice': '▦', 'i-cover': '◆', 'i-high': '▲' };
const TOOL_GROUPS = ['Mover', 'Desenho', 'Zonas', 'Ícones', 'Rotas', 'Texto', 'Apagar'];
const LAYERS = [['safe', 'Safe / Zonas'], ['tatica', 'Tática'], ['notas', 'Anotações']];

function newProject(mapId) {
  return {
    id: uid(), name: 'Nova estratégia', team: Settings.data.team || '', mapId: mapId || 'bermuda', gameVersion: Settings.data.gameVersion || '',
    drop: '', strategy: '', rotations: '', notes: '', objects: [], scenarios: [], measurements: [], loot: '',
    players: ROLES.map(r => ({ id: r.id, role: r.role, color: r.color, name: '', nick: '', char: '', passives: '', primary: '', secondary: '', equip: '', objective: '', notes: '', x: null, y: null, visible: true })),
    keyframes: { R1: [], R2: [], GR: [], SUP: [] }, duration: 20, created: Date.now(), updated: Date.now(), history: [], archived: false, videos: []
  };
}

const Studio = {
  p: null, cv: null, ctx: null, dpr: 1, W: 0, H: 0,
  view: { ox: 0, oy: 0, s: 1 }, world: { w: 2000, h: 2000 }, bgImg: null, bgVideo: null,
  tool: 'select', style: { color: '#00C8FF', width: 4, alpha: 1, dash: 'solid', fs: 22 }, layer: 'tatica', hidden: {},
  undo: [], redo: [], draft: null, sel: null, selPlayer: null, t: 0, playing: false, dirty: true,
  pointers: new Map(), pinch: null, panTab: 'estilo', safePhase: 1, safePredicted: true, cam: null, lastTs: 0, dirtyProject: false,

  init() {
    this.cv = $('#stage'); this.ctx = this.cv.getContext('2d');
    this.p = newProject();
    this.buildTools(); this.bind(); this.resize();
    if (matchMedia('(max-width:860px)').matches) $('#panel').classList.add('closed');
    new ResizeObserver(() => this.resize()).observe($('#stageWrap'));
    requestAnimationFrame(ts => this.loop(ts));
  },
  /* ---------- Projeto ---------- */
  async loadProject(p) {
    this.p = Object.assign(newProject(p.mapId), p);
    ROLES.forEach(r => { if (!this.p.keyframes[r.id]) this.p.keyframes[r.id] = []; });
    this.undo = []; this.redo = []; this.sel = null; this.t = 0; this.dirtyProject = false;
    $('#projName').value = this.p.name; $('#animDur').value = this.p.duration;
    await this.setMap(this.p.mapId, true); this.renderPanel(); this.renderKf();
  },
  async saveProject(silent, auto) {
    if (this.readOnly) return;
    const p = this.p; p.name = ($('#projName').value.trim() || 'Sem nome').slice(0, 120); p.updated = Date.now();
    const snap = deep({ ...p, history: undefined });
    // histórico de versões: salvamento manual sempre cria versão; automático no máximo a cada 5 min
    if (!auto || !p.history?.length || p.updated - p.history[0].date > 300000) p.history = [{ date: p.updated, snap }, ...(p.history || [])].slice(0, 25);
    await DB.put('projects', deep(p)); this.dirtyProject = false;
    await DB.kv('lastProject', p.id); DB.del('kv', 'autosave').catch(() => { });
    if (!silent) toast('Projeto salvo (versão ' + p.history.length + ' no histórico).');
    $('#saveState') && ($('#saveState').textContent = (auto ? 'Salvo automaticamente ' : 'Salvo ') + new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }));
  },
  async setMap(id, keepView) {
    const m = Maps.get(id) || Maps.list[0]; this.p.mapId = m.id;
    this.bgImg = await Maps.image(m); this.stopBgVideo();
    this.world = this.bgImg ? { w: this.bgImg.naturalWidth, h: this.bgImg.naturalHeight } : { w: 2000, h: 2000 };
    // coordenadas persistentes: se a imagem/versão do mapa mudou de resolução, reescala as marcações proporcionalmente
    const ref = this.p.ref;
    if (ref && ref.w && ref.h && (ref.w !== this.world.w || ref.h !== this.world.h)) { this.rescale(this.world.w / ref.w, this.world.h / ref.h); if (!keepView) toast('Marcações ajustadas à nova resolução do mapa.'); }
    this.p.ref = { mapId: m.id, w: this.world.w, h: this.world.h };
    this.p.players.forEach((pl, i) => { if (pl.x == null) { pl.x = this.world.w / 2 + (i - 1.5) * this.world.w * 0.03; pl.y = this.world.h / 2; } });
    this.fillMapSel(); this.fit(); this.dirty = true;
  },
  rescale(kx, ky) {
    const P = this.p, sc = q => { if (q) { q.x *= kx; q.y *= ky; } };
    P.objects.forEach(o => { sc(o.a); sc(o.b); sc(o.p); (o.pts || []).forEach(sc); });
    P.players.forEach(pl => { if (pl.x != null) { pl.x *= kx; pl.y *= ky; } });
    Object.values(P.keyframes).forEach(k => k.forEach(sc));
    (P.scenarios || []).forEach(s => s.safes.forEach(o => { sc(o.a); sc(o.b); }));
    this.dirtyProject = true;
  },
  fillMapSel() {
    $('#mapSel').innerHTML = Maps.list.map(m => `<option value="${m.id}" ${m.id === this.p.mapId ? 'selected' : ''}>${esc(m.name)}${Maps.status(m) === 'ok' ? '' : ' (pendente)'}</option>`).join('');
  },
  setBgVideo(video) { // modos 04/05: vídeo de partida como fundo
    this.stopBgVideo(); this.bgVideo = video;
    const set = () => { this.world = { w: video.videoWidth || 1280, h: video.videoHeight || 720 }; this.fit(); };
    if (video.readyState >= 1) set(); else video.addEventListener('loadedmetadata', set, { once: true });
  },
  stopBgVideo() {
    if (this.bgVideo) { this.bgVideo.pause(); this.bgVideo = null; if (this.bgImg) this.world = { w: this.bgImg.naturalWidth, h: this.bgImg.naturalHeight }; else this.world = { w: 2000, h: 2000 }; this.fit(); }
  },
  /* ---------- Histórico (desfazer/refazer) ---------- */
  snapshot() { this.undo.push(JSON.stringify({ o: this.p.objects, k: this.p.keyframes, pl: this.p.players.map(p => [p.x, p.y]) })); if (this.undo.length > 120) this.undo.shift(); this.redo = []; this.dirtyProject = true; },
  restore(str) { const s = JSON.parse(str); this.p.objects = s.o; this.p.keyframes = s.k; s.pl.forEach((xy, i) => { this.p.players[i].x = xy[0]; this.p.players[i].y = xy[1]; }); this.sel = null; this.dirty = true; this.renderKf(); this.renderPanel(); },
  cur() { return JSON.stringify({ o: this.p.objects, k: this.p.keyframes, pl: this.p.players.map(p => [p.x, p.y]) }); },
  doUndo() { if (!this.undo.length) return; this.redo.push(this.cur()); this.restore(this.undo.pop()); },
  doRedo() { if (!this.redo.length) return; this.undo.push(this.cur()); this.restore(this.redo.pop()); },
  /* ---------- Geometria ---------- */
  resize() {
    const r = $('#stageWrap').getBoundingClientRect(); if (!r.width || !r.height) return; const wasZero = !this.W;
    this.dpr = Math.min(2, window.devicePixelRatio || 1); this.W = r.width; this.H = r.height;
    const first = wasZero; this.cv.width = Math.round(r.width * this.dpr); this.cv.height = Math.round(r.height * this.dpr); this.dirty = true;
    if (first || !this.view.s || this.view.s === 1 && this.world.w > 0 && this.view.ox === 0) this.fit();
  },
  fit() { const s = Math.min(this.W / this.world.w, this.H / this.world.h) * 0.95 || 1; this.view = { s, ox: (this.W - this.world.w * s) / 2, oy: (this.H - this.world.h * s) / 2 }; this.dirty = true; },
  zoomAt(f, sx, sy) { const v = this.view, ns = clamp(v.s * f, 0.02, 40); v.ox = sx - (sx - v.ox) * ns / v.s; v.oy = sy - (sy - v.oy) * ns / v.s; v.s = ns; this.dirty = true; },
  toW(sx, sy) { return { x: (sx - this.view.ox) / this.view.s, y: (sy - this.view.oy) / this.view.s }; },
  unit() { return Math.max(this.world.w, this.world.h) / 1000; }, // espessuras proporcionais ao mapa
  evPos(e) { const r = this.cv.getBoundingClientRect(); return { sx: e.clientX - r.left, sy: e.clientY - r.top }; },
  /* ---------- Posição dos jogadores (keyframes) ---------- */
  posAt(pl, t) {
    const k = this.p.keyframes[pl.id]; if (!k || !k.length) return { x: pl.x, y: pl.y };
    if (t <= k[0].t) return k[0]; if (t >= k.at(-1).t) return k.at(-1);
    for (let i = 0; i < k.length - 1; i++) if (t >= k[i].t && t <= k[i + 1].t) {
      const a = k[i], b = k[i + 1], u = (t - a.t) / (b.t - a.t || 1), e = u < .5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
      return { x: a.x + (b.x - a.x) * e, y: a.y + (b.y - a.y) * e };
    }
    return k.at(-1);
  },
  setKey(pl, x, y, t = this.t) {
    const k = this.p.keyframes[pl.id]; const ex = k.find(q => Math.abs(q.t - t) < 0.05);
    if (ex) { ex.x = x; ex.y = y; } else { k.push({ t: +t.toFixed(2), x, y }); k.sort((a, b) => a.t - b.t); }
  },
  addKeyAll() {
    this.snapshot(); const list = this.selPlayer ? this.p.players.filter(p => p.id === this.selPlayer) : this.p.players;
    list.forEach(pl => { const q = this.posAt(pl, this.t); this.setKey(pl, q.x, q.y); });
    this.renderKf(); this.dirty = true; toast(`Keyframe em ${this.t.toFixed(1)}s para ${list.map(p => p.id).join(', ')}`);
  },
  delKeyAt() {
    this.snapshot(); let n = 0; const list = this.selPlayer ? [this.selPlayer] : ROLES.map(r => r.id);
    list.forEach(id => { const k = this.p.keyframes[id], before = k.length; this.p.keyframes[id] = k.filter(q => Math.abs(q.t - this.t) > 0.25); n += before - this.p.keyframes[id].length; });
    this.renderKf(); this.dirty = true; toast(n ? `${n} keyframe(s) removido(s)` : 'Nenhum keyframe neste tempo');
  },
  /* ---------- Ferramentas ---------- */
  buildTools() {
    let g = -1; const h = [`<div class="tgroups" role="tablist" aria-label="Grupos de ferramentas">${TOOL_GROUPS.map((n, i) => `<button class="tg ${i === 1 ? 'on' : ''}" data-tg="${i}" role="tab">${n}</button>`).join('')}</div>`];
    TOOLS.forEach(([id, n, path, grp]) => {
      if (grp !== g && g !== -1) h.push(`<div class="tsep" data-g="${grp}"></div>`); g = grp;
      const col = ROUTE_STYLE[id]?.color || ICON_COLOR[id] || 'currentColor';
      h.push(`<button class="tool" data-tool="${id}" data-g="${grp}" title="${n}" aria-label="${n}" aria-pressed="false"><svg viewBox="0 0 24 24" fill="none" stroke="${col}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" ${ROUTE_STYLE[id]?.dash.length ? `stroke-dasharray="${ROUTE_STYLE[id].dash.map(x => x / 3).join(' ')}"` : ''}><path d="${path}"/></svg></button>`);
    });
    $('#tools').innerHTML = h.join('');
    $$('#tools [data-tool]').forEach(b => b.onclick = () => this.setTool(b.dataset.tool));
    $$('#tools [data-tg]').forEach(b => b.onclick = () => this.showGroup(+b.dataset.tg));
    this.showGroup(1); this.setTool('select');
  },
  showGroup(i) { // no celular, mostra só o grupo escolhido (no computador todos ficam visíveis)
    $$('#tools [data-tg]').forEach(b => { b.classList.toggle('on', +b.dataset.tg === i); b.setAttribute('aria-selected', +b.dataset.tg === i); });
    $$('#tools [data-g]').forEach(b => b.classList.toggle('gh', +b.dataset.g !== i && +b.dataset.g !== 0));
  },
  setTool(t) {
    this.finishDraft(); this.tool = t; $$('#tools [data-tool]').forEach(b => { b.classList.toggle('on', b.dataset.tool === t); b.setAttribute('aria-pressed', b.dataset.tool === t); });
    if (t !== 'select') this.sel = null;
    if (t === 'zsafe') this.layer = 'safe';
    this.renderCtx(); this.dirty = true;
  },
  renderCtx() {
    const t = this.tool, st = this.style, name = TOOLS.find(x => x[0] === t)?.[1] || '';
    let h = `<b class="small" style="margin-right:4px">${name}</b>`;
    const drawTools = ['pen', 'line', 'arrow', 'carrow', 'aarrow', 'circle', 'rect', 'text', 'step', 'zdanger', 'zcontrol'];
    if (drawTools.includes(t)) {
      h += COLORS.map(c => `<span class="swatch ${c === st.color ? 'on' : ''}" data-c="${c}" style="background:${c}"></span>`).join('');
      h += `<input type="color" value="${st.color}" id="cxColor" style="width:28px;height:24px;border:0;background:none;padding:0">`;
      if (t !== 'text' && t !== 'step') h += `<label class="small muted">Esp.<input type="range" min="1" max="20" value="${st.width}" id="cxW"></label>`;
      else h += `<label class="small muted">Tam.<input type="range" min="10" max="80" value="${st.fs}" id="cxFs"></label>`;
      h += `<label class="small muted">Opac.<input type="range" min="10" max="100" value="${st.alpha * 100}" id="cxA"></label>`;
      if (!['text', 'step'].includes(t)) h += `<select id="cxD" class="in" style="padding:3px"><option value="solid">Contínua</option><option value="dash" ${st.dash === 'dash' ? 'selected' : ''}>Tracejada</option><option value="dot" ${st.dash === 'dot' ? 'selected' : ''}>Pontilhada</option></select>`;
    }
    if (t.startsWith('r-')) h += `<span class="small muted">Toque para adicionar pontos.</span><button class="btn sm pri" id="cxDone">Concluir rota</button>`;
    if (t === 'zsafe') h += `<select id="cxPh" class="in" style="padding:3px">${[1, 2, 3, 4].map(n => `<option value="${n}" ${n == this.safePhase ? 'selected' : ''}>${n === 4 ? 'Safe final' : n + 'ª safe'}</option>`).join('')}</select>
      <select id="cxPr" class="in" style="padding:3px"><option value="1">Previsão do analista</option><option value="0" ${this.safePredicted ? '' : 'selected'}>Confirmada na partida</option></select>`;
    if (t === 'select' && this.sel) h += `<button class="btn sm" id="cxEdit">Editar texto</button><button class="btn sm red" id="cxDel">Excluir</button>`;
    h += `<select id="cxL" class="in" style="padding:3px" title="Camada ativa">${LAYERS.map(([id, n]) => `<option value="${id}" ${id === this.layer ? 'selected' : ''}>${n}</option>`).join('')}</select>
      <button class="btn sm" id="cxClr" title="Limpar camada">Limpar camada</button>`;
    const bar = $('#ctxBar'); bar.innerHTML = h;
    $$('[data-c]', bar).forEach(s => s.onclick = () => { st.color = s.dataset.c; this.renderCtx(); });
    const on = (id, f) => { const e = $('#' + id); if (e) e.oninput = e.onchange = f; };
    on('cxColor', e => { st.color = e.target.value; }); on('cxW', e => st.width = +e.target.value); on('cxFs', e => st.fs = +e.target.value);
    on('cxA', e => st.alpha = e.target.value / 100); on('cxD', e => st.dash = e.target.value); on('cxL', e => this.layer = e.target.value);
    on('cxPh', e => this.safePhase = +e.target.value); on('cxPr', e => this.safePredicted = e.target.value === '1');
    const d = $('#cxDone'); if (d) d.onclick = () => this.finishDraft();
    const del = $('#cxDel'); if (del) del.onclick = () => this.deleteSel();
    const ed = $('#cxEdit'); if (ed) ed.onclick = () => this.editSelText();
    $('#cxClr').onclick = async () => {
      const n = this.p.objects.filter(o => o.layer === this.layer).length; if (!n) return toast('Camada já está vazia.');
      if (await Modal.confirm(`Limpar ${n} elemento(s) da camada "${LAYERS.find(l => l[0] === this.layer)[1]}"? (pode desfazer)`, 'Limpar', true)) { this.snapshot(); this.p.objects = this.p.objects.filter(o => o.layer !== this.layer); this.dirty = true; this.renderPanel(); }
    };
  },
  dashArr(d, w) { return d === 'dash' ? [w * 3, w * 2] : d === 'dot' ? [w * .1, w * 2] : []; },
  baseObj(type) { return { id: uid(), type, layer: this.layer, color: this.style.color, w: this.style.width, alpha: this.style.alpha, dash: this.style.dash }; },
  /* ---------- Entrada de ponteiro / toque ---------- */
  bind() {
    const cv = this.cv;
    cv.addEventListener('pointerdown', e => this.down(e)); cv.addEventListener('pointermove', e => this.move(e));
    cv.addEventListener('pointerup', e => this.up(e)); cv.addEventListener('pointercancel', e => this.up(e));
    cv.addEventListener('dblclick', () => { if (this.draft?.type === 'route') this.finishDraft(); });
    cv.addEventListener('wheel', e => { e.preventDefault(); const p = this.evPos(e); this.zoomAt(Math.exp(-e.deltaY * 0.0015), p.sx, p.sy); }, { passive: false });
    cv.addEventListener('contextmenu', e => e.preventDefault());
    $('#zIn').onclick = () => this.zoomAt(1.25, this.W / 2, this.H / 2); $('#zOut').onclick = () => this.zoomAt(0.8, this.W / 2, this.H / 2); $('#zFit').onclick = () => this.fit();
    $('#bUndo').onclick = () => this.doUndo(); $('#bRedo').onclick = () => this.doRedo();
    $('#bSave').onclick = () => this.saveProject();
    $('#bNew').onclick = async () => { if (this.dirtyProject && !await Modal.confirm('Há alterações não salvas. Criar novo projeto mesmo assim?', 'Criar novo')) return; this.loadProject(newProject(this.p.mapId)); };
    $('#mapSel').onchange = e => { this.snapshot(); this.setMap(e.target.value); };
    $('#projName').oninput = () => this.dirtyProject = true;
    $('#bPanel').onclick = () => $('#panel').classList.toggle('closed');
    $('#bPng').onclick = () => this.exportPng(false); $('#bSharePng').onclick = () => this.shareMenu();
    $('#bPlay').onclick = () => this.togglePlay();
    $('#bKf').onclick = () => this.addKeyAll(); $('#bKfDel').onclick = () => this.delKeyAt();
    $('#animDur').onchange = e => { this.p.duration = clamp(+e.target.value || 20, 2, 600); e.target.value = this.p.duration; this.renderKf(); };
    const kb = $('#kfbar'); let scrub = false;
    const seek = e => { const r = kb.getBoundingClientRect(); this.t = clamp((e.clientX - r.left) / r.width, 0, 1) * this.p.duration; this.renderKf(); this.dirty = true; };
    kb.onpointerdown = e => { scrub = true; kb.setPointerCapture(e.pointerId); seek(e); }; kb.onpointermove = e => scrub && seek(e); kb.onpointerup = () => scrub = false;
    window.addEventListener('keydown', e => {
      if (currentView !== 'estudio' || this.readOnly || $('#modal').classList.contains('on') || /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? this.doRedo() : this.doUndo(); }
      else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); this.doRedo(); }
      else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); this.saveProject(); }
      else if (e.key === 'Delete' || e.key === 'Backspace') { if (this.sel) { e.preventDefault(); this.deleteSel(); } }
      else if (e.key === 'Enter' || e.key === 'Escape') this.finishDraft();
      else if (e.key === ' ') { e.preventDefault(); this.togglePlay(); }
      else if (e.key === 'v') this.setTool('select'); else if (e.key === 'p') this.setTool('pen'); else if (e.key === 'e') this.setTool('eraser'); else if (e.key === 'a') this.setTool('arrow');
    });
    window.addEventListener('beforeunload', e => { if (this.dirtyProject) { e.preventDefault(); e.returnValue = ''; } });
  },
  down(e) {
    this.cv.setPointerCapture(e.pointerId); const p = this.evPos(e); this.pointers.set(e.pointerId, p);
    if (this.pointers.size === 2) { // pinça: cancela traço e inicia zoom
      if (this.draft && this.draft.type !== 'route') this.draft = null; this.drag = null;
      const [a, b] = [...this.pointers.values()]; this.pinch = { d: Math.hypot(a.sx - b.sx, a.sy - b.sy), cx: (a.sx + b.sx) / 2, cy: (a.sy + b.sy) / 2 }; return;
    }
    if (this.pointers.size > 2) return;
    const w = this.toW(p.sx, p.sy), t = this.tool;
    if (this.readOnly || e.button === 1 || e.button === 2 || t === 'pan') { this.drag = { mode: 'pan', sx: p.sx, sy: p.sy }; return; }
    // jogadores podem ser arrastados com a ferramenta Selecionar
    if (t === 'select') {
      const pl = this.hitPlayer(p.sx, p.sy);
      if (pl) { this.snapshot(); this.selPlayer = pl.id; this.drag = { mode: 'player', pl }; this.renderPanel(); return; }
      const o = this.hitObj(w.x, w.y); this.sel = o ? o.id : null; this.renderCtx();
      if (o) { this.snapshot(); this.drag = { mode: 'obj', o, last: w }; } else { this.selPlayer = null; this.drag = { mode: 'pan', sx: p.sx, sy: p.sy }; this.renderPanel(); }
      this.dirty = true; return;
    }
    if (t === 'eraser') { this.snapshot(); this.drag = { mode: 'erase' }; this.eraseAt(w); return; }
    if (t.startsWith('r-')) { if (!this.draft) { const s = ROUTE_STYLE[t]; this.draft = { ...this.baseObj('route'), kind: t, color: s.color, w: s.w, dash: 'custom', pts: [w] }; } this.draft.pts.push({ ...w }); this.dirty = true; return; }
    if (t === 'text' || t === 'region') { this.placeText(w, t); return; }
    if (t === 'step') { this.snapshot(); const n = this.p.objects.filter(o => o.type === 'step').length + 1; this.p.objects.push({ ...this.baseObj('step'), p: w, n, fs: this.style.fs }); this.dirty = true; return; }
    if (t.startsWith('i-')) { this.snapshot(); this.p.objects.push({ ...this.baseObj('icon'), kind: t, color: ICON_COLOR[t], p: w, label: '' }); this.dirty = true; return; }
    const o = this.baseObj(t);
    if (t === 'pen') o.pts = [w]; else { o.a = { ...w }; o.b = { ...w }; }
    if (t === 'zsafe') Object.assign(o, { layer: 'safe', phase: this.safePhase, predicted: this.safePredicted, color: '#00C8FF' });
    if (t === 'zdanger') o.color = this.style.color === '#00C8FF' ? '#FF4D6A' : this.style.color;
    if (t === 'zcontrol') o.color = this.style.color === '#00C8FF' ? '#FF8A30' : this.style.color;
    if (t === 'carrow') o.curv = 0.3;
    this.draft = o; this.dirty = true;
  },
  move(e) {
    if (!this.pointers.has(e.pointerId)) return; const p = this.evPos(e); this.pointers.set(e.pointerId, p);
    if (this.pinch && this.pointers.size === 2) {
      const [a, b] = [...this.pointers.values()], d = Math.hypot(a.sx - b.sx, a.sy - b.sy), cx = (a.sx + b.sx) / 2, cy = (a.sy + b.sy) / 2;
      this.view.ox += cx - this.pinch.cx; this.view.oy += cy - this.pinch.cy; this.zoomAt(d / this.pinch.d, cx, cy);
      this.pinch = { d, cx, cy }; return;
    }
    const w = this.toW(p.sx, p.sy), dr = this.drag;
    if (dr?.mode === 'pan') { this.view.ox += p.sx - dr.sx; this.view.oy += p.sy - dr.sy; dr.sx = p.sx; dr.sy = p.sy; this.dirty = true; return; }
    if (dr?.mode === 'player') { const pl = dr.pl; if (this.p.keyframes[pl.id].length) this.setKey(pl, w.x, w.y); else { pl.x = w.x; pl.y = w.y; } this.dirty = true; return; }
    if (dr?.mode === 'obj') { this.translate(dr.o, w.x - dr.last.x, w.y - dr.last.y); dr.last = w; this.dirty = true; return; }
    if (dr?.mode === 'erase') { this.eraseAt(w); return; }
    const d = this.draft; if (!d || d.type === 'route') return;
    if (d.type === 'pen') { const l = d.pts.at(-1); if (Math.hypot(l.x - w.x, l.y - w.y) > 1.5 / this.view.s) d.pts.push(w); } else d.b = w;
    this.dirty = true;
  },
  up(e) {
    this.pointers.delete(e.pointerId); if (this.pointers.size < 2) this.pinch = null;
    if (this.drag) { if (this.drag.mode === 'player') this.renderKf(); this.drag = null; return; }
    const d = this.draft; if (!d || d.type === 'route') return;
    const tiny = d.pts ? d.pts.length < 2 : Math.hypot(d.a.x - d.b.x, d.a.y - d.b.y) * this.view.s < 6;
    if (!tiny) {
      if (d.type === 'measure') { this.draft = null; this.dirty = true; return this.onMeasure(d); }
      this.snapshot(); this.p.objects.push(d); if (d.type === 'zsafe') this.renderPanel();
    }
    this.draft = null; this.dirty = true;
  },
  finishDraft() { const d = this.draft; if (d?.type === 'route') { d.pts.shift(); if (d.pts.length >= 2) { this.snapshot(); this.p.objects.push(d); } } this.draft = null; this.dirty = true; },
  async placeText(w, t) {
    if (t === 'region') {
      const m = Maps.get(this.p.mapId), free = m.regions.filter(r => r.nx == null);
      const pick = await new Promise(res => Modal.open(`<h3>Região neste ponto</h3>${free.length ? `<div class="row" style="flex-wrap:wrap">${free.map(r => `<button class="btn sm" data-rp="${r.id}">${esc(r.name)}</button>`).join('')}</div><p class="small muted">ou digite um novo nome:</p>` : ''}
        <div class="row"><input class="in" id="rpN" placeholder="Nome da região" style="flex:1"><button class="btn pri" id="rpOk">OK</button></div><div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn" data-x>Cancelar</button></div>`, b => {
        b.querySelector('[data-x]').onclick = () => { Modal.close(); res(null); };
        $$('[data-rp]', b).forEach(x => x.onclick = () => { Modal.close(); res({ id: x.dataset.rp }); });
        const ok = () => { const n = $('#rpN').value.trim(); Modal.close(); res(n ? { name: n.slice(0, 80) } : null); }; $('#rpOk').onclick = ok; $('#rpN').onkeydown = e => e.key === 'Enter' && ok();
      }));
      if (!pick) return; const nx = w.x / this.world.w, ny = w.y / this.world.h;
      if (pick.id) Object.assign(m.regions.find(r => r.id === pick.id), { nx, ny }); else m.regions.push({ id: uid(), name: pick.name, nx, ny });
      await DB.put('maps', m); this.dirty = true; return;
    }
    const txt = await Modal.prompt('Texto:'); if (!txt) return;
    this.snapshot(); this.p.objects.push({ ...this.baseObj('text'), p: w, text: txt, fs: this.style.fs });
    this.dirty = true;
  },
  async editSelText() {
    const o = this.p.objects.find(x => x.id === this.sel); if (!o) return;
    const key = o.type === 'text' ? 'text' : o.type === 'zsafe' ? 'note' : 'label';
    const v = await Modal.prompt('Texto / rótulo:', o[key] || ''); if (v === null) return; this.snapshot(); o[key] = v; this.dirty = true;
  },
  deleteSel() { if (!this.sel) return; this.snapshot(); this.p.objects = this.p.objects.filter(o => o.id !== this.sel); this.sel = null; this.renderCtx(); this.renderPanel(); this.dirty = true; },
  translate(o, dx, dy) { ['a', 'b', 'p'].forEach(k => { if (o[k]) { o[k].x += dx; o[k].y += dy; } }); if (o.pts) o.pts.forEach(q => { q.x += dx; q.y += dy; }); },
  eraseAt(w) {
    const o = this.hitObj(w.x, w.y); if (o) { this.p.objects = this.p.objects.filter(x => x !== o); this.dirty = true; return; }
    const m = Maps.get(this.p.mapId), tol = 20 / this.view.s, r = m.regions.find(r => r.nx != null && Math.hypot(r.nx * this.world.w - w.x, r.ny * this.world.h - w.y) < tol * 2);
    if (r) { r.nx = r.ny = null; DB.put('maps', m); this.dirty = true; toast('Região "' + r.name + '" removida do mapa (o nome continua na lista).'); }
  },
  hitPlayer(sx, sy) {
    const R = 22; for (const pl of [...this.p.players].reverse()) { if (!pl.visible) continue; const q = this.posAt(pl, this.t); const x = q.x * this.view.s + this.view.ox, y = q.y * this.view.s + this.view.oy; if (Math.hypot(x - sx, y - sy) < R) return pl; } return null;
  },
  hitObj(x, y) {
    const tol = 12 / this.view.s;
    const segD = (p, a, b) => { const dx = b.x - a.x, dy = b.y - a.y, l = dx * dx + dy * dy; let u = l ? ((p.x - a.x) * dx + (p.y - a.y) * dy) / l : 0; u = clamp(u, 0, 1); return Math.hypot(p.x - a.x - u * dx, p.y - a.y - u * dy); };
    const P = { x, y };
    for (const o of [...this.p.objects].reverse()) {
      if (this.hidden[o.layer]) continue;
      let hit = false; const tw = tol + (o.w || 0) * this.unit() / 2;
      if (o.pts) for (let i = 0; i < o.pts.length - 1 && !hit; i++) hit = segD(P, o.pts[i], o.pts[i + 1]) < tw;
      else if (['line', 'arrow', 'aarrow', 'measure'].includes(o.type)) hit = segD(P, o.a, o.b) < tw;
      else if (o.type === 'carrow') { const c = this.ctrl(o); for (let i = 0; i < 12 && !hit; i++) hit = segD(P, this.qpt(o.a, c, o.b, i / 12), this.qpt(o.a, c, o.b, (i + 1) / 12)) < tw; }
      else if (['circle', 'zdanger', 'zsafe'].includes(o.type)) { const r = Math.hypot(o.b.x - o.a.x, o.b.y - o.a.y), d = Math.hypot(x - o.a.x, y - o.a.y); hit = o.type === 'circle' ? Math.abs(d - r) < tw : d < r; }
      else if (['rect', 'zcontrol'].includes(o.type)) { const x1 = Math.min(o.a.x, o.b.x), x2 = Math.max(o.a.x, o.b.x), y1 = Math.min(o.a.y, o.b.y), y2 = Math.max(o.a.y, o.b.y); hit = o.type === 'rect' ? (x > x1 - tw && x < x2 + tw && y > y1 - tw && y < y2 + tw) && !(x > x1 + tw && x < x2 - tw && y > y1 + tw && y < y2 - tw) : x > x1 && x < x2 && y > y1 && y < y2; }
      else if (o.p) hit = Math.hypot(o.p.x - x, o.p.y - y) < tol * 2.2 + (o.fs || 0) * this.unit() * 0.5;
      if (hit) return o;
    }
    return null;
  },
  ctrl(o) { const mx = (o.a.x + o.b.x) / 2, my = (o.a.y + o.b.y) / 2, dx = o.b.x - o.a.x, dy = o.b.y - o.a.y; return { x: mx - dy * (o.curv ?? .3), y: my + dx * (o.curv ?? .3) }; },
  qpt(a, c, b, t) { const u = 1 - t; return { x: u * u * a.x + 2 * u * t * c.x + t * t * b.x, y: u * u * a.y + 2 * u * t * c.y + t * t * b.y }; },
  /* ---------- Medição ---------- */
  async onMeasure(d) {
    const du = Math.hypot(d.b.x - d.a.x, d.b.y - d.a.y), S = Settings.data;
    const calib = await new Promise(res => Modal.open(`<h3>Medição</h3><p>Distância no mapa: <b>${du.toFixed(0)} px</b>${S.metersPerUnit ? ` ≈ <b>${(du * S.metersPerUnit).toFixed(0)} m</b> (escala calibrada: ${S.metersPerUnit.toFixed(3)} m/px)` : ' — escala ainda não calibrada'}.</p>
      ${S.metersPerUnit && S.speedFoot ? `<p>Tempo estimado a pé: <b>${fmtT(du * S.metersPerUnit / S.speedFoot)}</b> (${S.speedFoot} m/s)</p>` : ''}
      ${S.metersPerUnit && S.speedVehicle ? `<p>Tempo estimado de veículo: <b>${fmtT(du * S.metersPerUnit / S.speedVehicle)}</b> (${S.speedVehicle} m/s)</p>` : ''}
      <p class="small muted">Estimativa baseada nos parâmetros definidos em Configurações. Velocidades reais variam com terreno, personagem e versão — use medições de treino.</p>
      <div class="grid g2"><label class="f">Esta linha mede (metros reais) — calibrar escala<input class="in" id="mCal" type="number" min="1"></label>
      <label class="f">Registrar medição de treino: tempo real (s)<input class="in" id="mTr" type="number" min="0" step="0.1"></label></div>
      <label class="f" style="margin-top:8px">Descrição da medição<input class="in" id="mDs" placeholder="ex.: Pico → Clock Tower a pé"></label>
      <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn" data-x>Fechar</button><button class="btn pri" data-ok>Aplicar</button></div>`, b => {
      b.querySelector('[data-x]').onclick = () => { Modal.close(); res(null); };
      b.querySelector('[data-ok]').onclick = () => { const r = { cal: +b.querySelector('#mCal').value, tr: +b.querySelector('#mTr').value, ds: b.querySelector('#mDs').value }; Modal.close(); res(r); };
    }));
    if (!calib) return;
    if (calib.cal > 0) { S.metersPerUnit = calib.cal / du; await Settings.save(); toast(`Escala calibrada: ${S.metersPerUnit.toFixed(3)} m/px`); }
    if (calib.tr > 0) { this.p.measurements.push({ id: uid(), desc: calib.ds || 'Medição', px: du, m: S.metersPerUnit ? du * S.metersPerUnit : null, s: calib.tr, date: Date.now() }); this.dirtyProject = true; this.renderPanel(); toast('Medição de treino registrada no projeto.'); }
  },
  /* ---------- Animação ---------- */
  togglePlay() { this.playing = !this.playing; if (this.playing && this.t >= this.p.duration) this.t = 0; $('#bPlay').textContent = this.playing ? '❚❚' : '▶'; },
  renderKf() {
    const kb = $('#kfbar'), D = this.p.duration;
    $$('.kf', kb).forEach(x => x.remove());
    this.p.players.forEach((pl, i) => (this.p.keyframes[pl.id] || []).forEach(k => { const d = document.createElement('div'); d.className = 'kf'; d.style.left = (k.t / D * 100) + '%'; d.style.top = (20 + i * 20) + '%'; d.style.background = pl.color; kb.appendChild(d); }));
    $('#kfph').style.left = (this.t / D * 100) + '%'; $('#tLabel').textContent = this.t.toFixed(1) + 's';
  },
  anyAnimated() { return this.p.objects.some(o => o.type === 'aarrow'); },
  loop(ts) {
    const dt = Math.min(0.1, (ts - (this.lastTs || ts)) / 1000); this.lastTs = ts;
    if (this.playing) { this.t += dt; if (this.t >= this.p.duration) { this.t = this.p.duration; this.playing = false; $('#bPlay').textContent = '▶'; } this.renderKf(); this.dirty = true; }
    if (currentView === 'estudio' && (this.dirty || this.anyAnimated() || this.bgVideo || Recorder.active || this.cam)) this.draw(ts);
    requestAnimationFrame(t => this.loop(t));
  },
  /* ---------- Renderização ---------- */
  draw(ts = performance.now(), target) {
    const c = target || this.ctx, cv = c.canvas, dpr = target ? 1 : this.dpr, v = this.view;
    c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = '#040a13'; c.fillRect(0, 0, cv.width, cv.height);
    c.setTransform(dpr * v.s, 0, 0, dpr * v.s, dpr * v.ox, dpr * v.oy);
    const U = this.unit();
    if (this.bgVideo && this.bgVideo.readyState >= 2) c.drawImage(this.bgVideo, 0, 0, this.world.w, this.world.h);
    else if (this.bgImg) c.drawImage(this.bgImg, 0, 0);
    else this.drawGrid(c);
    if (!this.bgVideo) for (const r of Maps.get(this.p.mapId)?.regions || []) if (r.nx != null) this.label(c, r.nx * this.world.w, r.ny * this.world.h, r.name.toUpperCase(), 15 * U, '#FFFFFF', 'rgba(7,17,31,.65)');
    for (const [L] of LAYERS) if (!this.hidden[L]) for (const o of this.p.objects) if (o.layer === L) this.drawObj(c, o, ts);
    if (this.draft) this.drawObj(c, this.draft, ts);
    const so = this.sel && this.p.objects.find(o => o.id === this.sel); if (so) this.drawSel(c, so);
    this.drawPlayers(c);
    // HUD em coordenadas de tela
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (Recorder.active || target) {
      c.font = '600 12px system-ui'; c.fillStyle = 'rgba(245,248,255,.7)'; c.textAlign = 'left'; c.textBaseline = 'top';
      c.fillText('ANALISTA TÁTICO PRO · ' + (this.p.name || ''), 12, (cv.height / dpr) - 22);
    }
    if (this.cam && this.cam.video.readyState >= 2) {
      const r = this.cam.rect; c.save(); c.beginPath(); c.roundRect ? c.roundRect(r.x, r.y, r.w, r.h, 12) : c.rect(r.x, r.y, r.w, r.h); c.clip();
      const vw = this.cam.video.videoWidth, vh = this.cam.video.videoHeight, s = Math.max(r.w / vw, r.h / vh);
      if (this.cam.mirror) { c.translate(r.x + r.w, r.y); c.scale(-1, 1); } else c.translate(r.x, r.y); c.drawImage(this.cam.video, (r.w - vw * s) / 2, (r.h - vh * s) / 2, vw * s, vh * s); c.restore();
      c.strokeStyle = '#00C8FF'; c.lineWidth = 2; c.beginPath(); c.roundRect ? c.roundRect(r.x, r.y, r.w, r.h, 12) : c.rect(r.x, r.y, r.w, r.h); c.stroke();
    }
    if (!target) this.dirty = false;
  },
  drawGrid(c) {
    const { w, h } = this.world; c.fillStyle = '#0a1726'; c.fillRect(0, 0, w, h);
    c.strokeStyle = 'rgba(0,200,255,.10)'; c.lineWidth = 1 / this.view.s;
    for (let i = 0; i <= 20; i++) { c.beginPath(); c.moveTo(i * w / 20, 0); c.lineTo(i * w / 20, h); c.moveTo(0, i * h / 20); c.lineTo(w, i * h / 20); c.stroke(); }
    c.strokeStyle = 'rgba(0,200,255,.3)'; c.lineWidth = 3 / this.view.s; c.strokeRect(0, 0, w, h);
    c.fillStyle = 'rgba(0,200,255,.35)'; c.font = `600 ${w / 40}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle';
    const L = 'ABCDEFGHIJ'; for (let i = 0; i < 10; i++) { c.fillText(L[i], (i + .5) * w / 10, w / 60); c.fillText(String(i + 1), w / 60, (i + .5) * h / 10); }
    c.fillStyle = 'rgba(245,248,255,.25)'; c.font = `600 ${w / 32}px system-ui`;
    c.fillText('IMAGEM DO MAPA PENDENTE — importe em Mapas', w / 2, h / 2);
  },
  label(c, x, y, t, fs, col, bg) {
    c.font = `700 ${fs}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; const m = c.measureText(t).width;
    if (bg) { c.fillStyle = bg; c.beginPath(); c.roundRect ? c.roundRect(x - m / 2 - fs * .4, y - fs * .7, m + fs * .8, fs * 1.4, fs * .3) : c.rect(x - m / 2 - fs * .4, y - fs * .7, m + fs * .8, fs * 1.4); c.fill(); }
    c.fillStyle = col; c.fillText(t, x, y);
  },
  arrowHead(c, from, to, size, color) {
    const ang = Math.atan2(to.y - from.y, to.x - from.x); c.save(); c.setLineDash([]); c.fillStyle = color; c.beginPath();
    c.moveTo(to.x, to.y); c.lineTo(to.x - size * Math.cos(ang - .45), to.y - size * Math.sin(ang - .45)); c.lineTo(to.x - size * Math.cos(ang + .45), to.y - size * Math.sin(ang + .45)); c.closePath(); c.fill(); c.restore();
  },
  drawObj(c, o, ts) {
    const U = this.unit(), w = (o.w || 4) * U; c.save(); c.globalAlpha = o.alpha ?? 1; c.strokeStyle = o.color; c.fillStyle = o.color; c.lineWidth = w; c.lineCap = 'round'; c.lineJoin = 'round';
    c.setLineDash(o.dash === 'custom' ? ROUTE_STYLE[o.kind].dash.map(x => x * U) : this.dashArr(o.dash, w));
    const path = pts => { c.beginPath(); c.moveTo(pts[0].x, pts[0].y); for (let i = 1; i < pts.length; i++) c.lineTo(pts[i].x, pts[i].y); c.stroke(); };
    switch (o.type) {
      case 'pen': path(o.pts); break;
      case 'line': path([o.a, o.b]); break;
      case 'measure': c.setLineDash([6 * U, 4 * U]); c.strokeStyle = '#fff'; c.lineWidth = 2 * U; path([o.a, o.b]); break;
      case 'arrow': { const hs = Math.max(12 * U, w * 3.2), ang = Math.atan2(o.b.y - o.a.y, o.b.x - o.a.x); path([o.a, { x: o.b.x - Math.cos(ang) * hs * .6, y: o.b.y - Math.sin(ang) * hs * .6 }]); this.arrowHead(c, o.a, o.b, hs, o.color); break; }
      case 'carrow': { const k = this.ctrl(o); c.beginPath(); c.moveTo(o.a.x, o.a.y); c.quadraticCurveTo(k.x, k.y, o.b.x, o.b.y); c.stroke(); this.arrowHead(c, this.qpt(o.a, k, o.b, .92), o.b, Math.max(12 * U, w * 3.2), o.color); break; }
      case 'aarrow': {
        const hs = Math.max(12 * U, w * 3.2); c.setLineDash([w * 2.5, w * 2]); c.lineDashOffset = -(ts / 1000) * w * 12; path([o.a, o.b]);
        const ph = ((ts / 1000) % 1.6) / 1.6, pt = { x: o.a.x + (o.b.x - o.a.x) * ph, y: o.a.y + (o.b.y - o.a.y) * ph };
        this.arrowHead(c, o.a, o.b, hs, o.color); c.globalAlpha *= .9; c.beginPath(); c.arc(pt.x, pt.y, w * 1.2, 0, 7); c.fill(); break;
      }
      case 'circle': { const r = Math.hypot(o.b.x - o.a.x, o.b.y - o.a.y); c.beginPath(); c.arc(o.a.x, o.a.y, r, 0, 7); c.stroke(); break; }
      case 'rect': c.beginPath(); c.rect(o.a.x, o.a.y, o.b.x - o.a.x, o.b.y - o.a.y); c.stroke(); break;
      case 'zdanger': case 'zsafe': {
        const r = Math.hypot(o.b.x - o.a.x, o.b.y - o.a.y); c.beginPath(); c.arc(o.a.x, o.a.y, r, 0, 7);
        if (o.type === 'zdanger') { c.globalAlpha = (o.alpha ?? 1) * .22; c.fill(); c.globalAlpha = o.alpha ?? 1; c.setLineDash([w * 2, w * 1.5]); c.stroke(); this.label(c, o.a.x, o.a.y, '⚠ PERIGO', 14 * U, '#fff', 'rgba(255,77,106,.7)'); }
        else {
          const col = ['#00C8FF', '#3CE6A0', '#FFD23F', '#FF8A30'][(o.phase || 1) - 1]; c.strokeStyle = col; c.lineWidth = 3 * U;
          c.setLineDash(o.predicted ? [10 * U, 8 * U] : []); c.globalAlpha = .1; c.fillStyle = col; c.fill(); c.globalAlpha = 1; c.stroke();
          c.setLineDash([]); c.beginPath(); c.arc(o.a.x, o.a.y, 3 * U, 0, 7); c.fillStyle = col; c.fill();
          this.label(c, o.a.x, o.a.y - r - 12 * U, `${o.phase === 4 ? 'SAFE FINAL' : o.phase + 'ª SAFE'} · ${o.predicted ? 'PREVISÃO' : 'CONFIRMADA'}${o.note ? ' · ' + o.note : ''}`, 11 * U, '#07111F', col);
        }
        break;
      }
      case 'zcontrol': {
        const x = Math.min(o.a.x, o.b.x), y = Math.min(o.a.y, o.b.y), W = Math.abs(o.b.x - o.a.x), H = Math.abs(o.b.y - o.a.y);
        c.globalAlpha = (o.alpha ?? 1) * .15; c.fillRect(x, y, W, H); c.globalAlpha = (o.alpha ?? 1) * .5; c.save(); c.beginPath(); c.rect(x, y, W, H); c.clip(); c.lineWidth = 1.5 * U; c.setLineDash([]);
        for (let i = -H; i < W; i += 14 * U) { c.beginPath(); c.moveTo(x + i, y + H); c.lineTo(x + i + H, y); c.stroke(); } c.restore();
        c.globalAlpha = o.alpha ?? 1; c.strokeRect(x, y, W, H); this.label(c, x + W / 2, y + 12 * U, 'CONTROLE' + (o.label ? ' · ' + o.label : ''), 11 * U, '#07111F', o.color); break;
      }
      case 'route': {
        const pts = o === this.draft ? o.pts.slice(1) : o.pts; if (pts.length < 1) break;
        c.shadowColor = o.color; c.shadowBlur = 6 * U; if (pts.length > 1) path(pts); c.shadowBlur = 0;
        if (pts.length > 1) this.arrowHead(c, pts.at(-2), pts.at(-1), 16 * U, o.color);
        pts.forEach(q => { c.beginPath(); c.setLineDash([]); c.arc(q.x, q.y, 3 * U, 0, 7); c.fill(); });
        const nm = { 'r-main': 'PRINCIPAL', 'r-alt': 'ALTERNATIVA', 'r-emer': 'EMERGÊNCIA' }[o.kind];
        this.label(c, pts[0].x, pts[0].y - 14 * U, 'ROTA ' + nm + (o.label ? ' · ' + o.label : ''), 10 * U, '#07111F', o.color); break;
      }
      case 'text': c.font = `700 ${o.fs * U}px system-ui`; c.textAlign = 'left'; c.textBaseline = 'middle'; c.lineWidth = o.fs * U * .18; c.strokeStyle = 'rgba(0,0,0,.75)'; c.setLineDash([]); c.strokeText(o.text, o.p.x, o.p.y); c.fillText(o.text, o.p.x, o.p.y); break;
      case 'step': { const r = o.fs * U * .7; c.setLineDash([]); c.beginPath(); c.arc(o.p.x, o.p.y, r, 0, 7); c.fill(); c.lineWidth = 2 * U; c.strokeStyle = '#fff'; c.stroke(); c.fillStyle = '#07111F'; c.font = `800 ${r * 1.1}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(o.n, o.p.x, o.p.y + r * .05); break; }
      case 'icon': {
        const r = 13 * U; c.setLineDash([]); c.fillStyle = 'rgba(7,17,31,.85)'; c.beginPath(); c.arc(o.p.x, o.p.y, r, 0, 7); c.fill(); c.lineWidth = 2.5 * U; c.strokeStyle = o.color; c.stroke();
        c.fillStyle = o.color; c.font = `800 ${r * 1.15}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(ICON_LETTER[o.kind], o.p.x, o.p.y + r * .05);
        if (o.label) this.label(c, o.p.x, o.p.y + r + 9 * U, o.label, 10 * U, '#fff', 'rgba(7,17,31,.8)'); break;
      }
    }
    c.restore();
  },
  drawSel(c, o) {
    const pts = o.pts || [o.a, o.b, o.p].filter(Boolean); let x1 = 1e9, y1 = 1e9, x2 = -1e9, y2 = -1e9;
    pts.forEach(q => { x1 = Math.min(x1, q.x); y1 = Math.min(y1, q.y); x2 = Math.max(x2, q.x); y2 = Math.max(y2, q.y); });
    if (['circle', 'zdanger', 'zsafe'].includes(o.type)) { const r = Math.hypot(o.b.x - o.a.x, o.b.y - o.a.y); x1 = o.a.x - r; x2 = o.a.x + r; y1 = o.a.y - r; y2 = o.a.y + r; }
    const pad = 14 / this.view.s; c.save(); c.strokeStyle = '#fff'; c.lineWidth = 1.5 / this.view.s; c.setLineDash([6 / this.view.s, 4 / this.view.s]); c.strokeRect(x1 - pad, y1 - pad, x2 - x1 + pad * 2, y2 - y1 + pad * 2); c.restore();
  },
  drawPlayers(c) {
    const s = this.view.s, R = 17 / s;
    for (const pl of this.p.players) { // trajetórias
      const k = this.p.keyframes[pl.id]; if (!pl.visible || !k || k.length < 2) continue;
      c.save(); c.strokeStyle = pl.color; c.globalAlpha = .55; c.lineWidth = 2.5 / s; c.setLineDash([7 / s, 6 / s]); c.beginPath(); c.moveTo(k[0].x, k[0].y); k.forEach(q => c.lineTo(q.x, q.y)); c.stroke();
      c.setLineDash([]); c.globalAlpha = .9; k.forEach(q => { c.beginPath(); c.arc(q.x, q.y, 3.5 / s, 0, 7); c.fillStyle = pl.color; c.fill(); }); c.restore();
    }
    for (const pl of this.p.players) {
      if (!pl.visible) continue; const q = this.posAt(pl, this.t);
      c.save(); c.shadowColor = pl.color; c.shadowBlur = 14 / s; c.fillStyle = pl.color; c.beginPath(); c.arc(q.x, q.y, R, 0, 7); c.fill(); c.shadowBlur = 0;
      c.lineWidth = (this.selPlayer === pl.id ? 3.5 : 2) / s; c.strokeStyle = this.selPlayer === pl.id ? '#fff' : 'rgba(7,17,31,.9)'; c.stroke();
      c.fillStyle = '#07111F'; c.font = `800 ${11 / s}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(pl.id, q.x, q.y + .5 / s);
      const nm = pl.nick || pl.name; if (nm) this.label(c, q.x, q.y + R + 10 / s, nm, 10 / s, '#fff', 'rgba(7,17,31,.8)');
      c.restore();
    }
  },
  /* ---------- Menu de compartilhamento ---------- */
  shareMenu() {
    Modal.open(`<h3>Compartilhar — ${esc(this.p.name)}</h3><div class="grid" style="gap:8px">
      <button class="btn" id="shImg" style="justify-content:flex-start">🖼 Imagem do mapa (PNG) — WhatsApp, Discord, Telegram…</button>
      <button class="btn" id="shVid" style="justify-content:flex-start">🎬 Vídeo gravado deste projeto</button>
      <button class="btn" id="shPrj" style="justify-content:flex-start">📦 Arquivo do projeto (.atp.json)</button>
      <button class="btn pri" id="shLink" style="justify-content:flex-start">🔗 Link público / controle de acesso</button></div>
      <p class="small muted">Links públicos exigem a conta na nuvem configurada (Configurações → Conta e nuvem).</p>
      <div class="row" style="justify-content:flex-end"><button class="btn" data-x>Fechar</button></div>`, b => {
      b.querySelector('[data-x]').onclick = () => Modal.close();
      $('#shImg').onclick = () => { Modal.close(); this.exportPng(true); };
      $('#shPrj').onclick = async () => { Modal.close(); const blob = new Blob([JSON.stringify({ app: 'analista-tatico-pro', type: 'project', version: APP_VERSION, format: BACKUP_FORMAT, project: { ...deep(this.p), history: [] } })], { type: 'application/json' }); shareFile(blob, (this.p.name || 'projeto').replace(/[^\w\-]+/g, '_') + '.atp.json', this.p.name); };
      $('#shVid').onclick = async () => { const vids = (await Media.list('rec')).filter(r => r.projectId === this.p.id || (this.p.videos || []).includes(r.id)); Modal.close();
        if (!vids.length) return toast('Nenhuma gravação deste projeto. Use ● Gravar.'); Recorder.showResult(vids[0]); };
      $('#shLink').onclick = () => { Modal.close(); Cloud.shareDialog(this.p); };
    });
  },
  /* ---------- Exportar imagem ---------- */
  exportPng(share) {
    // renderiza o mapa inteiro em resolução própria (até 3000px), independente do zoom atual
    const k = Math.min(1, 3000 / Math.max(this.world.w, this.world.h)), oc = document.createElement('canvas');
    oc.width = Math.round(this.world.w * k); oc.height = Math.round(this.world.h * k);
    const saved = this.view, cam = this.cam; this.view = { s: k, ox: 0, oy: 0 }; this.cam = null;
    this.draw(performance.now(), oc.getContext('2d')); this.view = saved; this.cam = cam; this.dirty = true;
    oc.toBlob(async b => {
      if (!b) return toast('Falha ao gerar imagem.', true);
      const name = (this.p.name || 'estrategia').replace(/[^\w\-]+/g, '_') + '.png';
      if (share) shareFile(b, name, this.p.name); else { download(b, name); toast('Imagem exportada.'); }
    }, 'image/png');
  }
};
Views.estudio = { render() { Studio.resize(); Studio.fillMapSel(); Studio.renderPanel(); Studio.renderKf(); Studio.dirty = true; } };
/* ==========================================================
   ESTÚDIO — painel lateral (camadas, squad, safe, gravação, projeto)
   ========================================================== */
const PTABS = [['camadas', 'Camadas'], ['squad', 'Squad'], ['safe', 'Safe'], ['gravar', 'Gravar'], ['projeto', 'Projeto']];
Studio.panTab = 'squad';
Studio.renderPanel = function () {
  $('#ptabs').innerHTML = PTABS.map(([id, n]) => `<button data-pt="${id}" class="${id === this.panTab ? 'on' : ''}">${n}</button>`).join('');
  $$('#ptabs [data-pt]').forEach(b => b.onclick = () => { this.panTab = b.dataset.pt; this.renderPanel(); });
  const P = this.p, el = $('#pbody');
  if (this.panTab === 'camadas') {
    el.innerHTML = `<h3>Camadas</h3>${LAYERS.map(([id, n]) => `<div class="row pcard"><b>${n}</b><span class="tag">${P.objects.filter(o => o.layer === id).length}</span><span class="sp"></span>
      <label class="small"><input type="checkbox" data-hide="${id}" ${this.hidden[id] ? '' : 'checked'}> visível</label><button class="btn sm" data-act="${id}" ${this.layer === id ? 'disabled' : ''}>${this.layer === id ? 'Ativa' : 'Ativar'}</button></div>`).join('')}
      <h3 style="margin-top:14px">Legenda</h3><div class="small muted">
      Rotas: <span style="color:#00C8FF">━ principal</span> · <span style="color:#FFD23F">╍ alternativa</span> · <span style="color:#FF4D6A">┄ emergência</span><br>
      Ícones: ✕ inimigo · $ moedas · M máquina de compras · V veículo · ▦ parede de gelo · ◆ cobertura · ▲ ponto elevado<br>
      Safe tracejada = previsão do analista · contínua = confirmada na partida.</div>
      <h3 style="margin-top:14px">Atalhos</h3><div class="small muted">Ctrl+Z / Ctrl+Y desfazer/refazer · Ctrl+S salvar · Del excluir seleção · Espaço reproduzir · Enter conclui rota · roda do mouse / pinça = zoom · botão direito ou ferramenta mão = mover mapa.</div>`;
    $$('[data-hide]', el).forEach(c => c.onchange = () => { this.hidden[c.dataset.hide] = !c.checked; this.dirty = true; });
    $$('[data-act]', el).forEach(b => b.onclick = () => { this.layer = b.dataset.act; this.renderCtx(); this.renderPanel(); });
  }
  if (this.panTab === 'squad') {
    el.innerHTML = `<h3>Squad</h3><p class="small muted">Arraste os jogadores com a ferramenta Selecionar. Com keyframes, arrastar grava a posição no tempo atual da linha do tempo.</p>
      ${P.players.map(pl => `<div class="pcard ${this.selPlayer === pl.id ? 'sel' : ''}">
        <div class="row"><span class="pchip" style="background:${pl.color}">${pl.id}</span><div><b>${esc(pl.nick || pl.name || pl.role)}</b><div class="small muted">${pl.role}${pl.char ? ' · ' + esc(pl.char) : ''}</div></div><span class="sp"></span>
        <label class="small"><input type="checkbox" data-vis="${pl.id}" ${pl.visible ? 'checked' : ''}></label></div>
        <div class="small muted" style="margin:6px 0">${pl.primary ? '🔫 ' + esc(pl.primary) : ''}${pl.secondary ? ' / ' + esc(pl.secondary) : ''} ${pl.objective ? '<br>🎯 ' + esc(pl.objective) : ''}</div>
        <div class="row"><button class="btn sm" data-ed="${pl.id}">Editar</button><button class="btn sm" data-selp="${pl.id}">${this.selPlayer === pl.id ? 'Selecionado' : 'Selecionar'}</button>
        <span class="small muted">${(P.keyframes[pl.id] || []).length} keyframes</span>${(P.keyframes[pl.id] || []).length ? `<button class="btn sm" data-clk="${pl.id}">Limpar</button>` : ''}</div></div>`).join('')}
      <p class="small muted">"+ Keyframe" grava o jogador selecionado — ou os quatro, se nenhum estiver selecionado.</p>`;
    $$('[data-vis]', el).forEach(c => c.onchange = () => { P.players.find(p => p.id === c.dataset.vis).visible = c.checked; this.dirty = true; });
    $$('[data-selp]', el).forEach(b => b.onclick = () => { this.selPlayer = this.selPlayer === b.dataset.selp ? null : b.dataset.selp; this.renderPanel(); this.dirty = true; });
    $$('[data-ed]', el).forEach(b => b.onclick = () => this.editPlayer(b.dataset.ed));
    $$('[data-clk]', el).forEach(b => b.onclick = () => { this.snapshot(); const pl = P.players.find(p => p.id === b.dataset.clk); const q = this.posAt(pl, this.t); pl.x = q.x; pl.y = q.y; P.keyframes[pl.id] = []; this.renderKf(); this.renderPanel(); this.dirty = true; });
  }
  if (this.panTab === 'safe') {
    const safes = P.objects.filter(o => o.type === 'zsafe').sort((a, b) => a.phase - b.phase);
    el.innerHTML = `<h3>Planejador de safe</h3><p class="small muted">Use a ferramenta <b>Zona segura</b> (arraste do centro para a borda). Cada safe é marcada como <b>previsão do analista</b> (tracejada) ou <b>confirmada na partida</b> (contínua).</p>
      <button class="btn sm pri" id="sfTool">Desenhar safe</button>
      ${safes.length ? safes.map(o => `<div class="pcard"><div class="row"><b>${o.phase === 4 ? 'Safe final' : o.phase + 'ª safe'}</b><span class="tag ${o.predicted ? 'warn' : 'ok'}">${o.predicted ? 'Previsão' : 'Confirmada'}</span><span class="sp"></span>
        <button class="btn sm" data-tg="${o.id}">${o.predicted ? 'Marcar confirmada' : 'Marcar previsão'}</button><button class="btn sm" data-dl="${o.id}">✕</button></div>
        <input class="in" data-nt="${o.id}" placeholder="Observação (entradas, saídas, confrontos…)" value="${esc(o.note || '')}" style="width:100%;margin-top:6px"></div>`).join('') : '<div class="empty small" style="margin-top:10px">Nenhuma safe marcada.</div>'}
      <h3 style="margin-top:14px">Cenários hipotéticos de fechamento</h3>
      <p class="small muted">Salve o conjunto atual de safes como cenário e alterne entre hipóteses.</p>
      <button class="btn sm" id="scSave">Salvar cenário atual</button>
      ${(P.scenarios || []).map(s => `<div class="row pcard"><b>${esc(s.name)}</b><span class="tag">${s.safes.length} safes</span><span class="sp"></span><button class="btn sm" data-scl="${s.id}">Aplicar</button><button class="btn sm" data-scd="${s.id}">✕</button></div>`).join('')}`;
    $('#sfTool').onclick = () => this.setTool('zsafe');
    $$('[data-tg]', el).forEach(b => b.onclick = () => { this.snapshot(); const o = P.objects.find(x => x.id === b.dataset.tg); o.predicted = !o.predicted; this.dirty = true; this.renderPanel(); });
    $$('[data-dl]', el).forEach(b => b.onclick = () => { this.snapshot(); P.objects = P.objects.filter(x => x.id !== b.dataset.dl); this.dirty = true; this.renderPanel(); });
    $$('[data-nt]', el).forEach(i => i.onchange = () => { P.objects.find(x => x.id === i.dataset.nt).note = i.value; this.dirtyProject = true; this.dirty = true; });
    $('#scSave').onclick = async () => { const n = await Modal.prompt('Nome do cenário:', 'Cenário ' + ((P.scenarios || []).length + 1)); if (!n) return; (P.scenarios = P.scenarios || []).push({ id: uid(), name: n, safes: deep(safes) }); this.dirtyProject = true; this.renderPanel(); };
    $$('[data-scl]', el).forEach(b => b.onclick = () => { const s = P.scenarios.find(x => x.id === b.dataset.scl); this.snapshot(); P.objects = P.objects.filter(o => o.type !== 'zsafe').concat(deep(s.safes).map(o => ({ ...o, id: uid() }))); this.dirty = true; this.renderPanel(); toast('Cenário aplicado: ' + s.name); });
    $$('[data-scd]', el).forEach(b => b.onclick = () => { P.scenarios = P.scenarios.filter(x => x.id !== b.dataset.scd); this.dirtyProject = true; this.renderPanel(); });
  }
  if (this.panTab === 'gravar') Recorder.renderPanel(el);
  if (this.panTab === 'projeto') {
    const f = (k, l, ta) => ta ? `<label class="f">${l}<textarea data-pf="${k}">${esc(P[k] || '')}</textarea></label>` : `<label class="f">${l}<input class="in" data-pf="${k}" value="${esc(P[k] || '')}"></label>`;
    el.innerHTML = `<h3>Dados do projeto</h3><div class="grid">${f('team', 'Nome da equipe')}${f('gameVersion', 'Versão do jogo')}${f('drop', 'Local de queda')}
      ${f('strategy', 'Estratégia inicial', 1)}${f('loot', 'Prioridades de loot / reagrupamento', 1)}${f('rotations', 'Rotações', 1)}${f('notes', 'Observações', 1)}</div>
      <h3 style="margin-top:14px">Medições de treino</h3>
      <p class="small muted">Use a ferramenta Medir para registrar tempos reais de deslocamento.</p>
      ${(P.measurements || []).length ? `<table><tr><th>Trecho</th><th>Dist.</th><th>Tempo</th><th></th></tr>${P.measurements.map(m => `<tr><td>${esc(m.desc)}</td><td>${m.m ? m.m.toFixed(0) + ' m' : m.px.toFixed(0) + ' px'}</td><td>${m.s}s</td><td><button class="btn sm" data-md="${m.id}">✕</button></td></tr>`).join('')}</table>` : '<div class="empty small">Nenhuma medição.</div>'}
      <div class="row" style="margin-top:14px"><button class="btn sm pri" id="pjSave">Salvar projeto</button><button class="btn sm" id="pjExp">Exportar projeto</button></div>`;
    $$('[data-pf]', el).forEach(i => i.oninput = () => { P[i.dataset.pf] = i.value; this.dirtyProject = true; });
    $$('[data-md]', el).forEach(b => b.onclick = () => { P.measurements = P.measurements.filter(m => m.id !== b.dataset.md); this.dirtyProject = true; this.renderPanel(); });
    $('#pjSave').onclick = () => this.saveProject(); $('#pjExp').onclick = () => Projects.exportOne(P);
  }
};
Studio.editPlayer = async function (id) {
  const pl = this.p.players.find(p => p.id === id), chars = await DB.all('chars'), weps = await DB.all('weapons');
  const dl = (lid, arr) => `<datalist id="${lid}">${arr.map(x => `<option value="${esc(x.name)}">`).join('')}</datalist>`;
  const fld = (k, l, list) => `<label class="f">${l}<input class="in" data-k="${k}" value="${esc(pl[k] || '')}" ${list ? `list="${list}"` : ''}></label>`;
  Modal.open(`<h3>${pl.id} — ${pl.role}</h3>${dl('dlc', chars)}${dl('dlw', weps)}
    <div class="grid g2">${fld('name', 'Nome')}${fld('nick', 'Nickname')}${fld('char', 'Personagem ativo', 'dlc')}${fld('passives', 'Habilidades passivas', 'dlc')}
    ${fld('primary', 'Arma principal', 'dlw')}${fld('secondary', 'Arma secundária', 'dlw')}${fld('equip', 'Equipamentos')}
    <label class="f">Cor identificadora<input type="color" data-k="color" value="${pl.color}" style="width:100%;height:34px;border:0;background:none"></label></div>
    <label class="f" style="margin-top:8px">Objetivo tático<input class="in" data-k="objective" value="${esc(pl.objective || '')}"></label>
    <label class="f" style="margin-top:8px">Rota individual / observações<textarea data-k="notes">${esc(pl.notes || '')}</textarea></label>
    <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn" data-x>Cancelar</button><button class="btn pri" data-ok>Salvar</button></div>`, b => {
    b.querySelector('[data-x]').onclick = () => Modal.close();
    b.querySelector('[data-ok]').onclick = () => { $$('[data-k]', b).forEach(i => pl[i.dataset.k] = i.value); this.dirtyProject = true; Modal.close(); this.renderPanel(); this.dirty = true; };
  });
};
/* ==========================================================
   ESTÚDIO DE GRAVAÇÃO — Canvas + microfone + câmera (MediaRecorder)
   ========================================================== */
const REC_MODES = [
  ['1', 'MODE_01 · Mapa + voz'], ['2', 'MODE_02 · Mapa + voz + câmera'], ['3', 'MODE_03 · Mapa + animação tática'],
  ['4', 'MODE_04 · Vídeo de partida + narração'], ['5', 'MODE_05 · Vídeo de partida + desenhos'], ['6', 'MODE_06 · Apresentação tática completa'],
  ['7', 'MODE_07 · Tela do computador + voz + desenhos']
];
const MIMES = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'];
function mediaErr(e, what) { // mensagens claras para falhas de permissão/dispositivo
  const n = e?.name;
  if (n === 'NotAllowedError' || n === 'SecurityError') return `Permissão de ${what} negada. Libere nas configurações do navegador/sistema e tente de novo.`;
  if (n === 'NotFoundError' || n === 'OverconstrainedError') return `Nenhum dispositivo de ${what} compatível encontrado.`;
  if (n === 'NotReadableError' || n === 'AbortError') return `O ${what} está em uso por outro aplicativo ou falhou ao iniciar.`;
  if (!window.isSecureContext) return `O ${what} exige HTTPS.`;
  return `${what[0].toUpperCase() + what.slice(1)} indisponível: ${e?.message || n}`;
}
function pickMime() {
  if (!window.MediaRecorder) return null;
  return MIMES.find(m => { try { return MediaRecorder.isTypeSupported(m); } catch { return false; } }) || '';
}
function fixDuration(v) { // vídeos WebM do MediaRecorder não trazem duração; força o cálculo
  return new Promise(res => {
    const done = () => { v.removeEventListener('durationchange', ch); v.currentTime = 0; res(v.duration); };
    const ch = () => { if (isFinite(v.duration)) done(); };
    const go = () => { if (isFinite(v.duration)) return res(v.duration); v.addEventListener('durationchange', ch); v.currentTime = 1e101; setTimeout(() => { if (!isFinite(v.duration)) { v.removeEventListener('durationchange', ch); res(NaN); } }, 4000); };
    if (v.readyState >= 1) go(); else v.addEventListener('loadedmetadata', go, { once: true });
  });
}
const Media = {
  async save(blob, meta) { const r = { id: 'm-' + uid(), blob, mime: blob.type, size: blob.size, date: Date.now(), ...meta }; await DB.put('media', r); return r; },
  async list(kind) { return (await DB.all('media')).filter(m => kind ? m.kind === kind : m.kind !== 'recpart').sort((a, b) => b.date - a.date); }
};
const AudioMix = {
  ctx: null, get() { if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)(); if (this.ctx.state === 'suspended') this.ctx.resume(); return this.ctx; },
  elSource(el) { if (!el._src) { el._src = this.get().createMediaElementSource(el); el._gain = this.ctx.createGain(); el._src.connect(el._gain); el._gain.connect(this.ctx.destination); } return el._gain; }
};
const Recorder = {
  active: false, paused: false, mode: '1', mic: true, gameAudio: true, rec: null, chunks: [], streams: [], t0: 0, acc: 0, timer: null, mime: '',
  facing: 'user', camId: '', micId: '', devices: { cams: [], mics: [] }, session: null, part: 0, wake: null, meterRaf: 0,
  support() {
    const s = [];
    if (!HTMLCanvasElement.prototype.captureStream) s.push('captura de Canvas');
    if (!window.MediaRecorder) s.push('MediaRecorder');
    if (!navigator.mediaDevices?.getUserMedia) s.push('microfone/câmera (getUserMedia — requer HTTPS)');
    return s;
  },
  canScreen() { return !!navigator.mediaDevices?.getDisplayMedia && !/Android|iPhone|iPad/i.test(navigator.userAgent); },
  async listDevices() {
    try { const d = await navigator.mediaDevices.enumerateDevices(); this.devices = { cams: d.filter(x => x.kind === 'videoinput'), mics: d.filter(x => x.kind === 'audioinput') }; } catch { }
  },
  renderPanel(el) {
    const miss = this.support(), bg = Studio.bgVideo, D = this.devices, modes = REC_MODES.filter(m => m[0] !== '7' || this.canScreen());
    el.innerHTML = `<h3>Estúdio de gravação</h3>
      ${miss.length ? `<div class="pcard small" style="border-color:var(--red)">Este navegador não oferece: ${miss.join(', ')}. A gravação não está disponível aqui.</div>` : ''}
      <label class="f">Modo<select id="rcMode">${modes.map(([v, n]) => `<option value="${v}" ${v === this.mode ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <div class="grid" style="margin:10px 0;gap:6px">
        <label class="small"><input type="checkbox" id="rcMic" ${this.mic ? 'checked' : ''}> Microfone (narração)</label>
        ${D.mics.length > 1 ? `<select id="rcMicSel" class="in" aria-label="Microfone"><option value="">Microfone padrão</option>${D.mics.map(m => `<option value="${m.deviceId}" ${m.deviceId === this.micId ? 'selected' : ''}>${esc(m.label || 'Microfone')}</option>`).join('')}</select>` : ''}
        <label class="small"><input type="checkbox" id="rcGa" ${this.gameAudio ? 'checked' : ''}> Incluir áudio do vídeo/tela, quando disponível</label>
      </div>
      <div class="row"><button class="btn sm" id="rcCam">${Studio.cam ? 'Desligar câmera' : 'Ativar câmera'}</button>
        ${Studio.cam || D.cams.length ? `<button class="btn sm" id="rcFlip">${this.facing === 'user' ? 'Usar câmera traseira' : 'Usar câmera frontal'}</button>` : ''}</div>
      ${D.cams.length > 1 ? `<select id="rcCamSel" class="in" style="margin-top:6px;width:100%" aria-label="Câmera"><option value="">Câmera automática (${this.facing === 'user' ? 'frontal' : 'traseira'})</option>${D.cams.map(m => `<option value="${m.deviceId}" ${m.deviceId === this.camId ? 'selected' : ''}>${esc(m.label || 'Câmera')}</option>`).join('')}</select>` : ''}
      ${Studio.cam ? '<p class="small muted">Arraste/redimensione a janela da câmera sobre o mapa.</p>' : ''}
      <h3 style="margin-top:14px">Vídeo de partida (modos 04/05/06)</h3>
      <div class="row"><button class="btn sm" id="rcBgF">Carregar arquivo</button><button class="btn sm" id="rcBgL">Da biblioteca</button>${bg ? '<button class="btn sm" id="rcBgX">Remover</button>' : ''}</div>
      ${bg ? `<div class="row" style="margin-top:8px"><button class="btn sm" id="rcBgP" aria-label="Reproduzir/pausar vídeo">${bg.paused ? '▶' : '❚❚'}</button><input type="range" id="rcBgS" aria-label="Posição do vídeo" min="0" max="1000" value="${bg.duration ? bg.currentTime / bg.duration * 1000 : 0}" style="flex:1">
        <select id="rcBgR" class="in" style="padding:3px" aria-label="Velocidade">${[0.25, 0.5, 1, 1.5, 2].map(r => `<option ${bg.playbackRate === r ? 'selected' : ''}>${r}</option>`).join('')}</select></div>` : '<p class="small muted">Nenhum vídeo carregado: o fundo é o mapa.</p>'}
      <div style="margin-top:16px">${this.active ? `<button class="btn red" id="rcStop" style="width:100%;justify-content:center">■ Finalizar gravação</button>`
        : `<button class="btn org" id="rcStart" style="width:100%;justify-content:center" ${miss.length ? 'disabled' : ''}>● Iniciar gravação</button>`}</div>
      <p class="small muted">Formato: ${this.mime || pickMime() || 'indisponível'}. Tudo que aparece no mapa (desenhos, jogadores, animações, câmera) entra no vídeo.
      ${window.MediaRecorder && MediaRecorder.prototype.pause ? 'Pausa suportada.' : 'Pausa não suportada neste navegador.'}
      O áudio interno de jogos não é capturado no celular; no computador, só quando o navegador oferece "compartilhar áudio" na captura de tela. Mantenha o app em primeiro plano durante a gravação.</p>
      <h3 style="margin-top:14px">Gravações recentes</h3><div id="rcList" class="small muted">Carregando…</div>`;
    $('#rcMode').onchange = e => { this.mode = e.target.value; if (['2', '6'].includes(this.mode) && !Studio.cam) this.toggleCam(); };
    $('#rcMic').onchange = e => this.mic = e.target.checked; $('#rcGa').onchange = e => this.gameAudio = e.target.checked;
    const ms = $('#rcMicSel'); if (ms) ms.onchange = e => this.micId = e.target.value;
    const cs = $('#rcCamSel'); if (cs) cs.onchange = async e => { this.camId = e.target.value; if (Studio.cam) { await this.toggleCam(); await this.toggleCam(); } };
    const fl = $('#rcFlip'); if (fl) fl.onclick = async () => { this.facing = this.facing === 'user' ? 'environment' : 'user'; this.camId = ''; if (Studio.cam) { await this.toggleCam(); await this.toggleCam(); } else Studio.renderPanel(); };
    $('#rcCam').onclick = () => this.toggleCam();
    $('#rcBgF').onclick = async () => { const f = await pickFile('video/*'); if (f) this.loadBg(f, f.name); };
    $('#rcBgL').onclick = () => this.pickFromLibrary();
    const x = $('#rcBgX'); if (x) x.onclick = () => { this.stopScreen(); Studio.stopBgVideo(); this.renderPanel(el); };
    if (bg) {
      $('#rcBgP').onclick = () => { bg.paused ? (bg.srcObject || AudioMix.elSource(bg), bg.play()) : bg.pause(); this.renderPanel(el); };
      $('#rcBgS').oninput = e => { if (bg.duration && isFinite(bg.duration)) bg.currentTime = e.target.value / 1000 * bg.duration; };
      $('#rcBgR').onchange = e => bg.playbackRate = +e.target.value;
    }
    const st = $('#rcStart'); if (st) st.onclick = () => this.start().catch(e => { this.cleanup(); toast('Falha ao iniciar a gravação: ' + e.message, true); });
    const sp = $('#rcStop'); if (sp) sp.onclick = () => this.stop();
    this.renderList();
  },
  async renderList() {
    const l = $('#rcList'); if (!l) return; const recs = (await Media.list('rec')).slice(0, 8);
    l.innerHTML = recs.length ? recs.map(r => `<div class="row pcard"><div><b style="color:var(--text)">${esc(r.name)}</b><br>${fmtDate(r.date)} · ${fmtBytes(r.size)}</div><span class="sp"></span><button class="btn sm" data-ro="${r.id}">Abrir</button></div>`).join('') : 'Nenhuma gravação ainda.';
    $$('[data-ro]', l).forEach(b => b.onclick = async () => this.showResult(await DB.get('media', b.dataset.ro)));
  },
  async pickFromLibrary() {
    const vids = (await Media.list()).filter(m => m.mime?.startsWith('video/'));
    if (!vids.length) return toast('Nenhum vídeo salvo. Importe em Análise de Partidas ou carregue um arquivo.');
    Modal.open(`<h3>Escolher vídeo</h3>${vids.map(v => `<div class="row pcard"><div><b>${esc(v.name)}</b><div class="small muted">${v.kind === 'vod' ? 'Partida' : 'Gravação'} · ${fmtBytes(v.size)}</div></div><span class="sp"></span><button class="btn sm pri" data-pk="${v.id}">Usar</button></div>`).join('')}
      <div class="row" style="justify-content:flex-end"><button class="btn" data-x>Fechar</button></div>`, b => {
      b.querySelector('[data-x]').onclick = () => Modal.close();
      $$('[data-pk]', b).forEach(x => x.onclick = () => { const v = vids.find(q => q.id === x.dataset.pk); Modal.close(); this.loadBg(v.blob, v.name); });
    });
  },
  loadBg(blob, name) {
    const v = document.createElement('video'); v.src = URL.createObjectURL(blob); v.playsInline = true; v.preload = 'auto';
    v.onerror = () => toast('Formato/codec de vídeo não suportado por este navegador. Converta para MP4 (H.264) e tente de novo.', true);
    Studio.setBgVideo(v); toast('Vídeo de partida carregado: ' + name); if (this.mode < '4') this.mode = '5'; Studio.renderPanel();
  },
  async toggleCam() {
    if (Studio.cam) { Studio.cam.stream.getTracks().forEach(t => t.stop()); Studio.cam = null; $('#camWin').classList.remove('on'); Studio.renderPanel(); Studio.dirty = true; return; }
    if (!navigator.mediaDevices?.getUserMedia) return toast(mediaErr({}, 'câmera'), true);
    const base = { width: { ideal: 1280 }, height: { ideal: 720 } };
    const tries = [this.camId ? { ...base, deviceId: { exact: this.camId } } : { ...base, facingMode: this.facing }, { facingMode: this.facing }, true];
    let stream, err;
    for (const v of tries) { try { stream = await navigator.mediaDevices.getUserMedia({ video: v, audio: false }); break; } catch (e) { err = e; if (e.name === 'NotAllowedError') break; } }
    if (!stream) return toast(mediaErr(err, 'câmera'), true);
    const video = $('#camVid'); video.srcObject = stream; await video.play().catch(() => { });
    const set = stream.getVideoTracks()[0].getSettings?.() || {}, mirror = (set.facingMode || this.facing) !== 'environment';
    const W = Studio.W, w = Math.max(140, Math.min(260, W * .28)), rect = { x: W - w - 14, y: Math.max(10, Studio.H - w * .75 - 60), w, h: w * .75 };
    stream.getVideoTracks()[0].onended = () => { if (Studio.cam?.stream === stream) { toast('A câmera foi desconectada.', true); Studio.cam = null; $('#camWin').classList.remove('on'); } };
    Studio.cam = { stream, video, rect, mirror }; this.placeCamWin(); $('#camWin').classList.add('on');
    await this.listDevices(); Studio.renderPanel();
  },
  placeCamWin() { const r = Studio.cam.rect, w = $('#camWin'); Object.assign(w.style, { left: r.x + 'px', top: r.y + 'px', width: r.w + 'px', height: r.h + 'px' }); },
  bindCamWin() {
    const w = $('#camWin'), rs = $('#camRs'); let d = null;
    $('#camVid').style.opacity = '0'; // a câmera é desenhada no canvas (entra no vídeo); a janela é só a alça
    w.style.background = 'transparent';
    w.addEventListener('pointerdown', e => { if (!Studio.cam) return; w.setPointerCapture(e.pointerId); const r = Studio.cam.rect; d = { mode: e.target === rs ? 'rs' : 'mv', x: e.clientX, y: e.clientY, r: { ...r } }; e.stopPropagation(); });
    w.addEventListener('pointermove', e => {
      if (!d) return; const r = Studio.cam.rect, dx = e.clientX - d.x, dy = e.clientY - d.y;
      if (d.mode === 'mv') { r.x = clamp(d.r.x + dx, 0, Studio.W - r.w); r.y = clamp(d.r.y + dy, 0, Studio.H - r.h); }
      else { r.w = clamp(d.r.w + dx, 100, Studio.W * .8); r.h = r.w * .75; }
      this.placeCamWin(); Studio.dirty = true;
    });
    w.addEventListener('pointerup', () => d = null);
  },
  async startScreen() { // MODE_07: captura de tela (computador) como fundo, com desenhos por cima
    let s; try { s = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 30 }, audio: true }); } catch (e) { throw new Error(mediaErr(e, 'captura de tela')); }
    const v = document.createElement('video'); v.srcObject = s; v.muted = true; v.playsInline = true; await v.play().catch(() => { });
    this.screen = s; Studio.setBgVideo(v);
    s.getVideoTracks()[0].onended = () => { if (this.active) { toast('Captura de tela encerrada — finalizando gravação.'); this.stop(); } };
    if (!s.getAudioTracks().length && this.gameAudio) toast('O navegador não forneceu áudio da tela/sistema; gravando apenas o microfone.');
    return s;
  },
  stopScreen() { if (this.screen) { this.screen.getTracks().forEach(t => t.stop()); this.screen = null; Studio.stopBgVideo(); } },
  makeRecorder(stream) { // tenta cada formato até um funcionar (codecs variam por navegador)
    const q = { alta: 6e6, media: 3e6, baixa: 1.5e6 }[Settings.data.recQuality] || 4e6;
    const list = MIMES.filter(m => { try { return MediaRecorder.isTypeSupported(m); } catch { return false; } });
    for (const m of [...list, '']) { try { const r = new MediaRecorder(stream, m ? { mimeType: m, videoBitsPerSecond: q, audioBitsPerSecond: 128000 } : undefined); this.mime = r.mimeType || m || 'video/webm'; return r; } catch (e) { console.warn('codec recusado', m, e); } }
    throw new Error('nenhum formato de vídeo suportado por este navegador');
  },
  meter(stream) {
    try {
      const ctx = AudioMix.get(), an = ctx.createAnalyser(); an.fftSize = 512; ctx.createMediaStreamSource(stream).connect(an);
      const buf = new Uint8Array(an.fftSize), el = $('#recMeter');
      const loop = () => { an.getByteTimeDomainData(buf); let m = 0; for (const v of buf) m = Math.max(m, Math.abs(v - 128)); el.style.width = Math.min(100, m / 1.28 * 1.6) + '%'; el.style.background = m > 115 ? 'var(--red)' : 'var(--green)'; if (this.active) this.meterRaf = requestAnimationFrame(loop); };
      loop();
    } catch { }
  },
  async start() {
    if (this.active) return;
    const m = this.mode, needBg = ['4', '5'].includes(m);
    if (needBg && !Studio.bgVideo) return toast('Carregue um vídeo de partida para este modo.', true);
    if (['2', '6'].includes(m) && !Studio.cam) { await this.toggleCam(); if (!Studio.cam && m === '2') return; }
    if (!window.MediaRecorder) return toast('MediaRecorder indisponível neste navegador.', true);
    if (m === '7') await this.startScreen();
    const fps = +Settings.data.recFps || 30, vs = Studio.cv.captureStream(fps), tracks = [...vs.getVideoTracks()]; this.streams = [vs];
    let micStream = null;
    if (this.mic) {
      try { micStream = await navigator.mediaDevices.getUserMedia({ audio: { deviceId: this.micId ? { exact: this.micId } : undefined, echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); this.streams.push(micStream); }
      catch (e) { toast(mediaErr(e, 'microfone') + ' Gravando sem voz.', true); }
    }
    const bg = Studio.bgVideo, scrAudio = this.screen?.getAudioTracks().length ? this.screen : null, useBgAudio = bg && !bg.srcObject && this.gameAudio;
    if (useBgAudio || (scrAudio && this.gameAudio)) { // mistura microfone + áudio do vídeo/tela
      const ctx = AudioMix.get(), dest = ctx.createMediaStreamDestination();
      if (micStream) ctx.createMediaStreamSource(micStream).connect(dest);
      if (useBgAudio) AudioMix.elSource(bg).connect(dest); else ctx.createMediaStreamSource(scrAudio).connect(dest);
      this.dest = dest; tracks.push(...dest.stream.getAudioTracks());
    } else if (micStream) tracks.push(...micStream.getAudioTracks());
    this.rec = this.makeRecorder(new MediaStream(tracks));
    this.chunks = []; this.session = 'rs-' + uid(); this.part = 0;
    const recName = (Studio.p.name || 'analise').replace(/[^\w\-]+/g, '_');
    this.rec.ondataavailable = e => { if (!e.data.size) return; this.chunks.push(e.data);
      // grava cada pedaço no aparelho: se o app fechar/travar, a gravação pode ser recuperada
      DB.put('media', { id: this.session + '-' + String(this.part++).padStart(5, '0'), kind: 'recpart', session: this.session, blob: e.data, mime: this.mime, name: recName, projectId: Studio.p.id, date: Date.now(), size: e.data.size }, { silent: true }).catch(() => { }); };
    this.rec.onstop = () => this.finish(); this.rec.onerror = e => { toast('Erro na gravação: ' + (e.error?.message || e.error?.name || 'desconhecido') + '. O que já foi gravado será salvo.', true); if (this.rec.state !== 'inactive') this.rec.stop(); };
    const badge = $('#recBadge'); badge.classList.add('on'); $('#bRecPause').style.display = 'none'; $('#bRecStop').style.display = 'none';
    for (let i = 3; i > 0; i--) { $('#recTime').textContent = 'Começa em ' + i; await new Promise(r => setTimeout(r, 800)); }
    $('#bRecPause').style.display = this.rec.pause ? '' : 'none'; $('#bRecStop').style.display = '';
    this.rec.start(1000); this.active = true; this.paused = false; this.t0 = performance.now(); this.acc = 0; document.body.classList.add('rec');
    try { this.wake = await navigator.wakeLock?.request('screen'); } catch { }
    if (micStream) this.meter(micStream);
    if (['3', '6'].includes(m)) { Studio.t = 0; Studio.playing = true; $('#bPlay').textContent = '❚❚'; }
    if (bg && (needBg || m === '6') && !bg.srcObject) { AudioMix.elSource(bg); bg.play().catch(() => { }); }
    this.timer = setInterval(() => $('#recTime').textContent = fmtT(this.elapsed()), 250);
    Studio.renderPanel(); $('#bRecOpen').textContent = '■ Parar';
  },
  elapsed() { return (this.acc + (this.paused ? 0 : performance.now() - this.t0)) / 1000; },
  togglePause() {
    if (!this.active || !this.rec.pause) return;
    if (!this.paused) { this.rec.pause(); this.acc += performance.now() - this.t0; this.paused = true; Studio.playing = false; if (!Studio.bgVideo?.srcObject) Studio.bgVideo?.pause(); $('#bRecPause').textContent = 'Continuar'; }
    else { this.rec.resume(); this.t0 = performance.now(); this.paused = false; $('#bRecPause').textContent = 'Pausar'; }
  },
  stop() { if (!this.active || !this.rec) return; this.dur = this.elapsed(); if (this.rec.state !== 'inactive') this.rec.stop(); },
  cleanup() {
    clearInterval(this.timer); cancelAnimationFrame(this.meterRaf); this.active = false; $('#recBadge').classList.remove('on'); $('#bRecOpen').textContent = '● Gravar';
    document.body.classList.remove('rec'); this.streams.forEach(s => s.getTracks().forEach(t => t.stop())); this.streams = []; this.stopScreen();
    try { this.wake?.release(); } catch { } this.wake = null;
    Studio.playing = false; $('#bPlay').textContent = '▶'; Studio.bgVideo?.pause?.();
  },
  async finish() {
    this.cleanup();
    const blob = new Blob(this.chunks, { type: (this.mime || 'video/webm').split(';')[0] }); this.chunks = [];
    if (!blob.size) { Studio.renderPanel(); return toast('A gravação ficou vazia.', true); }
    const ext = blob.type.includes('mp4') ? 'mp4' : 'webm', name = `${(Studio.p.name || 'analise').replace(/[^\w\-]+/g, '_')}_${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}.${ext}`;
    let rec;
    try { rec = await Media.save(blob, { kind: 'rec', name, duration: this.dur, projectId: Studio.p.id, mode: this.mode }); (Studio.p.videos = Studio.p.videos || []).push(rec.id); Studio.dirtyProject = true; await this.dropParts(this.session); }
    catch (e) { toast('Não foi possível salvar no aparelho (espaço?). Baixe o vídeo agora.', true); rec = { id: null, blob, name, size: blob.size, date: Date.now() }; }
    Studio.renderPanel(); this.showResult(rec);
  },
  async dropParts(session) { for (const p of (await DB.all('media')).filter(m => m.kind === 'recpart' && (!session || m.session === session))) await DB.del('media', p.id, { silent: true }); },
  async recoverOrphans() { // gravações interrompidas (app fechado, travamento, bateria)
    if (this.active) return;
    const parts = (await DB.all('media')).filter(m => m.kind === 'recpart'); if (!parts.length) return;
    const sessions = [...new Set(parts.map(p => p.session))];
    for (const s of sessions) {
      const ps = parts.filter(p => p.session === s).sort((a, b) => a.id.localeCompare(b.id)), size = ps.reduce((t, p) => t + p.size, 0);
      if (await Modal.confirm(`Foi encontrada uma gravação interrompida ("${ps[0].name}", ${fmtBytes(size)}, ${fmtDate(ps[0].date)}). Recuperar o que foi gravado?`, 'Recuperar')) {
        const blob = new Blob(ps.map(p => p.blob), { type: (ps[0].mime || 'video/webm').split(';')[0] });
        const r = await Media.save(blob, { kind: 'rec', name: ps[0].name + '_recuperado.' + (blob.type.includes('mp4') ? 'mp4' : 'webm'), projectId: ps[0].projectId, recovered: true });
        await this.dropParts(s); toast('Gravação recuperada.'); this.showResult(r); return;
      } else if (await Modal.confirm('Descartar definitivamente esta gravação interrompida?', 'Descartar', true)) await this.dropParts(s);
    }
  },
  showResult(r) {
    if (!r) return; const url = URL.createObjectURL(r.blob);
    Modal.open(`<h3>${esc(r.name)}</h3><video id="resV" src="${url}" controls playsinline style="width:100%;border-radius:10px;background:#000;max-height:50vh"></video>
      <p class="small muted">${fmtBytes(r.size)} · ${fmtDate(r.date)}${r.duration ? ' · ' + fmtT(r.duration) : ''}</p>
      <div class="row"><button class="btn pri" id="resD">Baixar</button><button class="btn" id="resS">Compartilhar</button><button class="btn" id="resE">Abrir no editor</button>
      ${r.id ? '<button class="btn red" id="resX">Excluir</button>' : ''}<span class="sp"></span><button class="btn" data-x>Fechar</button></div>`, b => {
      fixDuration($('#resV'));
      b.querySelector('[data-x]').onclick = () => { Modal.close(); URL.revokeObjectURL(url); };
      $('#resD').onclick = () => download(r.blob, r.name); $('#resS').onclick = () => shareFile(r.blob, r.name);
      $('#resE').onclick = () => { Modal.close(); go('video'); VEditor.addMedia(r); };
      const x = $('#resX'); if (x) x.onclick = async () => { if (await Modal.confirm('Excluir esta gravação do aparelho?', 'Excluir', true)) { await DB.del('media', r.id); Modal.close(); this.renderList(); toast('Gravação excluída.'); } };
    });
  }
};
$('#bRecOpen').onclick = () => { if (Recorder.active) return Recorder.stop(); Studio.panTab = 'gravar'; $('#panel').classList.remove('closed'); Studio.renderPanel(); };
$('#bRecStop').onclick = () => Recorder.stop(); $('#bRecPause').onclick = () => Recorder.togglePause();
document.addEventListener('visibilitychange', () => { // celulares congelam a aba em segundo plano
  if (!Recorder.active) return;
  if (document.hidden) { if (Recorder.rec?.pause && !Recorder.paused) { Recorder.togglePause(); Recorder.autoPaused = true; } }
  else { if (Recorder.autoPaused) { Recorder.autoPaused = false; toast('A gravação foi pausada enquanto o app estava em segundo plano. Toque em Continuar.'); }
    if (Recorder.wake?.released !== false) navigator.wakeLock?.request('screen').then(w => Recorder.wake = w).catch(() => { }); }
});
/* ==========================================================
   EDITOR DE VÍDEO — timeline não destrutiva
   (os arquivos originais não são alterados; cortes são pontos in/out)
   ========================================================== */
const VEditor = {
  d: { clips: [], audio: [], pip: [], texts: [] }, els: {}, urls: {}, T: 0, playing: false, sel: null, pps: 40,
  cv: null, ctx: null, cur: null, lastTs: 0, exporting: false, narr: null, built: false,
  async load() { const s = await DB.kv('veditor'); if (s) this.d = Object.assign({ clips: [], audio: [], pip: [], texts: [] }, s); },
  save() { return DB.kv('veditor', this.d); },
  dur(c) { return (c.out - c.in) / (c.speed || 1); },
  layout() { let t = 0; return this.d.clips.map(c => { const r = { c, start: t, end: t + this.dur(c) }; t = r.end; return r; }); },
  total() {
    const L = this.layout(); let e = L.at(-1)?.end || 0;
    [...this.d.audio, ...this.d.pip].forEach(a => e = Math.max(e, a.start + (a.out - a.in)));
    this.d.texts.forEach(x => e = Math.max(e, x.start + x.dur)); return e;
  },
  async el(mediaId, kind = 'video') {
    if (this.els[mediaId]) return this.els[mediaId];
    const m = await DB.get('media', mediaId); if (!m) return null;
    const e = document.createElement(kind === 'audio' && !m.mime?.startsWith('video') ? 'audio' : 'video');
    e.src = this.urls[mediaId] = URL.createObjectURL(m.blob); e.preload = 'auto'; e.playsInline = true;
    await new Promise(r => { e.onloadedmetadata = r; e.onerror = r; setTimeout(r, 5000); });
    if (!isFinite(e.duration) && e.tagName === 'VIDEO') await fixDuration(e);
    this.els[mediaId] = e; return e;
  },
  async addMedia(m) {
    const isAudio = m.mime?.startsWith('audio');
    const e = await this.el(m.id, isAudio ? 'audio' : 'video'); if (!e) return toast('Mídia não encontrada.', true);
    const D = isFinite(e.duration) ? e.duration : (m.duration || 10);
    if (isAudio) this.d.audio.push({ id: uid(), mediaId: m.id, name: m.name, start: this.T, in: 0, out: D, vol: 1 });
    else this.d.clips.push({ id: uid(), mediaId: m.id, name: m.name, in: 0, out: D, speed: 1, vol: 1, zoom: 1 });
    await this.save(); this.render(); toast('Adicionado à timeline: ' + m.name);
  },
  async importFiles(kind) {
    const fs = await pickFile(kind === 'audio' ? 'audio/*' : 'video/*', true); if (!fs?.length) return;
    for (const f of fs) {
      const m = await Media.save(f, { kind: 'import', name: f.name });
      if (kind === 'pip') { const e = await this.el(m.id); this.d.pip.push({ id: uid(), mediaId: m.id, name: f.name, start: this.T, in: 0, out: e?.duration || 10, vol: 1, x: .72, y: .68, w: .26 }); await this.save(); this.render(); }
      else await this.addMedia(m);
    }
  },
  /* ---------- Interface ---------- */
  render() {
    const el = $('#v-video');
    if (!this.built) {
      el.innerHTML = `<div class="ved"><div class="row"><h2 style="margin:0">Editor de vídeo</h2><span class="sp"></span>
        <button class="btn sm" id="veImpV">+ Vídeo</button><button class="btn sm" id="veImpA">+ Áudio</button><button class="btn sm" id="veImpP">+ Câmera/PiP</button>
        <button class="btn sm" id="veLib">Biblioteca</button><button class="btn sm" id="veTxt">+ Texto</button><button class="btn sm" id="veArr">+ Seta animada</button>
        <button class="btn sm" id="veNar">🎙 Gravar narração</button><button class="btn sm org" id="veExp">Exportar</button></div>
        <div class="glass" style="padding:10px"><div class="vprev"><canvas id="vcv" width="1280" height="720"></canvas></div>
          <div class="row" style="margin-top:8px"><button class="btn sm" id="veHome">⏮</button><button class="btn sm pri" id="vePlay">▶</button><span class="small" id="veTime">00:00 / 00:00</span><span class="sp"></span>
          <button class="btn sm" id="veSplit">✂ Dividir</button><button class="btn sm" id="veDel">Excluir</button><button class="btn sm" id="veL">◀ Mover</button><button class="btn sm" id="veR">Mover ▶</button>
          <label class="small muted">Zoom <input type="range" id="vePps" min="5" max="200" value="${this.pps}"></label></div></div>
        <div class="grid" style="grid-template-columns:minmax(0,1fr) 300px;gap:12px" id="veBottom"><div class="glass tl" id="veTl"></div><div class="glass card" id="veProps"></div></div></div>`;
      this.cv = $('#vcv'); this.ctx = this.cv.getContext('2d'); this.built = true;
      $('#veImpV').onclick = () => this.importFiles('video'); $('#veImpA').onclick = () => this.importFiles('audio'); $('#veImpP').onclick = () => this.importFiles('pip');
      $('#veLib').onclick = () => this.library();
      $('#veTxt').onclick = () => { this.d.texts.push({ id: uid(), kind: 'text', start: this.T, dur: 3, text: 'Texto', x: .5, y: .15, size: 56, color: '#FFFFFF' }); this.sel = this.d.texts.at(-1).id; this.save(); this.render(); };
      $('#veArr').onclick = () => { this.d.texts.push({ id: uid(), kind: 'arrow', start: this.T, dur: 3, x: .3, y: .7, x2: .65, y2: .4, size: 10, color: '#FF8A30', text: '' }); this.sel = this.d.texts.at(-1).id; this.save(); this.render(); };
      $('#vePlay').onclick = () => this.togglePlay(); $('#veHome').onclick = () => this.seek(0);
      $('#veSplit').onclick = () => this.split(); $('#veDel').onclick = () => this.delSel();
      $('#veL').onclick = () => this.moveSel(-1); $('#veR').onclick = () => this.moveSel(1);
      $('#vePps').oninput = e => { this.pps = +e.target.value; this.renderTl(); };
      $('#veExp').onclick = () => this.export(); $('#veNar').onclick = () => this.narrate();
      if (matchMedia('(max-width:860px)').matches) $('#veBottom').style.gridTemplateColumns = '1fr';
      requestAnimationFrame(t => this.loop(t));
    }
    this.renderTl(); this.renderProps(); this.drawFrame();
  },
  renderTl() {
    const L = this.layout(), tot = Math.max(10, this.total() + 5), W = tot * this.pps, pps = this.pps;
    const step = pps > 80 ? 1 : pps > 30 ? 5 : pps > 12 ? 10 : 30;
    let ruler = ''; for (let s = 0; s <= tot; s += step) ruler += `<span style="left:${s * pps}px">${fmtT(s)}</span>`;
    const item = (cls, id, l, w, txt) => `<div class="clip ${cls} ${this.sel === id ? 'sel' : ''}" data-it="${id}" style="left:${l}px;width:${Math.max(8, w)}px">${esc(txt)}</div>`;
    $('#veTl').innerHTML = `<div class="tlin" style="width:${W + 70}px"><div class="ruler" id="veRuler">${ruler}</div>
      <div class="track"><span class="lbl">Vídeo</span>${L.map(r => item('v', r.c.id, r.start * pps, (r.end - r.start) * pps, `${r.c.name} ${r.c.speed !== 1 ? '×' + r.c.speed : ''}`)).join('')}</div>
      <div class="track"><span class="lbl">Câmera</span>${this.d.pip.map(a => item('v', a.id, a.start * pps, (a.out - a.in) * pps, a.name)).join('')}</div>
      <div class="track"><span class="lbl">Áudio</span>${this.d.audio.map(a => item('a', a.id, a.start * pps, (a.out - a.in) * pps, a.name)).join('')}</div>
      <div class="track"><span class="lbl">Textos</span>${this.d.texts.map(x => item('t', x.id, x.start * pps, x.dur * pps, x.kind === 'arrow' ? '➜ seta' : x.text)).join('')}</div>
      <div class="tlph" id="vePh" style="left:${64 + this.T * pps + 8}px"></div></div>
      ${!this.d.clips.length ? '<div class="small muted" style="padding:8px">Importe vídeos, use gravações do Estúdio ("Abrir no editor") ou a Biblioteca.</div>' : ''}`;
    $('#veRuler').onpointerdown = e => { const r = e.currentTarget.getBoundingClientRect(); this.seek((e.clientX - r.left) / pps); };
    $$('#veTl [data-it]').forEach(d => {
      d.onpointerdown = e => {
        this.sel = d.dataset.it; $$('#veTl .clip').forEach(c => c.classList.toggle('sel', c === d)); this.renderProps();
        const it = this.find(this.sel); if (!it || it.type === 'clip') return; // arrastar itens de áudio/câmera/texto no tempo
        d.setPointerCapture(e.pointerId); const x0 = e.clientX, s0 = it.o.start;
        d.onpointermove = ev => { it.o.start = Math.max(0, s0 + (ev.clientX - x0) / pps); d.style.left = it.o.start * pps + 'px'; };
        d.onpointerup = () => { d.onpointermove = null; this.save(); this.renderProps(); };
      };
    });
    $('#veTime').textContent = `${fmtT(this.T)} / ${fmtT(this.total())}`;
  },
  find(id) {
    let o = this.d.clips.find(x => x.id === id); if (o) return { type: 'clip', o };
    o = this.d.audio.find(x => x.id === id); if (o) return { type: 'audio', o };
    o = this.d.pip.find(x => x.id === id); if (o) return { type: 'pip', o };
    o = this.d.texts.find(x => x.id === id); if (o) return { type: 'text', o }; return null;
  },
  renderProps() {
    const el = $('#veProps'), it = this.sel && this.find(this.sel);
    if (!it) { el.innerHTML = `<h3>Propriedades</h3><p class="small muted">Selecione um item na timeline. Itens de áudio, câmera e texto podem ser arrastados no tempo.</p>`; return; }
    const o = it.o, n = (k, l, step = .1, min = 0, max) => `<label class="f">${l}<input class="in" type="number" data-p="${k}" value="${+(+o[k]).toFixed(2)}" step="${step}" min="${min}" ${max != null ? `max="${max}"` : ''}></label>`;
    let h = `<h3>${{ clip: 'Clipe de vídeo', audio: 'Áudio', pip: 'Câmera / PiP', text: o.kind === 'arrow' ? 'Seta animada' : 'Texto' }[it.type]}</h3>`;
    if (it.type === 'clip') h += `<div class="small muted">${esc(o.name)}</div><div class="grid g2" style="grid-template-columns:1fr 1fr">${n('in', 'Início (s)')}${n('out', 'Fim (s)')}${n('speed', 'Velocidade', .25, .25, 4)}${n('vol', 'Volume', .1, 0, 2)}${n('zoom', 'Zoom', .1, 1, 4)}</div>
      <div class="row" style="margin-top:8px"><button class="btn sm" id="vpIn">Início = cursor</button><button class="btn sm" id="vpOut">Fim = cursor</button></div>`;
    if (it.type === 'audio' || it.type === 'pip') h += `<div class="small muted">${esc(o.name)}</div><div class="grid" style="grid-template-columns:1fr 1fr">${n('start', 'Posição (s)')}${n('in', 'Corte início')}${n('out', 'Corte fim')}${n('vol', 'Volume', .1, 0, 2)}
      ${it.type === 'pip' ? n('x', 'X (0–1)', .01, 0, 1) + n('y', 'Y (0–1)', .01, 0, 1) + n('w', 'Largura (0–1)', .01, .1, 1) : ''}</div>`;
    if (it.type === 'text') h += `${o.kind === 'text' ? `<label class="f">Texto<input class="in" data-p="text" data-s value="${esc(o.text)}"></label>` : `<label class="f">Rótulo (opcional)<input class="in" data-p="text" data-s value="${esc(o.text)}"></label>`}
      <div class="grid" style="grid-template-columns:1fr 1fr;margin-top:6px">${n('start', 'Início (s)')}${n('dur', 'Duração (s)', .1, .2)}${n('x', 'X (0–1)', .01, 0, 1)}${n('y', 'Y (0–1)', .01, 0, 1)}
      ${o.kind === 'arrow' ? n('x2', 'X final', .01, 0, 1) + n('y2', 'Y final', .01, 0, 1) : ''}${n('size', o.kind === 'arrow' ? 'Espessura' : 'Tamanho', 1, 4, 200)}
      <label class="f">Cor<input type="color" data-p="color" data-s value="${o.color}" style="width:100%;height:32px;border:0;background:none"></label></div>`;
    el.innerHTML = h;
    $$('[data-p]', el).forEach(i => i.onchange = () => {
      o[i.dataset.p] = i.hasAttribute('data-s') ? i.value : +i.value;
      if (it.type !== 'text') { const max = this.els[o.mediaId]?.duration || 1e9; o.in = clamp(o.in, 0, max); o.out = clamp(o.out, o.in + .1, max); }
      this.save(); this.renderTl(); this.drawFrame();
    });
    const vi = $('#vpIn'), vo = $('#vpOut');
    if (vi) vi.onclick = () => { const r = this.layout().find(x => x.c.id === o.id); const loc = o.in + (this.T - r.start) * o.speed; if (loc > o.in && loc < o.out) { o.in = loc; this.save(); this.render(); } else toast('Posicione o cursor dentro deste clipe.'); };
    if (vo) vo.onclick = () => { const r = this.layout().find(x => x.c.id === o.id); const loc = o.in + (this.T - r.start) * o.speed; if (loc > o.in && loc < o.out) { o.out = loc; this.save(); this.render(); } else toast('Posicione o cursor dentro deste clipe.'); };
  },
  async library() {
    const all = (await Media.list()).filter(m => m.kind !== 'mapimg');
    Modal.open(`<h3>Biblioteca de mídia</h3>${all.length ? all.map(m => `<div class="row pcard"><div><b>${esc(m.name)}</b><div class="small muted">${{ rec: 'Gravação', vod: 'Partida', import: 'Importado', narr: 'Narração' }[m.kind] || m.kind} · ${fmtBytes(m.size)} · ${fmtDate(m.date)}</div></div><span class="sp"></span><button class="btn sm pri" data-ad="${m.id}">Adicionar</button></div>`).join('') : '<div class="empty">Sem mídias.</div>'}
      <div class="row" style="justify-content:flex-end"><button class="btn" data-x>Fechar</button></div>`, b => {
      b.querySelector('[data-x]').onclick = () => Modal.close();
      $$('[data-ad]', b).forEach(x => x.onclick = async () => { Modal.close(); await this.addMedia(all.find(m => m.id === x.dataset.ad)); });
    });
  },
  split() {
    const r = this.layout().find(x => this.T > x.start + .05 && this.T < x.end - .05); if (!r) return toast('Posicione o cursor sobre um clipe de vídeo.');
    const c = r.c, loc = c.in + (this.T - r.start) * c.speed, n = { ...deep(c), id: uid(), in: loc }; c.out = loc;
    this.d.clips.splice(this.d.clips.indexOf(c) + 1, 0, n); this.save(); this.render(); toast('Clipe dividido.');
  },
  delSel() {
    const it = this.sel && this.find(this.sel); if (!it) return toast('Selecione um item.');
    const k = { clip: 'clips', audio: 'audio', pip: 'pip', text: 'texts' }[it.type]; this.d[k] = this.d[k].filter(x => x.id !== this.sel); this.sel = null; this.save(); this.render();
  },
  moveSel(dir) {
    const i = this.d.clips.findIndex(c => c.id === this.sel); if (i < 0) return toast('Selecione um clipe de vídeo.');
    const j = i + dir; if (j < 0 || j >= this.d.clips.length) return; [this.d.clips[i], this.d.clips[j]] = [this.d.clips[j], this.d.clips[i]]; this.save(); this.renderTl();
  },
  /* ---------- Reprodução ---------- */
  pauseAll() { Object.values(this.els).forEach(e => e.pause()); this.cur = null; },
  seek(t) { this.T = clamp(t, 0, this.total()); if (this.playing) this.pauseAll(); this.renderTl(); this.drawFrame(); },
  togglePlay() {
    if (this.playing) { this.playing = false; this.pauseAll(); } else { if (this.T >= this.total() - .05) this.T = 0; this.playing = true; AudioMix.get(); }
    $('#vePlay').textContent = this.playing ? '❚❚' : '▶';
  },
  async drawFrame() { // quadro parado (sem reprodução)
    if (this.playing || !this.ctx) return;
    const r = this.layout().find(x => this.T >= x.start && this.T < x.end) || null;
    if (r) { const e = await this.el(r.c.mediaId); if (e) { const t = r.c.in + (this.T - r.start) * r.c.speed; if (Math.abs(e.currentTime - t) > .04) { e.currentTime = t; await new Promise(res => { e.onseeked = res; setTimeout(res, 800); }); } } }
    for (const p of this.d.pip) if (this.T >= p.start && this.T < p.start + p.out - p.in) { const e = await this.el(p.mediaId); if (e) { e.currentTime = p.in + this.T - p.start; await new Promise(res => { e.onseeked = res; setTimeout(res, 600); }); } }
    this.paint(r);
  },
  paint(r) {
    const c = this.ctx, W = 1280, H = 720; c.fillStyle = '#000'; c.fillRect(0, 0, W, H);
    if (r) {
      const e = this.els[r.c.mediaId];
      if (e && e.readyState >= 2) { const s = Math.min(W / e.videoWidth, H / e.videoHeight) * (r.c.zoom || 1), w = e.videoWidth * s, h = e.videoHeight * s; c.drawImage(e, (W - w) / 2, (H - h) / 2, w, h); }
    } else if (!this.d.clips.length) { c.fillStyle = '#10243A'; c.fillRect(0, 0, W, H); c.fillStyle = '#8EA3BF'; c.font = '600 28px system-ui'; c.textAlign = 'center'; c.fillText('Timeline vazia', W / 2, H / 2); }
    for (const p of this.d.pip) {
      if (this.T < p.start || this.T >= p.start + p.out - p.in) continue; const e = this.els[p.mediaId]; if (!e || e.readyState < 2) continue;
      const w = p.w * W, h = w * e.videoHeight / e.videoWidth, x = p.x * W - w / 2, y = p.y * H - h / 2;
      c.save(); c.beginPath(); c.roundRect ? c.roundRect(x, y, w, h, 14) : c.rect(x, y, w, h); c.clip(); c.drawImage(e, x, y, w, h); c.restore();
      c.strokeStyle = '#00C8FF'; c.lineWidth = 3; c.beginPath(); c.roundRect ? c.roundRect(x, y, w, h, 14) : c.rect(x, y, w, h); c.stroke();
    }
    for (const x of this.d.texts) {
      if (this.T < x.start || this.T >= x.start + x.dur) continue; const u = clamp((this.T - x.start) / Math.min(.6, x.dur / 2), 0, 1);
      c.save(); c.globalAlpha = Math.min(1, u * 2);
      if (x.kind === 'text') { c.font = `800 ${x.size}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineWidth = x.size * .16; c.strokeStyle = 'rgba(0,0,0,.8)'; c.strokeText(x.text, x.x * W, x.y * H); c.fillStyle = x.color; c.fillText(x.text, x.x * W, x.y * H); }
      else {
        const ax = x.x * W, ay = x.y * H, bx = ax + (x.x2 * W - ax) * u, by = ay + (x.y2 * H - ay) * u, ang = Math.atan2(by - ay, bx - ax), hs = x.size * 3.5;
        c.strokeStyle = c.fillStyle = x.color; c.lineWidth = x.size; c.lineCap = 'round'; c.shadowColor = 'rgba(0,0,0,.6)'; c.shadowBlur = 8;
        c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx - Math.cos(ang) * hs * .5, by - Math.sin(ang) * hs * .5); c.stroke();
        c.beginPath(); c.moveTo(bx, by); c.lineTo(bx - hs * Math.cos(ang - .45), by - hs * Math.sin(ang - .45)); c.lineTo(bx - hs * Math.cos(ang + .45), by - hs * Math.sin(ang + .45)); c.fill();
        if (x.text) { c.font = '700 30px system-ui'; c.textAlign = 'center'; c.fillText(x.text, ax, ay - 24); }
      }
      c.restore();
    }
  },
  loop(ts) {
    const dt = Math.min(.1, (ts - (this.lastTs || ts)) / 1000); this.lastTs = ts;
    if (this.playing) this.tick(dt);
    requestAnimationFrame(t => this.loop(t));
  },
  tick(dt) {
    const L = this.layout(), tot = this.total(), r = L.find(x => this.T >= x.start - .001 && this.T < x.end - .02);
    if (r) {
      const e = this.els[r.c.mediaId];
      if (!e) { this.el(r.c.mediaId); return; }
      if (this.cur !== r.c.id) { if (this.cur) this.pauseAll(); this.cur = r.c.id; e.currentTime = r.c.in + (this.T - r.start) * r.c.speed; e.playbackRate = r.c.speed; AudioMix.elSource(e).gain.value = r.c.vol; e.play().catch(() => { }); }
      if (!e.seeking) this.T = r.start + (e.currentTime - r.c.in) / r.c.speed;
      if (e.currentTime >= r.c.out - .03 || e.ended) { e.pause(); this.T = r.end; this.cur = null; }
    } else this.T += dt;
    for (const a of [...this.d.audio, ...this.d.pip]) {
      const e = this.els[a.mediaId]; if (!e) { this.el(a.mediaId, 'audio'); continue; }
      const loc = a.in + this.T - a.start, on = this.T >= a.start && loc < a.out;
      if (on) { AudioMix.elSource(e).gain.value = a.vol; if (e.paused || Math.abs(e.currentTime - loc) > .35) { e.currentTime = loc; e.play().catch(() => { }); } } else if (!e.paused) e.pause();
    }
    if (this.T >= tot) { this.T = tot; this.playing = false; this.pauseAll(); $('#vePlay') && ($('#vePlay').textContent = '▶'); if (this.onEnd) this.onEnd(); }
    this.paint(r && this.cur ? r : (L.find(x => this.T >= x.start && this.T < x.end) || null));
    const ph = $('#vePh'); if (ph) ph.style.left = (64 + this.T * this.pps + 8) + 'px'; const tm = $('#veTime'); if (tm) tm.textContent = `${fmtT(this.T)} / ${fmtT(tot)}`;
  },
  /* ---------- Narração sobre a timeline ---------- */
  async narrate() {
    if (this.narr) { this.narr.rec.stop(); return; }
    let s; try { s = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); } catch (e) { return toast('Microfone indisponível: ' + e.message, true); }
    const mime = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm'].find(m => MediaRecorder.isTypeSupported?.(m)) || '';
    const rec = new MediaRecorder(s, mime ? { mimeType: mime } : undefined), chunks = [], start = this.T;
    rec.ondataavailable = e => e.data.size && chunks.push(e.data);
    rec.onstop = async () => {
      s.getTracks().forEach(t => t.stop()); this.narr = null; $('#veNar').textContent = '🎙 Gravar narração'; if (this.playing) this.togglePlay();
      const b = new Blob(chunks, { type: (mime || 'audio/webm').split(';')[0] }); if (!b.size) return;
      const m = await Media.save(b, { kind: 'narr', name: 'Narração ' + new Date().toLocaleTimeString('pt-BR') });
      const e = await this.el(m.id, 'audio'); let D = e?.duration; if (!isFinite(D)) D = (performance.now() - this.narr0) / 1000 || 5;
      this.d.audio.push({ id: uid(), mediaId: m.id, name: m.name, start, in: 0, out: D, vol: 1 }); await this.save(); this.render(); toast('Narração adicionada na faixa de áudio.');
    };
    this.narr = { rec }; this.narr0 = performance.now(); rec.start(); $('#veNar').textContent = '■ Parar narração';
    if (!this.playing && this.d.clips.length) this.togglePlay();
  },
  /* ---------- Exportação (renderização em tempo real) ---------- */
  async export() {
    if (this.exporting) return; const tot = this.total(); if (!tot) return toast('Timeline vazia.', true);
    if (!this.cv.captureStream || !window.MediaRecorder) return toast('Exportação de vídeo não suportada neste navegador.', true);
    for (const id of new Set([...this.d.clips, ...this.d.audio, ...this.d.pip].map(x => x.mediaId))) await this.el(id);
    if (!await Modal.confirm(`A exportação renderiza em tempo real: levará cerca de ${fmtT(tot)}. Mantenha esta tela aberta.`, 'Exportar')) return;
    const ctx = AudioMix.get(), dest = ctx.createMediaStreamDestination();
    const nodes = Object.values(this.els).map(e => AudioMix.elSource(e)); nodes.forEach(n => n.connect(dest));
    const mime = pickMime(), vs = this.cv.captureStream(30), stream = new MediaStream([...vs.getVideoTracks(), ...dest.stream.getAudioTracks()]);
    const rec = new MediaRecorder(stream, { mimeType: mime || undefined, videoBitsPerSecond: 6e6 }), chunks = [];
    rec.ondataavailable = e => e.data.size && chunks.push(e.data);
    this.exporting = true; $('#veExp').textContent = 'Exportando…'; $('#veExp').disabled = true;
    rec.onstop = async () => {
      nodes.forEach(n => { try { n.disconnect(dest); } catch { } }); vs.getTracks().forEach(t => t.stop()); this.exporting = false; this.onEnd = null;
      $('#veExp').textContent = 'Exportar'; $('#veExp').disabled = false;
      const b = new Blob(chunks, { type: (mime || 'video/webm').split(';')[0] }), name = 'edicao_' + new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-') + (b.type.includes('mp4') ? '.mp4' : '.webm');
      const m = await Media.save(b, { kind: 'rec', name, duration: tot }).catch(() => ({ id: null, blob: b, name, size: b.size, date: Date.now() }));
      Recorder.showResult(m);
    };
    this.pauseAll(); this.T = 0; this.cur = null; this.paint(null);
    rec.start(1000); this.onEnd = () => setTimeout(() => rec.state !== 'inactive' && rec.stop(), 300);
    this.playing = true; $('#vePlay').textContent = '❚❚';
  }
};
Views.video = { render() { VEditor.render(); } };
/* ==========================================================
   ANÁLISE DE VOD / PARTIDAS
   ========================================================== */
const EVAL_CATS = ['ROTACAO', 'POSICIONAMENTO', 'COMUNICACAO', 'MIRA', 'TROCA_DE_DANO', 'USO_DE_RECURSOS', 'CONTROLE_DE_AREA', 'DECISAO_DE_COMBATE', 'TRABALHO_EM_EQUIPE', 'USO_DE_HABILIDADES', 'DECISAO_DE_SAFE'];
const catName = c => c.replace(/_/g, ' ').toLowerCase().replace(/^./, x => x.toUpperCase());
async function roster() { const r = await DB.kv('roster') || {}; return ROLES.map(x => ({ id: x.id, nick: r[x.id] || '' })); }
const Vod = {
  cur: null, video: null, filter: '',
  async render() {
    const el = $('#v-vod'), vods = (await DB.all('vods')).sort((a, b) => b.date - a.date);
    if (this.cur) this.cur = vods.find(v => v.id === this.cur.id) || null;
    el.innerHTML = `<div class="row" style="margin-bottom:12px"><h2 style="margin:0">Análise de partidas</h2><span class="sp"></span>
      <button class="btn" id="vdCmp">Comparar partidas</button><button class="btn org" id="vdImp">+ Importar gravação</button></div>
      <div class="grid" style="grid-template-columns:minmax(0,260px) minmax(0,1fr);gap:14px" id="vdGrid">
      <div class="glass card"><h3>Partidas</h3>${vods.length ? vods.map(v => `<div class="pcard ${this.cur?.id === v.id ? 'sel' : ''}" style="cursor:pointer" data-vd="${v.id}"><b>${esc(v.name)}</b><div class="small muted">${fmtDate(v.date)} · ${v.annotations.length} anotações${v.mediaId ? '' : ' · vídeo não salvo'}</div></div>`).join('') : '<div class="empty small">Importe a gravação de uma partida para começar.</div>'}</div>
      <div id="vdMain">${this.cur ? '' : '<div class="glass card empty">Selecione ou importe uma partida.</div>'}</div></div>`;
    if (matchMedia('(max-width:860px)').matches) $('#vdGrid').style.gridTemplateColumns = '1fr';
    $('#vdImp').onclick = () => this.importVod(); $('#vdCmp').onclick = () => this.compare(vods);
    $$('[data-vd]', el).forEach(d => d.onclick = () => { this.cur = vods.find(v => v.id === d.dataset.vd); this.render(); });
    if (this.cur) this.renderMain();
  },
  async importVod() {
    const f = await pickFile('video/*'); if (!f) return;
    const save = await Modal.confirm(`Salvar o vídeo (${fmtBytes(f.size)}) neste aparelho para reabrir offline? Se não salvar, apenas as anotações ficam guardadas e o arquivo precisará ser selecionado de novo.`, 'Salvar vídeo');
    let mediaId = null;
    if (save) { try { mediaId = (await Media.save(f, { kind: 'vod', name: f.name })).id; } catch (e) { toast('Sem espaço para salvar o vídeo; somente as anotações serão salvas.', true); } }
    const v = { id: uid(), name: f.name.replace(/\.[^.]+$/, ''), file: f.name, mediaId, date: Date.now(), map: '', event: '', notes: '', annotations: [] };
    await DB.put('vods', v); this.cur = v; this.tmpBlob = f; this.tmpBlobFor = v.id; this.render();
  },
  async renderMain() {
    const v = this.cur, el = $('#vdMain'), ro = await roster();
    let blob = this.tmpBlobFor === v.id ? this.tmpBlob : null;
    if (!blob && v.mediaId) blob = (await DB.get('media', v.mediaId))?.blob;
    el.innerHTML = `<div class="glass card">
      <div class="row"><input class="in" id="vdName" value="${esc(v.name)}" style="flex:1"><input class="in" id="vdMap" placeholder="Mapa" value="${esc(v.map)}" style="width:120px"><input class="in" id="vdEv" placeholder="Evento / X-Treino" value="${esc(v.event)}" style="width:150px"></div>
      ${blob ? `<video id="vdV" controls playsinline style="width:100%;max-height:48vh;background:#000;border-radius:10px;margin-top:10px"></video>
        <div class="row" style="margin-top:6px"><button class="btn sm" data-sk="-5">-5s</button><button class="btn sm" data-sk="-0.0333">◀ quadro</button><button class="btn sm pri" id="vdPP">▶</button>
        <button class="btn sm" data-sk="0.0333">quadro ▶</button><button class="btn sm" data-sk="5">+5s</button>
        <select class="in" id="vdRate" style="padding:4px">${[0.25, 0.5, 1, 1.5, 2].map(r => `<option ${r === 1 ? 'selected' : ''}>${r}</option>`).join('')}</select><span class="small muted" id="vdT"></span><span class="sp"></span>
        <button class="btn sm" id="vdStudio">Desenhar no Estúdio</button></div>
        <p class="small muted">Avanço quadro a quadro aproximado (1/30 s); a precisão depende do codec e do navegador.</p>`
        : `<div class="empty" style="margin-top:10px">Vídeo não salvo neste aparelho (${esc(v.file)}). <button class="btn sm" id="vdRelink">Selecionar arquivo</button></div>`}
      <h3 style="margin-top:12px">Nova anotação ${blob ? '<span class="small muted">(usa o tempo atual do vídeo)</span>' : ''}</h3>
      <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px">
        <label class="f">Tipo<select id="anK"><option value="erro">Erro</option><option value="acerto">Acerto</option><option value="obs">Observação</option></select></label>
        <label class="f">Categoria<select id="anC">${EVAL_CATS.map(c => `<option value="${c}">${catName(c)}</option>`).join('')}</select></label>
        <label class="f">Jogador<select id="anP"><option value="SQUAD">Squad</option>${ro.map(r => `<option value="${r.id}">${r.id}${r.nick ? ' · ' + esc(r.nick) : ''}</option>`).join('')}</select></label>
        <label class="f">Prioridade<select id="anPr"><option value="alta">Alta</option><option value="media" selected>Média</option><option value="baixa">Baixa</option></select></label>
        <label class="f">Tempo (s)<input class="in" id="anT" type="number" step="0.1" value="0"></label></div>
      <div class="row" style="margin-top:8px"><input class="in" id="anTx" placeholder="Comentário" style="flex:1"><button class="btn pri" id="anAdd">Adicionar</button></div>
      <div class="row" style="margin-top:14px"><h3 style="margin:0">Anotações (${v.annotations.length})</h3><span class="sp"></span>
        <select class="in" id="anF" style="padding:4px"><option value="">Todas categorias</option>${EVAL_CATS.map(c => `<option value="${c}" ${this.filter === c ? 'selected' : ''}>${catName(c)}</option>`).join('')}</select>
        <button class="btn sm" id="anCsv">CSV</button><button class="btn sm red" id="vdDel">Excluir partida</button></div>
      <div id="anList"></div></div>`;
    const save = () => DB.put('vods', v);
    $('#vdName').onchange = e => { v.name = e.target.value; save(); }; $('#vdMap').onchange = e => { v.map = e.target.value; save(); }; $('#vdEv').onchange = e => { v.event = e.target.value; save(); };
    const vid = $('#vdV');
    if (vid) {
      vid.src = URL.createObjectURL(blob); this.video = vid; this.blob = blob;
      vid.ontimeupdate = () => { $('#vdT').textContent = fmtT(vid.currentTime) + ' (' + vid.currentTime.toFixed(2) + 's)'; $('#anT').value = vid.currentTime.toFixed(1); };
      vid.onplay = vid.onpause = () => $('#vdPP').textContent = vid.paused ? '▶' : '❚❚';
      $('#vdPP').onclick = () => vid.paused ? vid.play() : vid.pause();
      $$('[data-sk]', el).forEach(b => b.onclick = () => { vid.pause(); vid.currentTime = clamp(vid.currentTime + +b.dataset.sk, 0, vid.duration || 1e9); });
      $('#vdRate').onchange = e => vid.playbackRate = +e.target.value;
      $('#vdStudio').onclick = () => { vid.pause(); Recorder.loadBg(blob, v.name); Recorder.bgStart = vid.currentTime; Studio.bgVideo.currentTime = vid.currentTime; Studio.panTab = 'gravar'; go('estudio'); };
    } else $('#vdRelink').onclick = async () => { const f = await pickFile('video/*'); if (f) { this.tmpBlob = f; this.tmpBlobFor = v.id; this.renderMain(); } };
    $('#anAdd').onclick = async () => {
      const a = { id: uid(), t: +$('#anT').value || 0, kind: $('#anK').value, cat: $('#anC').value, player: $('#anP').value, priority: $('#anPr').value, comment: $('#anTx').value.trim() };
      v.annotations.push(a); v.annotations.sort((x, y) => x.t - y.t); await save(); $('#anTx').value = ''; this.renderList(); toast('Anotação registrada em ' + fmtT(a.t));
    };
    $('#anF').onchange = e => { this.filter = e.target.value; this.renderList(); };
    $('#anCsv').onclick = () => { const rows = [['tempo_s', 'tipo', 'categoria', 'jogador', 'prioridade', 'comentario'], ...v.annotations.map(a => [a.t, a.kind, a.cat, a.player, a.priority, a.comment])]; download(new Blob(['﻿' + rows.map(r => r.map(x => `"${String(x).replace(/"/g, '""')}"`).join(';')).join('\n')], { type: 'text/csv' }), v.name + '_anotacoes.csv'); };
    $('#vdDel').onclick = async () => { if (!await Modal.confirm(`Excluir a partida "${v.name}", suas ${v.annotations.length} anotações e o vídeo salvo?`, 'Excluir', true)) return; if (v.mediaId) await DB.del('media', v.mediaId); await DB.del('vods', v.id); this.cur = null; this.render(); };
    this.renderList();
  },
  renderList() {
    const v = this.cur, list = v.annotations.filter(a => !this.filter || a.cat === this.filter);
    $('#anList').innerHTML = list.length ? `<table><tr><th>Tempo</th><th>Tipo</th><th>Categoria</th><th>Jogador</th><th>Prior.</th><th>Comentário</th><th></th></tr>
      ${list.map(a => `<tr><td><button class="btn sm" data-go="${a.t}">${fmtT(a.t)}</button></td><td><span class="tag ${a.kind === 'erro' ? 'bad' : a.kind === 'acerto' ? 'ok' : ''}">${a.kind}</span></td><td>${catName(a.cat)}</td><td>${a.player}</td><td>${a.priority}</td><td>${esc(a.comment)}</td><td><button class="btn sm" data-dl="${a.id}">✕</button></td></tr>`).join('')}</table>` : '<div class="empty small">Sem anotações.</div>';
    $$('[data-go]').forEach(b => b.onclick = () => { if (this.video) { this.video.currentTime = +b.dataset.go; this.video.pause(); } });
    $$('#anList [data-dl]').forEach(b => b.onclick = async () => { v.annotations = v.annotations.filter(a => a.id !== b.dataset.dl); await DB.put('vods', v); this.renderList(); });
  },
  compare(vods) {
    if (vods.length < 1) return toast('Importe partidas primeiro.');
    const cell = (v, c, k) => v.annotations.filter(a => a.cat === c && a.kind === k).length;
    Modal.open(`<h3>Comparação entre partidas</h3><p class="small muted">Erros / acertos por categoria.</p><div style="overflow:auto"><table><tr><th>Categoria</th>${vods.map(v => `<th>${esc(v.name)}</th>`).join('')}</tr>
      ${EVAL_CATS.map(c => `<tr><td>${catName(c)}</td>${vods.map(v => `<td><span style="color:var(--red)">${cell(v, c, 'erro')}</span> / <span style="color:var(--green)">${cell(v, c, 'acerto')}</span></td>`).join('')}</tr>`).join('')}
      <tr><th>Total</th>${vods.map(v => `<th><span style="color:var(--red)">${v.annotations.filter(a => a.kind === 'erro').length}</span> / <span style="color:var(--green)">${v.annotations.filter(a => a.kind === 'acerto').length}</span></th>`).join('')}</tr></table></div>
      <div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn" data-x>Fechar</button></div>`, b => b.querySelector('[data-x]').onclick = () => Modal.close());
  }
};
Views.vod = { render() { Vod.render(); } };
/* ==========================================================
   BIBLIOTECAS — PERSONAGENS E ARMAS
   Nenhum efeito, número ou atributo é pré-preenchido: os dados
   variam por atualização e devem ser cadastrados/verificados pelo
   analista, sempre com a versão do jogo a que se referem.
   ========================================================== */
const SEED_CHARS = ['Oscar', 'Tatsuya', 'Joseph', 'Nikita', 'Olivia', 'Thiva', 'Rafael', 'Moco', 'Nero', 'Skyler', 'Iris', 'Suzy'];
const WEAPON_CATS = ['SMG', 'AR', 'SHOTGUN', 'SNIPER', 'MARKSMAN', 'LMG', 'PISTOL', 'MELEE', 'OUTRAS'];
const SEED_WEAPONS = [['UMP', 'SMG'], ['MP5', 'SMG'], ['MP40', 'SMG'], ['SCAR', 'AR'], ['XM8', 'AR'], ['GROZA', 'AR'], ['M1887', 'SHOTGUN'], ['M590', 'SHOTGUN'], ['M1014', 'SHOTGUN'], ['AWM', 'SNIPER']];
const ROLE_GUIDE = {
  R1: 'Analisar habilidades de entrada, mobilidade, resistência e pressão ofensiva.',
  R2: 'Analisar habilidades para acompanhar o R1, trocar dano, finalizar adversários e sustentar confrontos.',
  GR: 'Analisar habilidades de controle de área, informação, pressão e cobertura.',
  SUP: 'Analisar habilidades de recuperação, informação, proteção, economia e sustentação do squad.'
};
const CHAR_FIELDS = [['ability', 'Habilidade'], ['type', 'Tipo de habilidade', 'sel', ['', 'ativa', 'passiva']], ['description', 'Descrição', 'ta'], ['effect', 'Efeitos', 'ta'], ['activation', 'Condições de ativação'], ['cooldown', 'Recarga'],
['benefits', 'Vantagens', 'ta'], ['limits', 'Limitações', 'ta'], ['synergies', 'Sinergias (nomes de personagens)'], ['incompat', 'Incompatível com (nomes, separados por vírgula)'], ['situations', 'Situações recomendadas', 'ta'], ['notes', 'Observações por atualização', 'ta']];
const WEP_FIELDS = [['category', 'Categoria', 'sel', WEAPON_CATS], ['damage', 'Dano (valor do jogo)'], ['range', 'Alcance'], ['fireRate', 'Cadência'], ['accuracy', 'Precisão'], ['magazine', 'Pente / munição'],
['traits', 'Características', 'ta'], ['strengths', 'Vantagens', 'ta'], ['weaknesses', 'Desvantagens', 'ta'],
['attachments', 'Acessórios compatíveis'], ['compare', 'Comparação com outras armas', 'ta'], ['notes', 'Observações', 'ta']];

async function seedLibraries() {
  if (await DB.kv('seeded')) return; // semeia uma única vez; nunca sobrescreve dados do usuário
  for (const n of SEED_CHARS) await DB.put('chars', { id: 'c-' + n.toLowerCase(), name: n, roles: [], version: '', verified: false, created: 0, seed: true });
  for (const [n, c] of SEED_WEAPONS) await DB.put('weapons', { id: 'w-' + n.toLowerCase(), name: n, category: c, roles: [], version: '', verified: false, created: 0, seed: true });
  await DB.kv('seeded', true);
}
function libView(store, title, fields, extra) {
  return {
    q: '', role: '', cat: '',
    async render() {
      const el = $('#v-' + (store === 'chars' ? 'personagens' : 'armas'));
      let items = (await DB.all(store)).sort((a, b) => a.name.localeCompare(b.name));
      const imgs = {}; this.urls = this.urls || {};
      for (const i of items) if (i.imageId) { if (!this.urls[i.imageId]) { const m = await DB.get('media', i.imageId); if (m) this.urls[i.imageId] = URL.createObjectURL(m.blob); } imgs[i.id] = this.urls[i.imageId]; }
      const f = items.filter(i => (!this.q || i.name.toLowerCase().includes(this.q.toLowerCase())) && (!this.role || (i.roles || []).includes(this.role)) && (!this.cat || i.category === this.cat));
      el.innerHTML = `<div class="row" style="margin-bottom:12px"><h2 style="margin:0">${title}</h2><span class="sp"></span>${extra ? extra.buttons : ''}<button class="btn" id="lbExp">Exportar catálogo</button><button class="btn" id="lbImp">Importar catálogo</button><button class="btn org" id="lbNew">+ Novo</button></div>
        <div class="glass card small muted" style="margin-bottom:12px">Os dados de jogo (efeitos, tempos, atributos) não vêm pré-preenchidos para não apresentar informação desatualizada ou inventada.
        Cadastre cada item a partir de fonte confiável e marque a <b>versão do Free Fire</b> e se foi <b>verificado</b>. Imagens só devem ser importadas se você tiver autorização de uso.</div>
        <div class="row" style="margin-bottom:12px"><input class="in" id="lbQ" placeholder="Buscar" value="${esc(this.q)}">
        <select class="in" id="lbR"><option value="">Todas as funções</option>${ROLES.map(r => `<option value="${r.id}" ${this.role === r.id ? 'selected' : ''}>${r.id} · ${r.role}</option>`).join('')}</select>
        ${store === 'weapons' ? `<select class="in" id="lbC"><option value="">Todas categorias</option>${WEAPON_CATS.map(c => `<option ${this.cat === c ? 'selected' : ''}>${c}</option>`).join('')}</select>` : ''}</div>
        ${this.role ? `<div class="glass card small" style="margin-bottom:12px"><b>${this.role}:</b> ${ROLE_GUIDE[this.role]}</div>` : ''}
        ${extra ? `<div id="lbExtra" style="margin-bottom:14px"></div>` : ''}
        <div class="grid g3">${f.map(i => `<div class="glass card">
          <div class="row">${imgs[i.id] ? `<img src="${imgs[i.id]}" style="width:44px;height:44px;border-radius:10px;object-fit:cover">` : `<div class="pchip" style="width:44px;height:44px;border-radius:10px;background:var(--bg2);color:var(--blue)">${esc(i.name.slice(0, 2).toUpperCase())}</div>`}
          <div><b>${esc(i.name)}</b><div class="small muted">${esc(i.category || i.type || 'tipo não definido')}</div></div><span class="sp"></span>
          ${i.verified ? `<span class="tag ok">Verificado${i.version ? ' · ' + esc(i.version) : ''}</span>` : '<span class="tag warn">Dados pendentes</span>'}</div>
          <div class="small muted" style="margin:8px 0;min-height:36px">${esc((i.effect || i.traits || i.ability || 'Sem dados cadastrados.').slice(0, 140))}</div>
          <div class="row">${(i.roles || []).map(r => `<span class="tag">${r}</span>`).join('')}<span class="sp"></span><button class="btn sm" data-ed="${i.id}">Abrir</button></div></div>`).join('') || '<div class="empty">Nada encontrado.</div>'}</div>`;
      $('#lbQ').oninput = e => { this.q = e.target.value; clearTimeout(this._t); this._t = setTimeout(() => { this.render().then(() => { const q = $('#lbQ'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }); }, 250); };
      $('#lbR').onchange = e => { this.role = e.target.value; this.render(); }; const c = $('#lbC'); if (c) c.onchange = e => { this.cat = e.target.value; this.render(); };
      $('#lbNew').onclick = async () => { const n = await Modal.prompt('Nome:'); if (!n) return; const it = { id: (store === 'chars' ? 'c-' : 'w-') + uid(), name: n, roles: [], version: '', verified: false, created: Date.now() }; await DB.put(store, it); this.edit(it); };
      $$('[data-ed]', el).forEach(b => b.onclick = () => this.edit(items.find(i => i.id === b.dataset.ed)));
      $('#lbExp').onclick = () => download(new Blob([JSON.stringify({ app: 'analista-tatico-pro', type: 'catalog', store, format: BACKUP_FORMAT, date: Date.now(), items: items.map(i => ({ ...i, imageId: undefined })) }, null, 1)], { type: 'application/json' }), `catalogo_${store}.json`);
      $('#lbImp').onclick = () => this.importCatalog(items);
      if (extra) extra.mount(items, this);
    },
    async importCatalog(items) {
      const f = await pickFile('.json,application/json'); if (!f) return;
      let list;
      try {
        if (f.size > 20e6) throw new Error('arquivo acima de 20 MB');
        const j = sanitize(safeParse(await f.text()));
        if (j.app !== 'analista-tatico-pro' || j.type !== 'catalog' || j.store !== store || !Array.isArray(j.items)) throw new Error(`não é um catálogo de ${store === 'chars' ? 'personagens' : 'armas'} deste app`);
        if ((j.format || 1) > BACKUP_FORMAT) throw new Error('catálogo criado por uma versão mais nova do app');
        const allowed = new Set(['id', 'name', 'roles', 'version', 'verified', 'created', 'updated', ...fields.map(x => x[0])]);
        list = j.items.slice(0, 5000).map(i => { const o = {}; for (const k of Object.keys(i)) if (allowed.has(k)) o[k] = typeof i[k] === 'string' ? i[k].slice(0, 5000) : i[k]; return o; })
          .filter(i => typeof i.name === 'string' && i.name.trim()).map(i => ({ ...i, id: typeof i.id === 'string' && !/[\/]/.test(i.id) ? i.id.slice(0, 100) : (store === 'chars' ? 'c-' : 'w-') + uid(), roles: Array.isArray(i.roles) ? i.roles.filter(r => ROLES.some(x => x.id === r)) : [], verified: i.verified === true }));
      } catch (e) { return toast('Catálogo inválido: ' + e.message, true); }
      const ex = new Map(items.map(i => [i.id, i])), nw = list.filter(i => !ex.has(i.id)), upd = list.filter(i => ex.has(i.id) && JSON.stringify({ ...ex.get(i.id), imageId: undefined, updated: 0 }) !== JSON.stringify({ ...ex.get(i.id), ...i, imageId: undefined, updated: 0 }));
      Modal.open(`<h3>Pré-visualização da importação</h3><p>${list.length} item(ns) válidos no arquivo: <b>${nw.length} novos</b>, <b>${upd.length} já existentes com dados diferentes</b>, ${list.length - nw.length - upd.length} idênticos.</p>
        <div class="small muted" style="max-height:30vh;overflow:auto">${[...nw.map(i => '➕ ' + esc(i.name) + (i.version ? ' (' + esc(i.version) + ')' : '')), ...upd.map(i => '✎ ' + esc(i.name) + (i.version ? ' (' + esc(i.version) + ')' : ''))].join('<br>') || 'Nada a alterar.'}</div>
        <div class="row" style="margin-top:12px;justify-content:flex-end"><button class="btn" data-x>Cancelar</button><button class="btn" id="ciNew" ${nw.length ? '' : 'disabled'}>Adicionar só novos</button><button class="btn pri" id="ciAll" ${nw.length + upd.length ? '' : 'disabled'}>Adicionar e atualizar</button></div>`, b => {
        b.querySelector('[data-x]').onclick = () => Modal.close();
        const run = async arr => { for (const i of arr) await DB.put(store, { ...(ex.get(i.id) || {}), ...i, seed: false, updated: Date.now() }); Modal.close(); toast(arr.length + ' item(ns) gravado(s).'); this.render(); };
        $('#ciNew').onclick = () => run(nw);
        $('#ciAll').onclick = async () => { if (upd.length && !await Modal.confirm(`Substituir os dados de ${upd.length} item(ns) existente(s)? (os atuais vão para o ponto de restauração em Configurações)`, 'Substituir')) return; await RestorePoint.save(store, upd.map(i => ex.get(i.id))); run([...nw, ...upd]); };
      });
    },
    edit(it) {
      const fld = ([k, l, t, opts]) => t === 'sel' ? `<label class="f">${l}<select data-k="${k}">${opts.map(o => `<option value="${o}" ${it[k] === o ? 'selected' : ''}>${o || '—'}</option>`).join('')}</select></label>`
        : t === 'ta' ? `<label class="f">${l}<textarea data-k="${k}">${esc(it[k] || '')}</textarea></label>` : `<label class="f">${l}<input class="in" data-k="${k}" value="${esc(it[k] || '')}"></label>`;
      Modal.open(`<h3>${esc(it.name)}</h3><div class="grid g2" style="grid-template-columns:1fr 1fr">
        <label class="f">Nome<input class="in" data-k="name" value="${esc(it.name)}"></label><label class="f">Versão do jogo<input class="in" data-k="version" value="${esc(it.version || '')}" placeholder="${esc(Settings.data.gameVersion)}"></label></div>
        <div class="grid" style="margin-top:8px">${fields.map(fld).join('')}</div>
        <div class="small muted" style="margin-top:8px">Funções recomendadas</div><div class="row">${ROLES.map(r => `<label class="small"><input type="checkbox" data-role="${r.id}" ${(it.roles || []).includes(r.id) ? 'checked' : ''}> ${r.id}</label>`).join('')}</div>
        <label class="small" style="display:block;margin-top:8px"><input type="checkbox" data-k="verified" ${it.verified ? 'checked' : ''}> Dados verificados para a versão indicada</label>
        <div class="row" style="margin-top:12px"><button class="btn sm" id="liDup">Duplicar para outra versão</button><button class="btn sm" id="liImg">${it.imageId ? 'Trocar imagem' : 'Importar imagem autorizada'}</button><button class="btn sm red" id="liDel">Excluir</button><span class="sp"></span>
        <button class="btn" data-x>Cancelar</button><button class="btn pri" data-ok>Salvar</button></div>`, b => {
        b.querySelector('[data-x]').onclick = () => Modal.close();
        const collect = () => { delete it.seed; $$('[data-k]', b).forEach(i => it[i.dataset.k] = i.type === 'checkbox' ? i.checked : i.value); it.roles = $$('[data-role]', b).filter(c => c.checked).map(c => c.dataset.role); it.updated = Date.now(); };
        b.querySelector('[data-ok]').onclick = async () => { collect(); await DB.put(store, it); Modal.close(); this.render(); };
        $('#liDup').onclick = async () => { collect(); const v = await Modal.prompt('Versão do jogo da nova cópia:', Settings.data.gameVersion || ''); if (!v) return; const c = { ...deep({ ...it, imageId: undefined }), id: (store === 'chars' ? 'c-' : 'w-') + uid(), version: v, verified: false, seed: false, created: Date.now() }; if (it.imageId) c.imageId = it.imageId; await DB.put(store, c); toast('Cópia criada para a versão ' + v + ' — revise os dados.'); this.render(); };
        $('#liImg').onclick = async () => { const f = await pickFile('image/*'); if (!f) return; collect(); if (it.imageId) await DB.del('media', it.imageId); it.imageId = (await Media.save(f, { kind: 'libimg', name: f.name })).id; await DB.put(store, it); Modal.close(); this.render(); };
        $('#liDel').onclick = async () => { Modal.close(); if (await Modal.confirm(`Excluir "${it.name}" da biblioteca?`, 'Excluir', true)) { if (it.imageId) await DB.del('media', it.imageId); await DB.del(store, it.id); this.render(); } };
      });
    }
  };
}
/* ---------- Montador de combinações (1 ativa + 3 passivas) ---------- */
const comboExtra = {
  buttons: '',
  async mount(items) {
    const box = $('#lbExtra'), act = items.filter(i => i.type === 'ativa'), pas = items.filter(i => i.type === 'passiva');
    const combos = await DB.kv('combos') || [], st = this.st = this.st || { a: '', p: ['', '', ''], ver: Settings.data.gameVersion || '', role: '' };
    const opt = (arr, v) => `<option value="">—</option>` + arr.map(i => `<option value="${i.id}" ${v === i.id ? 'selected' : ''}>${esc(i.name)}${i.version ? ' (' + esc(i.version) + ')' : ''}</option>`).join('');
    box.innerHTML = `<div class="glass card"><h3>Montador de combinações — 1 habilidade ativa + 3 passivas</h3>
      ${!act.length || pas.length < 3 ? `<p class="small" style="color:var(--orange)">Para montar combinações, cadastre o <b>tipo de habilidade</b> (ativa/passiva) dos personagens. Hoje: ${act.length} ativa(s), ${pas.length} passiva(s).</p>` : ''}
      <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px">
        <label class="f">Ativa<select id="cbA">${opt(act, st.a)}</select></label>
        ${[0, 1, 2].map(i => `<label class="f">Passiva ${i + 1}<select data-cbp="${i}">${opt(pas, st.p[i])}</select></label>`).join('')}
        <label class="f">Versão do jogo<input class="in" id="cbV" value="${esc(st.ver)}"></label>
        <label class="f">Modo estrito de versão<select id="cbS"><option value="0">Avisar</option><option value="1" ${Settings.data.strictVersion ? 'selected' : ''}>Bloquear</option></select></label>
        <label class="f">Função<select id="cbR"><option value="">—</option>${ROLES.map(r => `<option ${st.role === r.id ? 'selected' : ''}>${r.id}</option>`).join('')}</select></label></div>
      <div id="cbOut" style="margin-top:10px"></div>
      <div class="row" style="margin-top:8px"><button class="btn sm pri" id="cbSave">Salvar combinação</button></div>
      ${combos.length ? `<h3 style="margin-top:12px">Combinações salvas</h3>${combos.map(c => `<div class="row pcard small"><b>${esc(c.label)}</b><span class="tag">${c.role || '—'}</span><span class="tag">${esc(c.ver || 'sem versão')}</span><span class="sp"></span><button class="btn sm" data-cl="${c.id}">Carregar</button><button class="btn sm" data-cd="${c.id}">✕</button></div>`).join('')}` : ''}</div>`;
    const upd = () => {
      st.a = $('#cbA').value; st.p = $$('[data-cbp]').map(s => s.value); st.ver = $('#cbV').value; st.role = $('#cbR').value;
      const sel = [st.a, ...st.p].filter(Boolean).map(id => items.find(i => i.id === id)), errs = [], warns = [];
      if (!st.a) errs.push('Escolha 1 habilidade ativa.'); if (st.p.filter(Boolean).length < 3) errs.push('Escolha 3 habilidades passivas.');
      if (new Set(st.p.filter(Boolean)).size !== st.p.filter(Boolean).length) errs.push('Passivas repetidas não são permitidas.');
      const names = sel.map(s => s.name.toLowerCase());
      sel.forEach(s => (s.incompat || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean).forEach(n => { if (names.includes(n)) errs.push(`${s.name} está cadastrado como incompatível com ${n}.`); }));
      const strict = Settings.data.strictVersion, vb = strict ? errs : warns;
      if (strict && !st.ver) errs.push('Modo estrito: informe a versão do jogo da combinação.');
      sel.forEach(s => { if (!s.verified) vb.push(`${s.name}: dados não verificados.`); if (st.ver && s.version && s.version !== st.ver) vb.push(`${s.name}: dados da versão ${s.version}, diferente de ${st.ver}.`); if (!s.version) vb.push(`${s.name}: sem versão do jogo informada.`); if (st.role && !(s.roles || []).includes(st.role)) warns.push(`${s.name} não está marcado como recomendado para ${st.role}.`); });
      const syn = []; sel.forEach(s => (s.synergies || '').split(/[,;]/).map(x => x.trim().toLowerCase()).filter(Boolean).forEach(n => { const o = sel.find(q => q.name.toLowerCase() === n && q !== s); if (o) syn.push(`${s.name} ↔ ${o.name}`); }));
      const alt = st.role ? pas.filter(p => (p.roles || []).includes(st.role) && !st.p.includes(p.id)).map(p => p.name) : [];
      const list = (t, arr, col) => arr.length ? `<div class="small" style="margin-top:6px"><b style="color:${col}">${t}</b><ul style="margin:4px 0 0 18px;padding:0">${arr.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : '';
      $('#cbOut').innerHTML = (errs.length ? list('Combinação inválida', errs, 'var(--red)') : sel.length ? '<span class="tag ok">Combinação válida segundo as regras cadastradas</span>' : '') +
        list('Atenção', [...new Set(warns)], 'var(--orange)') +
        list('Benefícios (cadastrados)', sel.filter(s => s.benefits).map(s => `${s.name}: ${s.benefits}`), 'var(--green)') +
        list('Possíveis desvantagens', sel.filter(s => s.limits).map(s => `${s.name}: ${s.limits}`), 'var(--red)') +
        list('Compatibilidade / sinergias', syn, 'var(--blue)') +
        list('Situações recomendadas', sel.filter(s => s.situations).map(s => `${s.name}: ${s.situations}`), 'var(--text)') +
        list('Alternativas de passiva para ' + (st.role || ''), alt, 'var(--muted)');
      return { sel, errs };
    };
    $$('#lbExtra select, #lbExtra input').forEach(e => e.onchange = upd);
    $('#cbS').onchange = async e => { Settings.data.strictVersion = e.target.value === '1'; await Settings.save(); upd(); };
    upd();
    this.squad(items, combos);
    $('#cbSave').onclick = async () => { const { sel, errs } = upd(); if (errs.length) return toast('Corrija a combinação antes de salvar.', true); combos.push({ id: uid(), label: sel.map(s => s.name).join(' + '), ...deep(st), date: Date.now() }); await DB.kv('combos', combos); Views.personagens.render(); };
    $$('[data-cl]', box).forEach(b => b.onclick = () => { const c = combos.find(x => x.id === b.dataset.cl); Object.assign(st, { a: c.a, p: c.p, ver: c.ver, role: c.role }); this.mount(items); });
    $$('[data-cd]', box).forEach(b => b.onclick = async () => { await DB.kv('combos', combos.filter(x => x.id !== b.dataset.cd)); Views.personagens.render(); });
  }
};
comboExtra.squad = async function (items, combos) { // composição R1/R2/GR/SUP
  const box = document.createElement('div'); box.className = 'glass card'; box.style.marginTop = '14px'; $('#lbExtra').appendChild(box);
  const comp = await DB.kv('squadComp') || {}, byId = id => combos.find(c => c.id === id);
  box.innerHTML = `<h3>Composição do squad</h3><p class="small muted">Escolha uma combinação salva para cada função. A validação usa a versão do jogo de cada combinação e o modo estrito.</p>
    <div class="grid g2">${ROLES.map(r => `<div class="pcard"><div class="row"><span class="pchip" style="background:${r.color}">${r.id}</span><b>${r.role}</b></div>
      <select class="in" data-sq="${r.id}" style="width:100%;margin-top:6px"><option value="">—</option>${combos.map(c => `<option value="${c.id}" ${comp[r.id] === c.id ? 'selected' : ''}>${esc(c.label)}${c.role && c.role !== r.id ? ' [' + c.role + ']' : ''}${c.ver ? ' · ' + esc(c.ver) : ''}</option>`).join('')}</select></div>`).join('')}</div>
    <div id="sqOut" class="small" style="margin-top:8px"></div><div class="row" style="margin-top:8px"><button class="btn sm pri" id="sqApply">Aplicar ao projeto aberto no Estúdio</button></div>`;
  const check = () => {
    const ch = ROLES.map(r => ({ r, c: byId(comp[r.id]) })), msgs = [], vers = new Set(ch.filter(x => x.c).map(x => x.c.ver || '(sem versão)'));
    ch.forEach(({ r, c }) => { if (!c) msgs.push(`${r.id}: sem combinação.`); else if (c.role && c.role !== r.id) msgs.push(`${r.id}: combinação montada para ${c.role}.`); });
    if (vers.size > 1) msgs.push('Combinações de versões diferentes: ' + [...vers].join(', ') + '.');
    const bad = Settings.data.strictVersion && vers.size > 1;
    $('#sqOut').innerHTML = msgs.length ? `<span style="color:${bad ? 'var(--red)' : 'var(--orange)'}">${msgs.map(esc).join('<br>')}</span>` : '<span class="tag ok">Composição completa e na mesma versão</span>';
    return !bad;
  };
  $$('[data-sq]', box).forEach(s => s.onchange = async () => { comp[s.dataset.sq] = s.value; await DB.kv('squadComp', comp); check(); });
  check();
  $('#sqApply').onclick = () => {
    if (!check()) return toast('Modo estrito: corrija as versões antes de aplicar.', true);
    const name = id => items.find(i => i.id === id)?.name || '';
    ROLES.forEach((r, i) => { const c = byId(comp[r.id]); if (!c) return; const pl = Studio.p.players[i]; pl.char = name(c.a); pl.passives = c.p.map(name).filter(Boolean).join(', '); });
    Studio.dirtyProject = true; Studio.renderPanel(); toast('Personagens aplicados ao squad do projeto "' + Studio.p.name + '".');
  };
};
/* ---------- Comparador e recomendações de equipamento ---------- */
const wepExtra = {
  buttons: '<button class="btn" id="wpCmp">Comparar</button>',
  async mount(items) {
    const box = $('#lbExtra'), lo = await DB.kv('loadouts') || {};
    const opt = v => `<option value="">—</option>` + items.map(i => `<option ${v === i.name ? 'selected' : ''}>${esc(i.name)}</option>`).join('');
    box.innerHTML = `<div class="glass card"><h3>Recomendações de equipamento por função</h3><p class="small muted">Sugestões do analista — não obrigatórias; dependem do jogador, da atualização e da estratégia.</p>
      <div class="grid g2">${ROLES.map(r => `<div class="pcard"><div class="row"><span class="pchip" style="background:${r.color}">${r.id}</span><b>${r.role}</b></div>
      <div class="grid" style="grid-template-columns:1fr 1fr;gap:6px;margin-top:6px"><label class="f">Principal<select data-lo="${r.id}.p">${opt(lo[r.id]?.p)}</select></label><label class="f">Secundária<select data-lo="${r.id}.s">${opt(lo[r.id]?.s)}</select></label></div>
      <input class="in" data-lo="${r.id}.n" placeholder="Equipamentos / observações" value="${esc(lo[r.id]?.n || '')}" style="width:100%;margin-top:6px"></div>`).join('')}</div></div>`;
    $$('[data-lo]', box).forEach(i => i.onchange = async () => { const [r, k] = i.dataset.lo.split('.'); (lo[r] = lo[r] || {})[k] = i.value; await DB.kv('loadouts', lo); toast('Recomendação salva.'); });
    $('#wpCmp').onclick = () => {
      Modal.open(`<h3>Comparar armas</h3><div class="row">${[0, 1, 2].map(i => `<select class="in" data-cw="${i}">${opt('')}</select>`).join('')}</div><div id="cwOut" style="overflow:auto;margin-top:10px"></div>
        <div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn" data-x>Fechar</button></div>`, b => {
        b.querySelector('[data-x]').onclick = () => Modal.close();
        const upd = () => { const sel = $$('[data-cw]', b).map(s => items.find(i => i.name === s.value)).filter(Boolean); $('#cwOut').innerHTML = sel.length ? `<table><tr><th></th>${sel.map(s => `<th>${esc(s.name)}</th>`).join('')}</tr>${[['version', 'Versão'], ...WEP_FIELDS].map(([k, l]) => `<tr><td class="muted">${l}</td>${sel.map(s => `<td>${esc(s[k] || '—')}</td>`).join('')}</tr>`).join('')}<tr><td class="muted">Funções</td>${sel.map(s => `<td>${(s.roles || []).join(', ') || '—'}</td>`).join('')}</tr></table>` : ''; };
        $$('[data-cw]', b).forEach(s => s.onchange = upd);
      });
    };
  }
};
Views.personagens = libView('chars', 'Biblioteca de personagens', CHAR_FIELDS, comboExtra);
Views.armas = libView('weapons', 'Catálogo de armas', WEP_FIELDS, wepExtra);
/* ==========================================================
   NUVEM — Firebase Auth + Firestore + Storage
   - Projetos privados por usuário (users/{uid}/items)
   - Sincronização com revisões (rev) e transações: conflitos nunca apagam dados
   - Fila de alterações pendentes (offline) com reenvio automático
   - Migração dos dados locais sem apagar nada
   - Links públicos (shares/{id}) com revogação, expiração e acesso por e-mail
   O SDK é carregado do CDN oficial (gstatic) somente quando a nuvem está configurada.
   ========================================================== */
const FB_VER = '10.12.2';
const SYNC_STORES = ['projects', 'maps', 'chars', 'weapons', 'matches', 'vods'];
const SYNC_KV = ['roster', 'scoring', 'combos', 'loadouts', 'economy', 'goals', 'settings', 'squadComp'];
const DOC_LIMIT = 900000; // documentos do Firestore têm limite de 1 MiB
const AUTH_ERR = {
  'auth/invalid-email': 'E-mail inválido.', 'auth/user-not-found': 'Usuário não encontrado.', 'auth/wrong-password': 'Senha incorreta.',
  'auth/invalid-credential': 'E-mail ou senha incorretos.', 'auth/email-already-in-use': 'Este e-mail já tem conta.', 'auth/weak-password': 'Senha fraca (mínimo 6 caracteres).',
  'auth/too-many-requests': 'Muitas tentativas. Aguarde alguns minutos.', 'auth/network-request-failed': 'Sem conexão com a internet.',
  'auth/popup-closed-by-user': 'Login cancelado.', 'auth/unauthorized-domain': 'Este domínio não está autorizado no Firebase (Authentication → Settings → Authorized domains).',
  'auth/operation-not-allowed': 'Este método de login não está ativado no console do Firebase.', 'permission-denied': 'Acesso negado pelas regras de segurança.'
};
const errMsg = e => AUTH_ERR[e?.code] || e?.message || String(e);
const isNetErr = e => !navigator.onLine || ['unavailable', 'deadline-exceeded', 'auth/network-request-failed', 'storage/retry-limit-exceeded'].includes(e?.code) || e instanceof TypeError;

/* ---------- Adaptador Firebase (SDK modular oficial) ---------- */
const FirebaseBackend = {
  name: 'firebase',
  async init(cfg) {
    const base = `https://www.gstatic.com/firebasejs/${FB_VER}/`;
    let mods; try { mods = await Promise.all(['firebase-app.js', 'firebase-auth.js', 'firebase-firestore.js', 'firebase-storage.js'].map(f => import(base + f))); }
    catch (e) { throw new Error('não foi possível carregar o Firebase (sem internet?)'); }
    const [A0, A, F, S] = mods; this.A = A; this.F = F; this.S = S;
    this.app = A0.initializeApp(cfg, 'atp');
    this.auth = A.getAuth(this.app);
    try { await A.setPersistence(this.auth, A.indexedDBLocalPersistence); } catch { }
    try { this.db = F.initializeFirestore(this.app, { localCache: F.persistentLocalCache({ tabManager: F.persistentMultipleTabManager() }) }); }
    catch { this.db = F.getFirestore(this.app); }
    this.st = cfg.storageBucket ? S.getStorage(this.app) : null;
    try { await A.getRedirectResult(this.auth); } catch (e) { toast(errMsg(e), true); }
  },
  hasStorage() { return !!this.st; },
  onAuth(cb) { return this.A.onAuthStateChanged(this.auth, u => cb(u ? { uid: u.uid, email: u.email, name: u.displayName } : null)); },
  signIn(e, p) { return this.A.signInWithEmailAndPassword(this.auth, e, p); },
  async signUp(e, p) { const c = await this.A.createUserWithEmailAndPassword(this.auth, e, p); try { await this.A.sendEmailVerification(c.user); toast('Conta criada. Enviamos um e-mail de verificação (necessário para abrir links restritos).'); } catch { } return c; },
  async google() {
    const pr = new this.A.GoogleAuthProvider();
    try { await this.A.signInWithPopup(this.auth, pr); }
    catch (e) { if (['auth/popup-blocked', 'auth/operation-not-supported-in-this-environment', 'auth/cancelled-popup-request'].includes(e.code)) return this.A.signInWithRedirect(this.auth, pr); throw e; }
  },
  signOut() { return this.A.signOut(this.auth); },
  reset(e) { return this.A.sendPasswordResetEmail(this.auth, e); },
  norm(key, d) { if (!d) return null; return { key, ...d, serverTime: d.serverTime?.toMillis?.() ?? Date.now() }; },
  ref(uid, key) { return this.F.doc(this.db, 'users', uid, 'items', key); },
  async tx(uid, key, payload, expected) {
    const F = this.F, r = this.ref(uid, key);
    return F.runTransaction(this.db, async t => {
      const s = await t.get(r), cur = s.exists() ? s.data() : null, rev = cur ? cur.rev : 0;
      if (rev !== expected) return { ok: false, remote: this.norm(key, cur) };
      t.set(r, { ...payload, rev: rev + 1, serverTime: F.serverTimestamp() }); return { ok: true, rev: rev + 1 };
    });
  },
  async since(uid, t) {
    const F = this.F, q = F.query(F.collection(this.db, 'users', uid, 'items'), F.where('serverTime', '>', F.Timestamp.fromMillis(t)));
    return (await F.getDocs(q)).docs.map(d => this.norm(d.id, d.data()));
  },
  watch(uid, t, cb, onErr) {
    const F = this.F, q = F.query(F.collection(this.db, 'users', uid, 'items'), F.where('serverTime', '>', F.Timestamp.fromMillis(t)));
    return F.onSnapshot(q, s => { const ch = s.docChanges().filter(c => c.type !== 'removed' && !c.doc.metadata.hasPendingWrites).map(c => this.norm(c.doc.id, c.doc.data({ serverTimestamps: 'estimate' }))); if (ch.length) cb(ch); }, onErr);
  },
  sref(p) { if (!this.st) throw new Error('Cloud Storage não configurado (storageBucket)'); return this.S.ref(this.st, p); },
  async upload(path, blob) { await this.S.uploadBytes(this.sref(path), blob, { contentType: blob.type || 'application/octet-stream' }); },
  download(path) { return this.S.getBlob(this.sref(path)); },
  async remove(path) { try { await this.S.deleteObject(this.sref(path)); } catch (e) { if (e.code !== 'storage/object-not-found') throw e; } },
  url(path) { return this.S.getDownloadURL(this.sref(path)); },
  async shareCreate(doc) {
    const F = this.F, r = F.doc(F.collection(this.db, 'shares'));
    await F.setDoc(r, { ...doc, expiresAt: doc.expiresAt ? F.Timestamp.fromMillis(doc.expiresAt) : null, createdAt: F.serverTimestamp() }); return r.id;
  },
  shareUpdate(id, patch) { return this.F.updateDoc(this.F.doc(this.db, 'shares', id), patch); },
  async shareGet(id) { const s = await this.F.getDoc(this.F.doc(this.db, 'shares', id)); if (!s.exists()) return null; const d = s.data(); return { id, ...d, expiresAt: d.expiresAt?.toMillis?.() ?? null, createdAt: d.createdAt?.toMillis?.() ?? null }; },
  async shareList(uid) { const F = this.F; return (await F.getDocs(F.query(F.collection(this.db, 'shares'), F.where('owner', '==', uid)))).docs.map(d => ({ id: d.id, ...d.data(), expiresAt: d.data().expiresAt?.toMillis?.() ?? null, createdAt: d.data().createdAt?.toMillis?.() ?? null })); }
};

/* ---------- Motor de sincronização ---------- */
const Cloud = {
  be: null, user: null, cfg: null, cfgSource: '', status: 'desligado', flushing: false, unsub: null, lastErr: '', retry: 0, tmr: null, enabled: false,
  syncable(store, id) { return SYNC_STORES.includes(store) || (store === 'kv' && SYNC_KV.includes(id)); },
  key(store, id) { return store + '~' + id; },
  async loadConfig() {
    const w = window.FIREBASE_CONFIG;
    if (w && w.apiKey && w.projectId) { this.cfgSource = 'arquivo'; return w; }
    const k = await DB.kv('fbconfig'); if (k) { this.cfgSource = 'aparelho'; return k; }
    return null;
  },
  parseConfig(text) { // aceita o objeto copiado do console do Firebase, sem executar código
    const out = {}, keys = ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId', 'measurementId'];
    for (const k of keys) { const m = new RegExp(`["']?${k}["']?\\s*:\\s*["']([^"']{1,200})["']`).exec(text); if (m) out[k] = m[1]; }
    if (!out.apiKey || !out.projectId || !out.authDomain) throw new Error('faltam apiKey, authDomain ou projectId');
    return out;
  },
  setStatus(s, err) { this.status = s; if (err !== undefined) this.lastErr = err; const el = $('#cloudStatus'); if (el) el.textContent = this.statusText(); const si = $('#sideInfo'); if (si) si.textContent = 'v' + APP_VERSION + (this.user ? ' · ☁ ' + s : ''); },
  statusText() { return this.status + (this.lastErr ? ' — ' + this.lastErr : ''); },
  async boot() {
    DB.hooks.push((s, id, op) => this.changed(s, id, op));
    window.addEventListener('online', () => { this.retry = 0; this.flush(); });
    window.addEventListener('offline', () => this.user && this.setStatus('offline — alterações ficam pendentes'));
    this.cfg = await this.loadConfig();
    if (this.cfg) this.start().catch(e => this.setStatus('erro', e.message));
  },
  async start() {
    if (this.be) return; this.setStatus('conectando');
    const be = window.__ATP_BACKEND || FirebaseBackend; await be.init(this.cfg); this.be = be;
    be.onAuth(u => this.onUser(u).catch(e => this.setStatus('erro', errMsg(e))));
  },
  async onUser(u) {
    this.unsub?.(); this.unsub = null; this.user = u; this.enabled = false;
    if (!u) { this.setStatus('desconectado', ''); this.refreshUI(); return; }
    this.setStatus('conectado', '');
    if (await DB.kv('migrated_' + u.uid)) { this.enabled = true; this.listen(); this.flush(); }
    else this.migrateDialog();
    this.refreshUI();
  },
  refreshUI() { if (currentView === 'config') { const b = $('#cloudBox'); if (b) this.renderSettings(b); } },
  /* --- fila de pendências --- */
  async changed(store, id, op) {
    if (!this.syncable(store, id)) return;
    const k = this.key(store, id), m = await DB.get('sync', k) || { id: k, store, rid: id, rev: 0 };
    Object.assign(m, { dirty: true, op, mtime: Date.now() }); await DB.put('sync', m, { silent: true });
    if (this.enabled) { clearTimeout(this.tmr); this.tmr = setTimeout(() => this.flush(), 1500); }
  },
  async pending() { return (await DB.all('sync')).filter(m => m.dirty && m.store !== 'media').length; },
  async flush() {
    if (!this.enabled || !this.user || this.flushing) return;
    if (!navigator.onLine) return this.setStatus('offline — alterações ficam pendentes');
    this.flushing = true; this.setStatus('sincronizando');
    let fail = null; const t0 = Date.now();
    try {
      const list = (await DB.all('sync')).filter(m => m.dirty && m.store !== 'media').sort((a, b) => a.mtime - b.mtime);
      for (const m of list) {
        try { await this.pushOne(m); }
        catch (e) { if (isNetErr(e)) { fail = e; break; } console.error('sync', m.id, e); this.lastErr = `${m.id}: ${errMsg(e)}`; }
      }
    } finally { this.flushing = false; }
    if (fail) { this.retry = Math.min(this.retry + 1, 6); const wait = [2, 5, 15, 30, 60, 120, 300][this.retry] * 1000; this.setStatus(`pendente — nova tentativa em ${wait / 1000}s`, ''); clearTimeout(this.tmr); this.tmr = setTimeout(() => this.flush(), wait); }
    else {
      this.retry = 0; const n = await this.pending(); this.setStatus(n ? `${n} pendente(s)` : 'sincronizado', this.lastErr); await DB.put('kv', { id: 'lastSync', v: Date.now() }, { silent: true });
      if ((await DB.all('sync')).some(m => m.dirty && m.mtime > t0)) this.flushSoon(); // alterações feitas durante o envio
    }
    this.refreshUI();
  },
  mediaRefs(store, rec) { return store === 'maps' ? (rec.versions || []).map(v => v.mediaId) : ['chars', 'weapons'].includes(store) && rec.imageId ? [rec.imageId] : []; },
  async encode(store, rec, key) {
    let r = rec;
    if (store === 'projects') r = { ...rec, history: (rec.history || []).slice(0, 10) };
    let json = JSON.stringify(r);
    if (store === 'projects' && json.length > DOC_LIMIT) { r = { ...rec, history: [] }; json = JSON.stringify(r); }
    if (json.length <= DOC_LIMIT) return { json, storagePath: null, size: json.length };
    if (!this.be.hasStorage()) throw new Error('registro grande demais para o Firestore e Cloud Storage não configurado');
    const path = `users/${this.user.uid}/items/${key}.json`; await this.be.upload(path, new Blob([json], { type: 'application/json' }));
    return { json: null, storagePath: path, size: json.length };
  },
  async decode(d) {
    if (!d || d.deleted) return null;
    const text = d.storagePath ? await (await this.be.download(d.storagePath)).text() : d.json;
    const store = d.store, rec = sanitize(safeParse(text)); const err = validateRecord(store, rec);
    if (err) throw new Error(`registro remoto inválido (${d.key}): ${err}`); return rec;
  },
  async uploadMedia(store, rec) {
    if (!this.be.hasStorage()) return;
    for (const id of this.mediaRefs(store, rec)) {
      const k = this.key('media', id), m = await DB.get('sync', k); if (m?.uploaded) continue;
      const med = await DB.get('media', id); if (!med) continue;
      await this.be.upload(`users/${this.user.uid}/media/${id}`, med.blob); await DB.put('sync', { id: k, store: 'media', rid: id, uploaded: true }, { silent: true });
    }
  },
  async downloadMedia(store, rec) {
    if (!this.be.hasStorage()) return;
    for (const id of this.mediaRefs(store, rec)) {
      if (await DB.get('media', id)) continue;
      try { const blob = await this.be.download(`users/${this.user.uid}/media/${id}`); await DB.put('media', { id, kind: store === 'maps' ? 'mapimg' : 'libimg', blob, mime: blob.type, size: blob.size, date: Date.now(), name: id }, { silent: true }); await DB.put('sync', { id: this.key('media', id), store: 'media', rid: id, uploaded: true }, { silent: true }); }
      catch (e) { console.warn('mídia remota indisponível', id, e); }
    }
  },
  async pushOne(m) {
    const key = m.id, local = await DB.get(m.store, m.rid), base = { store: m.store, id: m.rid, deviceId: await this.deviceId() };
    let payload;
    if (!local) payload = { ...base, deleted: true, json: null, storagePath: null, size: 0 };
    else { await this.uploadMedia(m.store, local); payload = { ...base, deleted: false, ...(await this.encode(m.store, local, key)) }; }
    const res = await this.be.tx(this.user.uid, key, payload, m.rev || 0);
    const cur = await DB.get('sync', key); // pode ter mudado durante o envio
    if (res.ok) { await DB.put('sync', { ...cur, rev: res.rev, dirty: cur.mtime !== m.mtime ? true : false }, { silent: true }); return; }
    await this.resolve(m, local, res.remote, 'push');
  },
  /* conflito: a mesma informação mudou neste aparelho e na nuvem. Nada é descartado. */
  async resolve(m, local, remoteDoc, why) {
    const key = m.id, store = m.store, id = m.rid;
    if (!remoteDoc || remoteDoc.deleted) { // removido na nuvem, mas alterado aqui → reenvia a versão local
      await DB.put('sync', { id: key, store, rid: id, rev: remoteDoc?.rev || 0, dirty: !!local, mtime: Date.now(), op: 'put' }, { silent: true });
      if (local && why === 'push') return this.flushSoon(); return;
    }
    const remote = await this.decode(remoteDoc);
    const pristine = (['chars', 'weapons'].includes(store) && local?.seed) || (store === 'maps' && local?.builtin && !local.versions?.length && !local.regions?.length); // item de fábrica nunca editado: a nuvem prevalece sem conflito
    if (local && !pristine && JSON.stringify(local) !== JSON.stringify(remote)) {
      if (store === 'projects') {
        const copy = { ...deep(local), id: uid(), name: local.name + ' (conflito – este aparelho)', updated: Date.now() };
        await DB.put('projects', copy); // entra na fila como novo projeto
        if (Studio.p?.id === id) { Studio.p.id = copy.id; Studio.p.name = copy.name; $('#projName').value = copy.name; }
        toast(`Conflito no projeto "${local.name}": a versão da nuvem foi mantida e a sua foi salva como cópia.`, true);
      } else await this.logConflict(store, local, 'alterado em outro aparelho');
    }
    await this.downloadMedia(store, remote);
    await DB.put(store, remote, { silent: true });
    await DB.put('sync', { id: key, store, rid: id, rev: remoteDoc.rev, dirty: false, mtime: Date.now() }, { silent: true });
    await this.afterApply(store, id, remote);
  },
  flushSoon() { clearTimeout(this.tmr); this.tmr = setTimeout(() => this.flush(), 500); },
  async logConflict(store, rec, reason) {
    const log = await DB.kv('conflictLog') || []; log.unshift({ id: uid(), date: Date.now(), store, rec, reason });
    await DB.put('kv', { id: 'conflictLog', v: log.slice(0, 50) }, { silent: true });
  },
  async apply(docs) {
    let last = await DB.kv('lastPull_' + this.user.uid) || 0;
    for (const d of docs) {
      try {
        const [store, ...rest] = d.key.split('~'), id = rest.join('~'); d.store = d.store || store;
        if (!this.syncable(store, id)) continue;
        const m = await DB.get('sync', d.key);
        if (m && (m.rev || 0) >= d.rev) { last = Math.max(last, d.serverTime); continue; }
        const local = await DB.get(store, id);
        if (m?.dirty) await this.resolve(m, local, d, 'pull');
        else if (d.deleted) {
          if (local) { if (store === 'projects') { await DB.put('projects', { ...local, archived: true, name: local.name + ' (excluído em outro aparelho)' }, { silent: true }); }
            else { await this.logConflict(store, local, 'excluído em outro aparelho'); await DB.del(store, id, { silent: true }); } }
          await DB.put('sync', { id: d.key, store, rid: id, rev: d.rev, dirty: false }, { silent: true });
        } else {
          const rec = await this.decode(d); await this.downloadMedia(store, rec);
          await DB.put(store, rec, { silent: true }); await DB.put('sync', { id: d.key, store, rid: id, rev: d.rev, dirty: false }, { silent: true });
          await this.afterApply(store, id, rec);
        }
        last = Math.max(last, d.serverTime);
      } catch (e) { console.error('aplicar remoto', d.key, e); this.lastErr = errMsg(e); }
    }
    await DB.put('kv', { id: 'lastPull_' + this.user.uid, v: last }, { silent: true });
    this.setStatus('sincronizado', this.lastErr);
    if (currentView !== 'estudio' && Views[currentView]?.render && !$('#modal').classList.contains('on')) Views[currentView].render();
  },
  async afterApply(store, id, rec) {
    if (store === 'maps') { await Maps.load(); if (Studio.p?.mapId === id) Studio.setMap(id, true); }
    if (store === 'kv' && id === 'settings') await Settings.load();
    if (store === 'projects' && Studio.p?.id === id && !Studio.dirtyProject) { await Studio.loadProject(rec); toast('Projeto atualizado a partir de outro aparelho.'); }
  },
  async listen() {
    const since = await DB.kv('lastPull_' + this.user.uid) || 0;
    this.unsub = this.be.watch(this.user.uid, since, docs => this.apply(docs), e => this.setStatus('erro', errMsg(e)));
  },
  async deviceId() { let d = await DB.kv('deviceId'); if (!d) { d = 'dev-' + uid(); await DB.put('kv', { id: 'deviceId', v: d }, { silent: true }); } return d; },
  /* --- migração dos dados locais (sem apagar nada) --- */
  async localRecords() {
    const out = [];
    for (const s of SYNC_STORES) for (const r of await DB.all(s)) out.push({ store: s, rec: r });
    for (const k of SYNC_KV) { const r = await DB.get('kv', k); if (r) out.push({ store: 'kv', rec: r }); }
    return out;
  },
  async migrateDialog() {
    const recs = await this.localRecords(), c = s => recs.filter(r => r.store === s).length;
    Modal.open(`<h3>Ativar sincronização</h3><p>Conta: <b>${esc(this.user.email || this.user.uid)}</b></p>
      <p class="small">Este aparelho tem ${c('projects')} projeto(s), ${c('maps')} mapa(s), ${c('chars')} personagem(ns), ${c('weapons')} arma(s), ${c('matches')} partida(s) e ${c('vods')} análise(s) de VOD.</p>
      <p class="small muted">Os dados serão enviados para a sua área privada na nuvem e mesclados com o que já existir nela. <b>Nada será apagado</b>: se o mesmo item for diferente aqui e na nuvem, os dois são mantidos (projetos viram cópia "conflito"; demais itens vão para o registro de conflitos).
      Vídeos não são enviados automaticamente; imagens de mapas e da biblioteca são enviadas se o Cloud Storage estiver configurado.</p>
      <div class="row" style="justify-content:flex-end"><button class="btn" data-x>Agora não</button><button class="btn pri" id="mgGo">Enviar e sincronizar</button></div>`, b => {
      b.querySelector('[data-x]').onclick = () => { Modal.close(); this.setStatus('sincronização pausada (migração pendente)'); this.refreshUI(); };
      $('#mgGo').onclick = async () => { Modal.close(); try { await this.migrate(); } catch (e) { this.setStatus('erro', errMsg(e)); toast('Migração interrompida: ' + errMsg(e) + '. Nada foi apagado; tente de novo.', true); } };
    });
  },
  async migrate() {
    if (!navigator.onLine) throw new Error('sem conexão');
    this.setStatus('migrando');
    const remote = new Map((await this.be.since(this.user.uid, 0)).map(d => [d.key, d])), recs = await this.localRecords();
    for (const { store, rec } of recs) {
      const key = this.key(store, rec.id), d = remote.get(key), m = { id: key, store, rid: rec.id, rev: 0, dirty: true, mtime: Date.now(), op: 'put' };
      if (!d || d.deleted) { m.rev = d?.rev || 0; await DB.put('sync', m, { silent: true }); continue; }
      let r = null; try { r = await this.decode(d); } catch { }
      if (r && JSON.stringify(r) === JSON.stringify(rec)) await DB.put('sync', { ...m, rev: d.rev, dirty: false }, { silent: true });
      else await this.resolve({ ...m, rev: -1 }, rec, d, 'migrate');
      remote.delete(key);
    }
    for (const d of remote.values()) await this.apply([d]); // itens que só existem na nuvem
    await DB.put('kv', { id: 'migrated_' + this.user.uid, v: Date.now() }, { silent: true });
    this.enabled = true; await this.listen(); await this.flush(); toast('Sincronização ativada.'); this.refreshUI();
  },
  /* --- tela de configurações --- */
  async renderSettings(el) {
    if (!el) return;
    const n = this.user ? await this.pending() : 0, log = await DB.kv('conflictLog') || [], last = await DB.kv('lastSync');
    let h = `<h3>Conta e nuvem (Firebase)</h3>`;
    if (!this.cfg) h += `<p class="small muted">Nuvem não configurada. Crie um projeto no console do Firebase, ative Authentication (E-mail/senha e Google), Firestore e Storage, publique as regras <code>firestore.rules</code> e <code>storage.rules</code> deste pacote e cole aqui o objeto <code>firebaseConfig</code> do app Web.
      Para links públicos funcionarem em outros aparelhos, preencha também o arquivo <code>firebase-config.js</code> do site.</p>
      <textarea id="fbCfg" placeholder='{ apiKey: "...", authDomain: "...", projectId: "...", storageBucket: "...", appId: "..." }'></textarea><button class="btn pri" id="fbSave" style="margin-top:6px">Conectar</button>`;
    else {
      h += `<p class="small">Projeto: <b>${esc(this.cfg.projectId)}</b> (configuração do ${this.cfgSource}) · Status: <b id="cloudStatus">${esc(this.statusText())}</b></p>`;
      if (!this.be) h += `<button class="btn" id="fbRetry">Tentar conectar novamente</button>`;
      else if (!this.user) h += `<div class="grid" style="gap:6px"><input class="in" id="fbEm" type="email" autocomplete="email" placeholder="E-mail"><input class="in" id="fbPw" type="password" autocomplete="current-password" placeholder="Senha (mín. 6)">
        <div class="row"><button class="btn pri" id="fbIn">Entrar</button><button class="btn" id="fbUp">Criar conta</button><button class="btn" id="fbG">Entrar com Google</button><button class="btn sm" id="fbRs">Esqueci a senha</button></div></div>`;
      else h += `<p class="small">Conectado como <b>${esc(this.user.email || this.user.uid)}</b>. Pendências: <b>${n}</b>. Última sincronização: ${fmtDate(last)}.</p>
        <div class="row">${this.enabled ? '<button class="btn" id="fbNow">Sincronizar agora</button>' : '<button class="btn pri" id="fbMig">Ativar sincronização</button>'}<button class="btn" id="fbShares">Meus links públicos</button><button class="btn" id="fbOut">Sair</button></div>`;
      if (this.cfgSource === 'aparelho') h += `<div class="row" style="margin-top:8px"><button class="btn sm" id="fbForget">Remover configuração deste aparelho</button></div>`;
    }
    if (log.length) h += `<h3 style="margin-top:12px">Registro de conflitos (${log.length})</h3><div style="max-height:180px;overflow:auto">${log.map(c => `<div class="row pcard small"><div><b>${esc(c.rec?.name || c.rec?.id)}</b> <span class="muted">${esc(c.store)} · ${esc(c.reason)} · ${fmtDate(c.date)}</span></div><span class="sp"></span><button class="btn sm" data-cr="${c.id}">Restaurar esta versão</button></div>`).join('')}</div>`;
    el.innerHTML = h;
    const on = (id, f) => { const b = $('#' + id); if (b) b.onclick = async () => { b.disabled = true; try { await f(); } catch (e) { toast(errMsg(e), true); } finally { b.disabled = false; } }; };
    on('fbSave', async () => { const c = this.parseConfig($('#fbCfg').value); await DB.put('kv', { id: 'fbconfig', v: c }, { silent: true }); this.cfg = c; this.cfgSource = 'aparelho'; await this.start(); this.renderSettings(el); });
    on('fbRetry', async () => { await this.start(); this.renderSettings(el); });
    const cred = () => { const e = $('#fbEm').value.trim(), p = $('#fbPw').value; if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)) throw new Error('Informe um e-mail válido.'); return [e, p]; };
    on('fbIn', () => this.be.signIn(...cred())); on('fbUp', () => this.be.signUp(...cred())); on('fbG', () => this.be.google());
    on('fbRs', async () => { const e = $('#fbEm').value.trim(); if (!e) throw new Error('Digite o e-mail.'); await this.be.reset(e); toast('E-mail de redefinição enviado.'); });
    on('fbOut', async () => { if (await this.pending() && !await Modal.confirm('Há alterações ainda não enviadas. Elas continuam salvas neste aparelho e serão enviadas quando você entrar de novo. Sair?', 'Sair')) return; await this.be.signOut(); });
    on('fbNow', () => this.flush()); on('fbMig', () => this.migrateDialog()); on('fbShares', () => this.mySharesDialog());
    on('fbForget', async () => { if (!await Modal.confirm('Remover a configuração do Firebase deste aparelho? Seus dados locais continuam aqui.', 'Remover')) return; await DB.del('kv', 'fbconfig', { silent: true }); location.reload(); });
    $$('[data-cr]', el).forEach(b => b.onclick = async () => { const c = log.find(x => x.id === b.dataset.cr); if (!await Modal.confirm(`Restaurar "${c.rec?.name || c.rec?.id}" com esta versão? A versão atual será substituída e sincronizada.`, 'Restaurar')) return; await DB.put(c.store, c.rec); toast('Versão restaurada.'); });
  },
  /* --- links públicos --- */
  needLogin() { if (this.user && this.be) return false; toast('Entre na sua conta em Configurações → Conta e nuvem para criar links.', true); go('config'); return true; },
  linkFor(id) {
    const u = new URL(location.href); u.hash = ''; u.search = '?share=' + encodeURIComponent(id);
    if (this.cfgSource !== 'arquivo') u.search += '&cfg=' + encodeURIComponent(btoa(JSON.stringify(this.cfg))); // config pública do Firebase (sem segredos)
    return u.toString();
  },
  async shareDialog(p) {
    if (this.needLogin()) return;
    if (!this.be.hasStorage()) toast('Cloud Storage não configurado: o link terá o projeto, mas não a imagem do mapa nem vídeos.', true);
    const shares = (await this.be.shareList(this.user.uid).catch(e => { toast(errMsg(e), true); return []; })).filter(s => s.projectId === p.id);
    const vids = (await Media.list('rec')).filter(r => r.projectId === p.id || (p.videos || []).includes(r.id));
    Modal.open(`<h3>Link público — ${esc(p.name)}</h3>
      ${shares.length ? `<div style="max-height:30vh;overflow:auto">${shares.map(s => `<div class="pcard small"><div class="row"><b>${s.visibility === 'public' ? 'Qualquer pessoa com o link' : 'Somente: ' + esc((s.emails || []).join(', '))}</b><span class="sp"></span>${s.revoked ? '<span class="tag bad">Revogado</span>' : s.expiresAt && s.expiresAt < Date.now() ? '<span class="tag warn">Expirado</span>' : '<span class="tag ok">Ativo</span>'}</div>
        <div class="muted">Criado ${fmtDate(s.createdAt)}${s.expiresAt ? ' · expira ' + fmtDate(s.expiresAt) : ''}${s.files?.video ? ' · com vídeo' : ''}</div>
        ${s.revoked ? '' : `<div class="row" style="margin-top:6px"><button class="btn sm pri" data-cp="${s.id}">Copiar link</button><button class="btn sm" data-ns="${s.id}">Compartilhar</button><button class="btn sm" data-up="${s.id}">Atualizar conteúdo</button><button class="btn sm red" data-rv="${s.id}">Revogar</button></div>`}</div>`).join('')}</div>` : ''}
      <h3 style="margin-top:12px">Novo link</h3>
      <div class="grid" style="gap:8px">
        <label class="f">Quem pode abrir<select id="shVis"><option value="public">Qualquer pessoa com o link (sem login)</option><option value="emails">Somente e-mails autorizados (exige login)</option></select></label>
        <label class="f" id="shEmW" style="display:none">E-mails autorizados (separados por vírgula)<input class="in" id="shEm" placeholder="jogador@exemplo.com, coach@exemplo.com"></label>
        <label class="f">Validade<select id="shExp"><option value="0">Sem expiração</option><option value="1">1 dia</option><option value="7">7 dias</option><option value="30">30 dias</option></select></label>
        <label class="f">Vídeo (opcional)<select id="shVid"><option value="">Sem vídeo</option>${vids.map(v => `<option value="${v.id}">${esc(v.name)} (${fmtBytes(v.size)})</option>`).join('')}</select></label></div>
      <p class="small muted">O link mostra uma cópia somente leitura do projeto no momento da criação (use "Atualizar conteúdo" para enviar mudanças). Revogar bloqueia o acesso e apaga os arquivos públicos.</p>
      <div class="row" style="justify-content:flex-end"><button class="btn" data-x>Fechar</button><button class="btn pri" id="shCreate">Criar link</button></div>`, b => {
      b.querySelector('[data-x]').onclick = () => Modal.close();
      $('#shVis').onchange = e => $('#shEmW').style.display = e.target.value === 'emails' ? '' : 'none';
      const copy = async id => { const l = this.linkFor(id); try { await navigator.clipboard.writeText(l); toast('Link copiado.'); } catch { Modal.open(`<h3>Link</h3><textarea readonly style="min-height:90px">${esc(l)}</textarea><div class="row" style="justify-content:flex-end"><button class="btn" data-x>Fechar</button></div>`, m => m.querySelector('[data-x]').onclick = () => Modal.close()); } };
      $$('[data-cp]', b).forEach(x => x.onclick = () => copy(x.dataset.cp));
      $$('[data-ns]', b).forEach(x => x.onclick = async () => { const url = this.linkFor(x.dataset.ns); if (navigator.share) { try { await navigator.share({ title: p.name, text: 'Análise tática: ' + p.name, url }); } catch { } } else copy(x.dataset.ns); });
      $$('[data-rv]', b).forEach(x => x.onclick = async () => { if (!await Modal.confirm('Revogar este link? Quem tiver o endereço perde o acesso imediatamente.', 'Revogar', true)) return; await this.revoke(shares.find(s => s.id === x.dataset.rv)); this.shareDialog(p); });
      $$('[data-up]', b).forEach(x => x.onclick = async () => { x.disabled = true; try { await this.publish(x.dataset.up, p, shares.find(s => s.id === x.dataset.up)?.files?.video ? null : undefined); toast('Conteúdo do link atualizado.'); } catch (e) { toast(errMsg(e), true); } x.disabled = false; });
      $('#shCreate').onclick = async () => {
        const vis = $('#shVis').value, emails = vis === 'emails' ? $('#shEm').value.split(',').map(s => s.trim().toLowerCase()).filter(e => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)).slice(0, 50) : [];
        if (vis === 'emails' && !emails.length) return toast('Informe ao menos um e-mail válido.', true);
        const days = +$('#shExp').value, vid = $('#shVid').value; $('#shCreate').disabled = true; $('#shCreate').textContent = 'Publicando…';
        try {
          const id = await this.be.shareCreate({ owner: this.user.uid, projectId: p.id, title: String(p.name).slice(0, 120), visibility: vis, emails, revoked: false, expiresAt: days ? Date.now() + days * 864e5 : null, files: {}, json: null, ready: false });
          await this.publish(id, p, vid || null); Modal.close(); await copy(id); this.shareDialog(p);
        } catch (e) { toast('Falha ao criar link: ' + errMsg(e), true); $('#shCreate').disabled = false; $('#shCreate').textContent = 'Criar link'; }
      };
    });
  },
  async publish(id, p, videoId) { // envia o conteúdo público do link
    const snap = { ...deep(p), history: [], videos: [] }, json = JSON.stringify(snap), files = {}, patch = { ready: true, title: String(p.name).slice(0, 120) };
    if (json.length > DOC_LIMIT) { if (!this.be.hasStorage()) throw new Error('projeto grande demais sem Cloud Storage'); files.project = `public/${id}/project.json`; await this.be.upload(files.project, new Blob([json], { type: 'application/json' })); patch.json = null; }
    else patch.json = json;
    if (this.be.hasStorage()) {
      const m = Maps.get(p.mapId), v = m && Maps.activeVersion(m), med = v && await DB.get('media', v.mediaId);
      if (med) { files.map = `public/${id}/map`; await this.be.upload(files.map, med.blob); patch.mapName = m.name; }
      if (videoId) { const r = await DB.get('media', videoId); if (r) { files.video = `public/${id}/video`; await this.be.upload(files.video, r.blob); } }
    }
    if (videoId === null) { const cur = await this.be.shareGet(id).catch(() => null); if (cur?.files?.video) files.video = cur.files.video; }
    patch.files = files; await this.be.shareUpdate(id, patch);
  },
  async revoke(s) {
    await this.be.shareUpdate(s.id, { revoked: true, json: null });
    for (const f of Object.values(s.files || {})) await this.be.remove(f).catch(e => console.warn(e));
    toast('Link revogado.');
  },
  async mySharesDialog() {
    if (this.needLogin()) return;
    const list = (await this.be.shareList(this.user.uid)).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    Modal.open(`<h3>Meus links públicos</h3>${list.map(s => `<div class="row pcard small"><div><b>${esc(s.title)}</b><div class="muted">${s.visibility === 'public' ? 'Público' : 'Restrito'} · ${fmtDate(s.createdAt)}</div></div><span class="sp"></span>${s.revoked ? '<span class="tag bad">Revogado</span>' : `<button class="btn sm red" data-rv="${s.id}">Revogar</button>`}</div>`).join('') || '<div class="empty">Nenhum link criado.</div>'}
      <div class="row" style="justify-content:flex-end"><button class="btn" data-x>Fechar</button></div>`, b => {
      b.querySelector('[data-x]').onclick = () => Modal.close();
      $$('[data-rv]', b).forEach(x => x.onclick = async () => { if (!await Modal.confirm('Revogar este link?', 'Revogar', true)) return; await this.revoke(list.find(s => s.id === x.dataset.rv)); this.mySharesDialog(); });
    });
  },
  /* --- visitante de link público (somente leitura, não grava nada) --- */
  async openShare(id) {
    document.body.classList.add('ro'); Studio.readOnly = true; currentView = 'estudio';
    $$('.view').forEach(v => v.classList.toggle('on', v.id === 'v-estudio')); Studio.resize();
    const fail = msg => { $('#roTitle').textContent = 'Link indisponível'; Modal.open(`<h3>Link indisponível</h3><p>${esc(msg)}</p>`); };
    try {
      let cfg = window.FIREBASE_CONFIG?.apiKey ? window.FIREBASE_CONFIG : null;
      const c = new URLSearchParams(location.search).get('cfg');
      if (!cfg && c) { const o = safeParse(atob(c)); cfg = {}; for (const k of ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'appId', 'messagingSenderId']) if (typeof o[k] === 'string' && o[k].length < 200) cfg[k] = o[k]; }
      if (!cfg?.apiKey) return fail('Este site não tem a configuração da nuvem.');
      const be = window.__ATP_BACKEND || FirebaseBackend; await be.init(cfg); this.be = be; this.cfg = cfg;
      const user = await new Promise(r => { let done = false; be.onAuth(u => { if (!done) { done = true; r(u); } }); setTimeout(() => !done && r(null), 4000); });
      let s; try { s = await be.shareGet(id); } catch (e) { if (e.code === 'permission-denied' || /permiss/i.test(e.message)) return this.shareLogin(id, user); throw e; }
      if (!s || s.revoked) return fail('Este link foi revogado pelo proprietário ou não existe.');
      if (s.expiresAt && s.expiresAt < Date.now()) return fail('Este link expirou.');
      if (!s.ready) return fail('O conteúdo ainda está sendo publicado. Tente em instantes.');
      const text = s.json || await (await be.download(s.files.project)).text(), p = sanitize(safeParse(text)), err = validateRecord('projects', p);
      if (err) return fail('Conteúdo inválido: ' + err);
      const ref = p.ref; p.ref = null; // as coordenadas estão no espaço da imagem do proprietário (ref)
      await Studio.loadProject(p); $('#roTitle').textContent = s.title; document.title = s.title + ' — ANALISTA TÁTICO PRO';
      let img = null; if (s.files?.map) { try { img = new Image(); img.src = await be.url(s.files.map); await img.decode(); } catch { img = null; } }
      if (img) { Studio.bgImg = img; Studio.world = { w: img.naturalWidth, h: img.naturalHeight }; }
      if (ref?.w && (ref.w !== Studio.world.w || ref.h !== Studio.world.h)) Studio.rescale(Studio.world.w / ref.w, Studio.world.h / ref.h);
      Studio.fit();
      if (s.files?.video) { const url = await be.url(s.files.video), b = document.createElement('button'); b.className = 'btn sm org ro-keep'; b.textContent = '▶ Assistir análise em vídeo'; b.onclick = () => Modal.open(`<h3>${esc(s.title)}</h3><video src="${esc(url)}" controls playsinline style="width:100%;max-height:70vh;background:#000;border-radius:10px"></video><div class="row" style="justify-content:flex-end;margin-top:8px"><button class="btn" data-x>Fechar</button></div>`, m => m.querySelector('[data-x]').onclick = () => Modal.close()); $('.topbar').appendChild(b); }
      Studio.dirty = true; Studio.dirtyProject = false;
    } catch (e) { fail('Não foi possível abrir: ' + errMsg(e)); }
  },
  shareLogin(id, user) {
    Modal.open(`<h3>Acesso restrito</h3><p class="small">Este link foi <b>revogado</b>, expirou ou é restrito a e-mails autorizados. ${user ? `A conta ${esc(user.email)} não tem acesso.` : 'Se você recebeu acesso, entre com o e-mail autorizado pelo analista.'}</p>
      <div class="grid" style="gap:6px"><input class="in" id="slE" type="email" placeholder="E-mail"><input class="in" id="slP" type="password" placeholder="Senha"></div>
      <div class="row" style="margin-top:8px"><button class="btn pri" id="slIn">Entrar</button><button class="btn" id="slG">Entrar com Google</button>${user ? '<button class="btn" id="slOut">Sair</button>' : ''}</div>`, b => {
      const after = () => location.reload();
      $('#slIn').onclick = () => this.be.signIn($('#slE').value.trim(), $('#slP').value).then(after).catch(e => toast(errMsg(e), true));
      $('#slG').onclick = () => this.be.google().then(after).catch(e => toast(errMsg(e), true));
      const o = $('#slOut'); if (o) o.onclick = () => this.be.signOut().then(after);
    });
  }
};
/* ==========================================================
   QUEDA & ECONOMIA
   ========================================================== */
Views.queda = {
  async render() {
    const el = $('#v-queda'), E = Object.assign({ items: [], coins: {}, buy: {}, resources: '', notes: '' }, await DB.kv('economy') || {}), ro = await roster(), P = Studio.p;
    const save = () => DB.kv('economy', E);
    const total = id => E.items.filter(i => E.buy[id]?.includes(i.id)).reduce((s, i) => s + (+i.cost || 0), 0);
    const teamCoins = ROLES.reduce((s, r) => s + (+E.coins[r.id] || 0), 0), teamCost = ROLES.reduce((s, r) => s + total(r.id), 0);
    el.innerHTML = `<h2>Planejador de queda e economia</h2>
      <div class="grid g2">
      <div class="glass card"><h3>Queda (projeto atual: ${esc(P.name)})</h3>
        <label class="f">Local de queda<input class="in" id="qDrop" value="${esc(P.drop || '')}"></label>
        <label class="f" style="margin-top:8px">Prioridades de loot / reagrupamento / início da rotação<textarea id="qLoot">${esc(P.loot || '')}</textarea></label>
        <p class="small muted">No mapa, use as ferramentas Moedas ($), Máquina de compras (M), Veículo (V) e os marcadores R1/R2/GR/SUP para posicionar o squad.</p>
        <div class="row"><button class="btn pri" id="qOpen">Abrir mapa no Estúdio</button><button class="btn" id="qCoin">Marcar moedas</button><button class="btn" id="qShop">Marcar máquinas</button></div>
        <h3 style="margin-top:14px">Recursos disponíveis</h3><textarea id="qRes" placeholder="Ex.: kits, granadas, coletes, itens adquiridos…">${esc(E.resources)}</textarea></div>
      <div class="glass card"><h3>Itens e custos (configurável)</h3>
        <p class="small muted">Custos não são pré-definidos: preencha conforme a versão (${esc(Settings.data.gameVersion || 'não definida')}) e as regras da partida/campeonato.</p>
        <table><tr><th>Item</th><th>Custo</th><th></th></tr>${E.items.map(i => `<tr><td><input class="in" data-in="${i.id}" value="${esc(i.name)}" style="width:100%"></td><td><input class="in" type="number" min="0" data-ic="${i.id}" value="${i.cost}" style="width:90px"></td><td><button class="btn sm" data-id="${i.id}">✕</button></td></tr>`).join('')}</table>
        <button class="btn sm" id="qAdd" style="margin-top:8px">+ Item (rádio, colete, arma…)</button></div></div>
      <div class="glass card" style="margin-top:14px"><h3>Calculadora do squad</h3>
        ${E.items.length ? `<div style="overflow:auto"><table><tr><th>Jogador</th><th>Moedas</th>${E.items.map(i => `<th>${esc(i.name)}<br><span class="muted">${i.cost}</span></th>`).join('')}<th>Gasto</th><th>Saldo</th></tr>
        ${ROLES.map(r => { const c = +E.coins[r.id] || 0, t = total(r.id); return `<tr><td><span class="pchip" style="background:${r.color};display:inline-grid;width:26px;height:26px">${r.id}</span> ${esc(ro.find(x => x.id === r.id)?.nick || '')}</td>
          <td><input class="in" type="number" min="0" data-co="${r.id}" value="${E.coins[r.id] ?? ''}" style="width:80px"></td>${E.items.map(i => `<td><input type="checkbox" data-by="${r.id}|${i.id}" ${E.buy[r.id]?.includes(i.id) ? 'checked' : ''}></td>`).join('')}
          <td>${t}</td><td style="color:${c - t < 0 ? 'var(--red)' : 'var(--green)'}">${c - t}</td></tr>`; }).join('')}
        <tr><th>Squad</th><th>${teamCoins}</th>${E.items.map(() => '<th></th>').join('')}<th>${teamCost}</th><th style="color:${teamCoins - teamCost < 0 ? 'var(--red)' : 'var(--green)'}">${teamCoins - teamCost}</th></tr></table></div>
        ${teamCoins - teamCost < 0 ? '<p class="small" style="color:var(--red)">O plano de compras excede as moedas do squad.</p>' : ''}
        <p class="small muted">Saldo individual negativo pode ser coberto por moedas de colegas, se as regras do modo permitirem.</p>` : '<div class="empty small">Cadastre itens e custos para usar a calculadora.</div>'}
        <label class="f" style="margin-top:8px">Observações<textarea id="qNotes">${esc(E.notes)}</textarea></label></div>`;
    $('#qDrop').onchange = e => { P.drop = e.target.value; Studio.dirtyProject = true; }; $('#qLoot').onchange = e => { P.loot = e.target.value; Studio.dirtyProject = true; };
    $('#qOpen').onclick = () => go('estudio'); $('#qCoin').onclick = () => { go('estudio'); Studio.setTool('i-coin'); }; $('#qShop').onclick = () => { go('estudio'); Studio.setTool('i-shop'); };
    $('#qRes').onchange = e => { E.resources = e.target.value; save(); }; $('#qNotes').onchange = e => { E.notes = e.target.value; save(); };
    $('#qAdd').onclick = async () => { const n = await Modal.prompt('Nome do item:'); if (!n) return; E.items.push({ id: uid(), name: n, cost: 0 }); await save(); this.render(); };
    $$('[data-in]', el).forEach(i => i.onchange = async () => { E.items.find(x => x.id === i.dataset.in).name = i.value; await save(); this.render(); });
    $$('[data-ic]', el).forEach(i => i.onchange = async () => { E.items.find(x => x.id === i.dataset.ic).cost = Math.max(0, +i.value || 0); await save(); this.render(); });
    $$('[data-id]', el).forEach(b => b.onclick = async () => { E.items = E.items.filter(x => x.id !== b.dataset.id); await save(); this.render(); });
    $$('[data-co]', el).forEach(i => i.onchange = async () => { E.coins[i.dataset.co] = Math.max(0, +i.value || 0); await save(); this.render(); });
    $$('[data-by]', el).forEach(c => c.onchange = async () => { const [r, id] = c.dataset.by.split('|'); E.buy[r] = (E.buy[r] || []).filter(x => x !== id); if (c.checked) E.buy[r].push(id); await save(); this.render(); });
  }
};
/* ==========================================================
   ESTRATÉGIAS & PROJETOS
   ========================================================== */
const Projects = {
  exportOne(p) { download(new Blob([JSON.stringify({ app: 'analista-tatico-pro', type: 'project', version: APP_VERSION, format: BACKUP_FORMAT, project: p }, null, 1)], { type: 'application/json' }), (p.name || 'projeto').replace(/[^\w\-]+/g, '_') + '.atp.json'); },
  async importFile() {
    const f = await pickFile('.json,application/json'); if (!f) return;
    try {
      if (f.size > 30e6) throw new Error('arquivo acima de 30 MB');
      const j = safeParse(await f.text()); if (j?.app !== 'analista-tatico-pro') throw new Error('não é um arquivo deste app');
      if ((j.format || 1) > BACKUP_FORMAT) throw new Error('arquivo criado por uma versão mais nova do app — atualize');
      const list = (j.type === 'project' ? [j.project] : j.projects || []).map(p => sanitize(p));
      if (!list.length) throw new Error('arquivo sem projetos');
      const bad = list.map(p => validateRecord('projects', p)).filter(Boolean); if (bad.length) throw new Error(bad[0]);
      if (!await Modal.confirm(`Importar ${list.length} projeto(s): ${list.map(p => '"' + p.name + '"').join(', ').slice(0, 300)}? Projetos existentes não serão substituídos (se o identificador já existir, será criada uma cópia).`, 'Importar')) return;
      for (const p of list) { const ex = await DB.get('projects', p.id); if (ex) { p.id = uid(); p.name += ' (importado)'; } p.history = Array.isArray(p.history) ? p.history.slice(0, 25) : []; await DB.put('projects', p); }
      toast(list.length + ' projeto(s) importado(s).'); Views.estrategias.render();
    } catch (e) { toast('Arquivo inválido: ' + e.message, true); }
  }
};
Views.estrategias = {
  q: '', arch: false, map: '',
  async render() {
    const el = $('#v-estrategias'); const all = (await DB.all('projects')).sort((a, b) => b.updated - a.updated);
    const list = all.filter(p => !!p.archived === this.arch && (!this.map || p.mapId === this.map) && (!this.q || (p.name + ' ' + p.team + ' ' + p.drop).toLowerCase().includes(this.q.toLowerCase())));
    el.innerHTML = `<div class="row" style="margin-bottom:12px"><h2 style="margin:0">Estratégias & projetos salvos</h2><span class="sp"></span><button class="btn" id="psImp">Importar</button><button class="btn org" id="psNew">+ Nova estratégia</button></div>
      <div class="row" style="margin-bottom:12px"><input class="in" id="psQ" placeholder="Buscar por nome, equipe, queda" value="${esc(this.q)}">
      <select class="in" id="psM"><option value="">Todos os mapas</option>${Maps.list.map(m => `<option value="${m.id}" ${this.map === m.id ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select>
      <label class="small"><input type="checkbox" id="psA" ${this.arch ? 'checked' : ''}> Arquivados</label></div>
      <div class="grid g3">${list.map(p => `<div class="glass card"><div class="row"><b>${esc(p.name)}</b><span class="sp"></span><span class="tag">${esc(Maps.get(p.mapId)?.name || p.mapId)}</span></div>
        <div class="small muted" style="margin:6px 0">${esc(p.team || 'Sem equipe')} · Queda: ${esc(p.drop || '—')}<br>Versão do jogo: ${esc(p.gameVersion || '—')} · ${p.objects.length} marcações · ${(p.videos || []).length} vídeos<br>Atualizado ${fmtDate(p.updated)} · ${(p.history || []).length} versões</div>
        <div class="row"><button class="btn sm pri" data-op="${p.id}">Abrir</button><button class="btn sm" data-du="${p.id}">Duplicar</button><button class="btn sm" data-ex="${p.id}">Exportar</button>
        <button class="btn sm" data-hi="${p.id}">Histórico</button><button class="btn sm" data-ar="${p.id}">${p.archived ? 'Restaurar' : 'Arquivar'}</button><button class="btn sm" data-de="${p.id}">Excluir</button></div></div>`).join('') || '<div class="empty">Nenhum projeto. Crie uma estratégia no Estúdio e salve.</div>'}</div>`;
    const get = id => all.find(p => p.id === id);
    $('#psQ').oninput = e => { this.q = e.target.value; clearTimeout(this._t); this._t = setTimeout(() => this.render().then(() => { const q = $('#psQ'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }), 250); };
    $('#psM').onchange = e => { this.map = e.target.value; this.render(); }; $('#psA').onchange = e => { this.arch = e.target.checked; this.render(); };
    $('#psNew').onclick = async () => { await Studio.loadProject(newProject(Studio.p.mapId)); go('estudio'); }; $('#psImp').onclick = () => Projects.importFile();
    $$('[data-op]', el).forEach(b => b.onclick = async () => { if (Studio.dirtyProject && !await Modal.confirm('O projeto aberto tem alterações não salvas. Abrir outro mesmo assim?', 'Abrir')) return; await Studio.loadProject(get(b.dataset.op)); go('estudio'); });
    $$('[data-du]', el).forEach(b => b.onclick = async () => { const p = deep(get(b.dataset.du)); p.id = uid(); p.name += ' (cópia)'; p.created = p.updated = Date.now(); p.history = []; await DB.put('projects', p); this.render(); });
    $$('[data-ex]', el).forEach(b => b.onclick = () => Projects.exportOne(get(b.dataset.ex)));
    $$('[data-ar]', el).forEach(b => b.onclick = async () => { const p = get(b.dataset.ar); p.archived = !p.archived; await DB.put('projects', p); this.render(); });
    $$('[data-de]', el).forEach(b => b.onclick = async () => { const p = get(b.dataset.de); if (await Modal.confirm(`Excluir definitivamente "${p.name}"? Exporte antes se quiser manter um backup.`, 'Excluir', true)) { await DB.del('projects', p.id); this.render(); } });
    $$('[data-hi]', el).forEach(b => b.onclick = () => {
      const p = get(b.dataset.hi);
      Modal.open(`<h3>Histórico — ${esc(p.name)}</h3>${(p.history || []).map((h, i) => `<div class="row pcard"><div><b>Versão ${p.history.length - i}</b><div class="small muted">${fmtDate(h.date)} · ${h.snap.objects.length} marcações</div></div><span class="sp"></span><button class="btn sm" data-rv="${i}">Abrir como cópia</button></div>`).join('') || '<div class="empty">Sem versões.</div>'}
        <div class="row" style="justify-content:flex-end"><button class="btn" data-x>Fechar</button></div>`, m => {
        m.querySelector('[data-x]').onclick = () => Modal.close();
        $$('[data-rv]', m).forEach(x => x.onclick = async () => { const s = deep(p.history[+x.dataset.rv].snap); s.id = uid(); s.name = p.name + ' (versão de ' + fmtDate(p.history[+x.dataset.rv].date) + ')'; s.history = []; Modal.close(); await Studio.loadProject(s); go('estudio'); toast('Versão aberta como novo projeto — salve para manter.'); });
      });
    });
  }
};
/* ==========================================================
   RELATÓRIOS
   ========================================================== */
const MATCH_TYPES = ['X-Treino', 'Campeonato', 'Scrim', 'Treino'];
Views.relatorios = {
  f: { type: '', event: '', map: '', from: '', to: '', player: '' },
  async render() {
    const el = $('#v-relatorios'), all = (await DB.all('matches')).sort((a, b) => a.date - b.date), models = await DB.kv('scoring') || [], ro = await roster(), vods = await DB.all('vods'), goals = await DB.kv('goals') || {};
    const F = this.f, inR = m => (!F.type || m.type === F.type) && (!F.event || m.event === F.event) && (!F.map || m.map === F.map) && (!F.from || m.date >= +new Date(F.from)) && (!F.to || m.date <= +new Date(F.to) + 864e5);
    const pts = m => { const md = models.find(x => x.id === m.model); if (!md) return null; const kills = ROLES.reduce((s, r) => s + (+m.kills?.[r.id] || 0), 0); return (+(md.place[(+m.placement || 0) - 1]) || 0) + kills * (+md.kill || 0); };
    const ms = all.filter(inR), nick = id => ro.find(r => r.id === id)?.nick || id;
    const sum = (k, id) => ms.reduce((s, m) => s + (+m[k]?.[id] || 0), 0), has = (k, id) => ms.some(m => m[k]?.[id] !== '' && m[k]?.[id] != null);
    const vf = vods.filter(v => (!F.event || v.event === F.event) && (!F.map || v.map === F.map) && (!F.from || v.date >= +new Date(F.from)) && (!F.to || v.date <= +new Date(F.to) + 864e5));
    const ann = (id, k) => vf.reduce((s, v) => s + v.annotations.filter(a => a.player === id && a.kind === k).length, 0);
    const P = ms.map(pts).filter(x => x != null), places = ms.map(m => +m.placement).filter(Boolean);
    const events = [...new Set(all.map(m => m.event).filter(Boolean))], mapsU = [...new Set(all.map(m => m.map).filter(Boolean))];
    const players = F.player ? ROLES.filter(r => r.id === F.player) : ROLES;
    const maxK = Math.max(1, ...ms.map(m => ROLES.reduce((s, r) => s + (+m.kills?.[r.id] || 0), 0)));
    el.innerHTML = `<div class="row noprint" style="margin-bottom:12px"><h2 style="margin:0">Relatórios</h2><span class="sp"></span><button class="btn" id="rpModels">Modelos de pontuação</button><button class="btn" id="rpCsv">CSV</button><button class="btn" id="rpPdf">Exportar PDF</button><button class="btn org" id="rpNew">+ Partida</button></div>
      <div class="glass card noprint" style="margin-bottom:12px"><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px">
        <label class="f">Tipo<select data-f="type"><option value="">Todos</option>${MATCH_TYPES.map(t => `<option ${F.type === t ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <label class="f">Campeonato / evento<select data-f="event"><option value="">Todos</option>${events.map(t => `<option ${F.event === t ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></label>
        <label class="f">Mapa<select data-f="map"><option value="">Todos</option>${mapsU.map(t => `<option ${F.map === t ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></label>
        <label class="f">Jogador<select data-f="player"><option value="">Squad</option>${ROLES.map(r => `<option value="${r.id}" ${F.player === r.id ? 'selected' : ''}>${r.id} ${esc(nick(r.id) !== r.id ? nick(r.id) : '')}</option>`).join('')}</select></label>
        <label class="f">De<input class="in" type="date" data-f="from" value="${F.from}"></label><label class="f">Até<input class="in" type="date" data-f="to" value="${F.to}"></label></div></div>
      <div class="glass card" style="margin-bottom:12px"><h3>${esc(Settings.data.team || 'Equipe')} — relatório ${F.player ? 'de ' + esc(nick(F.player)) : 'do squad'}${F.event ? ' · ' + esc(F.event) : ''}${F.map ? ' · ' + esc(F.map) : ''}</h3>
        <div class="small muted">Período: ${F.from || 'início'} → ${F.to || 'hoje'} · gerado em ${fmtDate(Date.now())}</div>
        <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr));margin-top:10px">
          <div><div class="small muted">Partidas</div><div class="kpi">${ms.length}</div></div>
          <div><div class="small muted">Pontos</div><div class="kpi">${P.length ? P.reduce((a, b) => a + b, 0) : '—'}</div></div>
          <div><div class="small muted">Colocação média</div><div class="kpi">${places.length ? (places.reduce((a, b) => a + b, 0) / places.length).toFixed(1) : '—'}</div></div>
          <div><div class="small muted">Kills</div><div class="kpi">${ROLES.reduce((s, r) => s + sum('kills', r.id), 0)}</div></div>
          <div><div class="small muted">Booyahs</div><div class="kpi">${places.filter(p => p === 1).length}</div></div></div></div>
      <div class="glass card" style="margin-bottom:12px"><h3>Por jogador</h3><div style="overflow:auto"><table><tr><th>Jogador</th><th>Kills</th><th>Assist.</th><th>Dano</th><th>Erros (VOD)</th><th>Acertos (VOD)</th><th>Objetivos de melhoria</th></tr>
        ${players.map(r => `<tr><td><b>${r.id}</b> ${esc(nick(r.id) !== r.id ? nick(r.id) : '')}</td><td>${sum('kills', r.id)}</td><td>${has('assists', r.id) ? sum('assists', r.id) : '—'}</td><td>${has('damage', r.id) ? sum('damage', r.id) : '—'}</td>
          <td style="color:var(--red)">${ann(r.id, 'erro')}</td><td style="color:var(--green)">${ann(r.id, 'acerto')}</td><td><textarea data-goal="${r.id}" style="min-height:40px">${esc(goals[r.id] || '')}</textarea></td></tr>`).join('')}</table></div>
        <p class="small muted">Assistências e dano aparecem apenas quando registrados. Erros/acertos vêm das anotações de VOD com o mesmo evento/mapa/período.</p></div>
      <div class="glass card" style="margin-bottom:12px"><h3>Evolução entre partidas</h3>${ms.length ? `<svg viewBox="0 0 ${Math.max(300, ms.length * 46)} 150" style="width:100%;max-height:200px">${ms.map((m, i) => { const k = (F.player ? +m.kills?.[F.player] || 0 : ROLES.reduce((s, r) => s + (+m.kills?.[r.id] || 0), 0)), h = k / maxK * 100; return `<rect x="${i * 46 + 8}" y="${115 - h}" width="30" height="${h}" rx="4" fill="#00C8FF"/><text x="${i * 46 + 23}" y="${110 - h}" fill="#F5F8FF" font-size="11" text-anchor="middle">${k}</text><text x="${i * 46 + 23}" y="132" fill="#8EA3BF" font-size="10" text-anchor="middle">#${m.placement || '?'}</text><text x="${i * 46 + 23}" y="146" fill="#8EA3BF" font-size="9" text-anchor="middle">${new Date(m.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}</text>`; }).join('')}</svg><div class="small muted">Barras = kills; abaixo, colocação e data.</div>` : '<div class="empty small">Sem partidas no filtro.</div>'}</div>
      <div class="glass card"><h3>Partidas</h3><div style="overflow:auto"><table><tr><th>Data</th><th>Tipo</th><th>Evento</th><th>Mapa</th><th>Col.</th><th>Kills</th><th>Pontos</th><th class="noprint"></th></tr>
        ${ms.slice().reverse().map(m => `<tr><td>${new Date(m.date).toLocaleDateString('pt-BR')}</td><td>${m.type}</td><td>${esc(m.event)}</td><td>${esc(m.map)}</td><td>${m.placement || '—'}</td><td>${ROLES.reduce((s, r) => s + (+m.kills?.[r.id] || 0), 0)}</td><td>${pts(m) ?? '—'}</td>
        <td class="noprint"><button class="btn sm" data-em="${m.id}">Editar</button></td></tr>`).join('')}</table></div></div>`;
    $$('[data-f]', el).forEach(i => i.onchange = () => { F[i.dataset.f] = i.value; this.render(); });
    $$('[data-goal]', el).forEach(t => t.onchange = async () => { goals[t.dataset.goal] = t.value; await DB.kv('goals', goals); });
    $('#rpNew').onclick = () => this.editMatch({ id: uid(), date: Date.now(), type: 'X-Treino', event: '', map: '', placement: '', kills: {}, damage: {}, assists: {}, notes: '', model: models[0]?.id || '' }, models, true);
    $$('[data-em]', el).forEach(b => b.onclick = () => this.editMatch(all.find(m => m.id === b.dataset.em), models));
    $('#rpModels').onclick = () => this.editModels(models);
    $('#rpPdf').onclick = () => { try { window.print(); } catch (e) { toast('Impressão indisponível neste navegador.', true); } };
    $('#rpCsv').onclick = () => { const rows = [['data', 'tipo', 'evento', 'mapa', 'colocacao', 'pontos', ...ROLES.flatMap(r => [r.id + '_kills', r.id + '_assist', r.id + '_dano'])], ...ms.map(m => [new Date(m.date).toLocaleDateString('pt-BR'), m.type, m.event, m.map, m.placement, pts(m) ?? '', ...ROLES.flatMap(r => [m.kills?.[r.id] ?? '', m.assists?.[r.id] ?? '', m.damage?.[r.id] ?? ''])])]; download(new Blob(['﻿' + rows.map(r => r.map(x => `"${String(x).replace(/"/g, '""')}"`).join(';')).join('\n')], { type: 'text/csv' }), 'relatorio.csv'); };
  },
  editMatch(m, models, isNew) {
    const n = (k, r) => `<input class="in" type="number" min="0" data-m="${k}.${r}" value="${m[k]?.[r] ?? ''}" style="width:70px">`;
    Modal.open(`<h3>${isNew ? 'Nova partida' : 'Editar partida'}</h3><div class="grid g2" style="grid-template-columns:1fr 1fr">
      <label class="f">Data<input class="in" type="date" id="mD" value="${new Date(m.date - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10)}"></label>
      <label class="f">Tipo<select id="mT">${MATCH_TYPES.map(t => `<option ${m.type === t ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
      <label class="f">Campeonato / evento<input class="in" id="mE" value="${esc(m.event)}"></label><label class="f">Mapa<input class="in" id="mM" list="mML" value="${esc(m.map)}"><datalist id="mML">${Maps.list.map(x => `<option value="${esc(x.name)}">`).join('')}</datalist></label>
      <label class="f">Colocação<input class="in" type="number" min="1" id="mP" value="${m.placement}"></label>
      <label class="f">Modelo de pontuação<select id="mMd"><option value="">—</option>${models.map(x => `<option value="${x.id}" ${m.model === x.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label></div>
      <table style="margin-top:8px"><tr><th></th><th>Kills</th><th>Assist.</th><th>Dano</th></tr>${ROLES.map(r => `<tr><td>${r.id}</td><td>${n('kills', r.id)}</td><td>${n('assists', r.id)}</td><td>${n('damage', r.id)}</td></tr>`).join('')}</table>
      <label class="f" style="margin-top:8px">Observações<textarea id="mN">${esc(m.notes)}</textarea></label>
      <div class="row" style="margin-top:12px">${isNew ? '' : '<button class="btn red" id="mDel">Excluir</button>'}<span class="sp"></span><button class="btn" data-x>Cancelar</button><button class="btn pri" data-ok>Salvar</button></div>`, b => {
      b.querySelector('[data-x]').onclick = () => Modal.close();
      b.querySelector('[data-ok]').onclick = async () => {
        m.date = +new Date($('#mD').value + 'T12:00') || Date.now(); m.type = $('#mT').value; m.event = $('#mE').value.trim(); m.map = $('#mM').value.trim(); m.placement = $('#mP').value; m.model = $('#mMd').value; m.notes = $('#mN').value;
        $$('[data-m]', b).forEach(i => { const [k, r] = i.dataset.m.split('.'); (m[k] = m[k] || {})[r] = i.value === '' ? '' : +i.value; });
        await DB.put('matches', m); Modal.close(); this.render();
      };
      const d = $('#mDel'); if (d) d.onclick = async () => { Modal.close(); if (await Modal.confirm('Excluir esta partida dos relatórios?', 'Excluir', true)) { await DB.del('matches', m.id); this.render(); } };
    });
  },
  editModels(models) {
    const draw = () => Modal.open(`<h3>Modelos de pontuação</h3><p class="small muted">Defina os pontos por colocação e por abate de cada campeonato. Nenhum valor é assumido.</p>
      ${models.map(md => `<div class="pcard"><div class="row"><input class="in" data-mn="${md.id}" value="${esc(md.name)}" style="flex:1"><label class="small">Pts/kill <input class="in" type="number" data-mk="${md.id}" value="${md.kill}" style="width:70px"></label><button class="btn sm" data-md="${md.id}">✕</button></div>
        <div class="small muted" style="margin-top:6px">Pontos por colocação (1º ao ${md.place.length}º):</div><div class="row">${md.place.map((v, i) => `<input class="in" type="number" data-mp="${md.id}|${i}" value="${v}" title="${i + 1}º" style="width:54px">`).join('')}
        <button class="btn sm" data-ma="${md.id}">+</button><button class="btn sm" data-mr="${md.id}">−</button></div></div>`).join('')}
      <div class="row" style="margin-top:10px"><button class="btn" id="mdNew">+ Modelo</button><span class="sp"></span><button class="btn pri" data-ok>Salvar</button></div>`, b => {
      const g = id => models.find(x => x.id === id);
      $$('[data-mn]', b).forEach(i => i.onchange = () => g(i.dataset.mn).name = i.value); $$('[data-mk]', b).forEach(i => i.onchange = () => g(i.dataset.mk).kill = +i.value || 0);
      $$('[data-mp]', b).forEach(i => i.onchange = () => { const [id, k] = i.dataset.mp.split('|'); g(id).place[+k] = +i.value || 0; });
      $$('[data-ma]', b).forEach(x => x.onclick = () => { g(x.dataset.ma).place.push(0); draw(); }); $$('[data-mr]', b).forEach(x => x.onclick = () => { g(x.dataset.mr).place.pop(); draw(); });
      $$('[data-md]', b).forEach(x => x.onclick = () => { models.splice(models.indexOf(g(x.dataset.md)), 1); draw(); });
      $('#mdNew').onclick = () => { models.push({ id: uid(), name: 'Novo campeonato', kill: 0, place: Array(12).fill(0) }); draw(); };
      b.querySelector('[data-ok]').onclick = async () => { await DB.kv('scoring', models); Modal.close(); this.render(); toast('Modelos salvos.'); };
    });
    draw();
  }
};
/* ==========================================================
   CONFIGURAÇÕES, BACKUP E PWA
   ========================================================== */
const blobToB64 = b => new Promise(r => { const f = new FileReader(); f.onload = () => r(f.result); f.readAsDataURL(b); });
const b64ToBlob = async d => { // decodifica sem executar nada; só aceita mídia
  const m = /^data:([\w.+-]+\/[\w.+-]+)(;[\w=.+-]+)*;base64,/.exec(d); if (!m || !/^(image|video|audio)\//.test(m[1])) throw new Error('mídia inválida');
  const bin = atob(d.slice(m[0].length)), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new Blob([u], { type: m[1] });
};
let installEvt = null; window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEvt = e; if (currentView === 'config') Views.config.render(); });
Views.config = {
  async render() {
    const el = $('#v-config'), S = Settings.data, ro = await DB.kv('roster') || {};
    let est = null; try { est = await navigator.storage?.estimate(); } catch { } let pers = null; try { pers = await navigator.storage?.persisted(); } catch { }
    const standalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone;
    el.innerHTML = `<h2>Configurações</h2><div class="grid g2">
      <div class="glass card"><h3>Equipe e jogo</h3><div class="grid">
        <label class="f">Nome da equipe<input class="in" data-s="team" value="${esc(S.team)}"></label>
        <label class="f">Versão atual do Free Fire (usada em projetos e bibliotecas)<input class="in" data-s="gameVersion" value="${esc(S.gameVersion)}" placeholder="ex.: OB-xx / temporada"></label>
        <div class="small muted">Nicks do squad</div>${ROLES.map(r => `<label class="f">${r.id} · ${r.role}<input class="in" data-ro="${r.id}" value="${esc(ro[r.id] || '')}"></label>`).join('')}</div></div>
      <div class="glass card"><h3>Deslocamento (calculadora de tempo)</h3><div class="grid">
        <label class="f">Escala (metros por pixel do mapa) — calibre com a ferramenta Medir<input class="in" type="number" step="0.001" min="0" data-s="metersPerUnit" value="${S.metersPerUnit || ''}"></label>
        <label class="f">Velocidade a pé medida em treino (m/s)<input class="in" type="number" step="0.1" min="0" data-s="speedFoot" value="${S.speedFoot || ''}"></label>
        <label class="f">Velocidade de veículo medida em treino (m/s)<input class="in" type="number" step="0.1" min="0" data-s="speedVehicle" value="${S.speedVehicle || ''}"></label>
        <p class="small muted">Sem valores padrão: os tempos só aparecem após você informar escala e velocidades medidas.</p></div>
        <h3 style="margin-top:12px">Gravação</h3><div class="grid g2" style="grid-template-columns:1fr 1fr">
        <label class="f">Qualidade<select data-s="recQuality">${['alta', 'media', 'baixa'].map(q => `<option ${S.recQuality === q ? 'selected' : ''}>${q}</option>`).join('')}</select></label>
        <label class="f">Quadros/s<select data-s="recFps">${[24, 30, 60].map(q => `<option ${+S.recFps === q ? 'selected' : ''}>${q}</option>`).join('')}</select></label></div></div>
      <div class="glass card"><h3>Armazenamento e backup</h3>
        <p class="small">${est ? `Uso: <b>${fmtBytes(est.usage || 0)}</b> de ~${fmtBytes(est.quota || 0)} disponíveis.` : 'Estimativa de espaço indisponível.'} Armazenamento persistente: <b>${pers ? 'sim' : 'não'}</b>.</p>
        <div class="row"><button class="btn" id="cfPers" ${pers ? 'disabled' : ''}>Pedir armazenamento persistente</button></div>
        <div class="row" style="margin-top:10px"><button class="btn pri" id="cfBk">Exportar backup</button><label class="small"><input type="checkbox" id="cfBkM"> incluir vídeos e imagens</label></div>
        <div class="row" style="margin-top:8px"><button class="btn" id="cfRs">Restaurar backup…</button><button class="btn" id="cfUndo">Desfazer última importação</button></div>
        <p class="small muted">O backup é validado e mostrado antes de qualquer gravação; nada é apagado nem sobrescrito sem confirmação.</p>
        <h3 style="margin-top:12px">Preferências</h3>
        <label class="small" style="display:block"><input type="checkbox" data-sb="autoSave" ${S.autoSave ? 'checked' : ''}> Salvamento automático do projeto (a cada 30 s com alterações)</label>
        <label class="small" style="display:block"><input type="checkbox" data-sb="strictVersion" ${S.strictVersion ? 'checked' : ''}> Modo estrito de versão nas combinações de personagens</label>
        <label class="f" style="margin-top:6px">Resolução máxima das imagens de mapa (px)<select data-s="maxMapPx">${[2048, 4096, 8192].map(v => `<option ${+S.maxMapPx === v ? 'selected' : ''}>${v}</option>`).join('')}</select></label></div>
      <div class="glass card" id="cloudBox"></div>
      <div class="glass card"><h3>Aplicativo</h3>
        <p class="small">Versão ${APP_VERSION} · ${standalone ? 'instalado como app' : 'rodando no navegador'} · Service worker: <b>${'serviceWorker' in navigator ? (navigator.serviceWorker.controller ? 'ativo (offline)' : 'registrando / indisponível') : 'não suportado'}</b></p>
        ${installEvt ? '<button class="btn org" id="cfInst">Instalar aplicativo</button>' : `<p class="small muted">${standalone ? '' : 'Para instalar: no Android/Chrome use "Instalar app" no menu; no iPhone, Compartilhar → "Adicionar à Tela de Início".'}</p>`}
</div></div>`;
    $$('[data-s]', el).forEach(i => i.onchange = async () => { S[i.dataset.s] = i.type === 'number' || ['recFps', 'maxMapPx'].includes(i.dataset.s) ? (+i.value || 0) : i.value.slice(0, 200); await Settings.save(); toast('Configuração salva.'); });
    $$('[data-sb]', el).forEach(i => i.onchange = async () => { S[i.dataset.sb] = i.checked; await Settings.save(); toast('Configuração salva.'); });
    $('#cfUndo').onclick = () => RestorePoint.undo();
    Cloud.renderSettings($('#cloudBox'));
    $$('[data-ro]', el).forEach(i => i.onchange = async () => { ro[i.dataset.ro] = i.value; await DB.kv('roster', ro); });
    $('#cfPers').onclick = async () => { const ok = await navigator.storage?.persist?.(); toast(ok ? 'Armazenamento persistente concedido.' : 'O navegador não concedeu (instale o app para aumentar a chance).'); this.render(); };
    $('#cfBk').onclick = () => this.backup($('#cfBkM').checked); $('#cfRs').onclick = () => this.restore();
    const ins = $('#cfInst'); if (ins) ins.onclick = async () => { installEvt.prompt(); await installEvt.userChoice; installEvt = null; this.render(); };
  },
  async backup(withMedia) {
    toast('Gerando backup…'); const out = { app: 'analista-tatico-pro', type: 'backup', version: APP_VERSION, format: BACKUP_FORMAT, date: Date.now(), withMedia, stores: {} };
    for (const s of DB.stores) {
      if (s === 'sync') continue; // metadados de sincronização são do aparelho
      let rows = await DB.all(s);
      if (s === 'kv') rows = rows.filter(r => !['autosave', 'restorePoint', 'fbconfig', 'outbox'].includes(r.id));
      if (s === 'media') { rows = rows.filter(r => r.kind !== 'recpart'); if (!withMedia) rows = []; else rows = await Promise.all(rows.map(async r => ({ ...r, blob: await blobToB64(r.blob) }))); }
      out.stores[s] = rows;
    }
    out.counts = Object.fromEntries(Object.entries(out.stores).map(([k, v]) => [k, v.length]));
    download(new Blob([JSON.stringify(out)], { type: 'application/json' }), `backup_analista_${new Date().toISOString().slice(0, 10)}.json`); toast('Backup exportado.');
  },
  async restore() {
    const f = await pickFile('.json,application/json'); if (!f) return;
    const LIMIT = 600e6;
    let j, plan = {}, invalid = [];
    try {
      if (f.size > LIMIT) throw new Error(`arquivo de ${fmtBytes(f.size)} excede o limite de ${fmtBytes(LIMIT)} — gere um backup sem vídeos`);
      j = safeParse(await f.text());
      if (!j || j.app !== 'analista-tatico-pro' || j.type !== 'backup' || typeof j.stores !== 'object') throw new Error('não é um backup deste app');
      const fmt = j.format || 1; if (fmt > BACKUP_FORMAT) throw new Error(`backup no formato ${fmt}, mais novo que este app (${BACKUP_FORMAT}) — atualize o app`);
      for (const [s, rows] of Object.entries(j.stores)) {
        if (!SCHEMA[s]) { invalid.push(`coleção desconhecida ignorada: ${s}`); continue; }
        if (!Array.isArray(rows)) { invalid.push(`${s}: não é uma lista`); continue; }
        const existing = new Map((await DB.all(s)).map(r => [r.id, r])); plan[s] = { add: [], change: [], same: 0 };
        for (const raw of rows) {
          let r; try { r = s === 'media' ? { ...sanitize({ ...raw, blob: null }), blob: raw.blob } : sanitize(raw); } catch (e) { invalid.push(`${s}: ${e.message}`); continue; }
          const err = validateRecord(s, r); if (err) { invalid.push(`${s} ${String(raw?.id || '?').slice(0, 40)}: ${err}`); continue; }
          if (s === 'kv' && ['autosave', 'restorePoint', 'fbconfig', 'outbox'].includes(r.id)) continue;
          const ex = existing.get(r.id);
          if (!ex) plan[s].add.push(r); else if (s === 'media' || JSON.stringify(ex) === JSON.stringify(r)) plan[s].same++; else plan[s].change.push(r);
        }
      }
    } catch (e) { return toast('Backup inválido: ' + e.message, true); }
    const tot = k => Object.values(plan).reduce((t, p) => t + (k === 'same' ? p.same : p[k].length), 0), NAMES = { projects: 'Projetos', maps: 'Mapas', media: 'Mídias', chars: 'Personagens', weapons: 'Armas', vods: 'Partidas (VOD)', matches: 'Partidas (relatório)', kv: 'Configurações e listas' };
    Modal.open(`<h3>Pré-visualização do backup</h3><p class="small muted">Gerado em ${fmtDate(j.date)} · app ${esc(j.version || '?')} · formato ${j.format || 1}${j.withMedia ? ' · com mídias' : ''}</p>
      <table><tr><th>Coleção</th><th>Novos</th><th>Diferentes</th><th>Idênticos</th></tr>${Object.entries(plan).map(([k, p]) => `<tr><td>${NAMES[k] || k}</td><td>${p.add.length}</td><td>${p.change.length}</td><td>${p.same}</td></tr>`).join('')}</table>
      ${invalid.length ? `<p class="small" style="color:var(--orange)">${invalid.length} registro(s) inválido(s) serão ignorados:<br>${invalid.slice(0, 8).map(esc).join('<br>')}${invalid.length > 8 ? '<br>…' : ''}</p>` : '<p class="small" style="color:var(--green)">Estrutura validada.</p>'}
      <p class="small muted">Nada é apagado. Os dados substituídos ficam guardados num ponto de restauração (Configurações → Desfazer última importação).</p>
      <div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn" data-x>Cancelar</button><button class="btn" id="rsNew" ${tot('add') ? '' : 'disabled'}>Importar só novos (${tot('add')})</button><button class="btn pri" id="rsAll" ${tot('add') + tot('change') ? '' : 'disabled'}>Novos + substituir diferentes (${tot('add') + tot('change')})</button></div>`, b => {
      b.querySelector('[data-x]').onclick = () => Modal.close();
      const run = async replace => {
        Modal.close(); toast('Restaurando…'); const before = [], added = [];
        for (const [s, p] of Object.entries(plan)) { for (const r of p.add) added.push({ store: s, id: r.id }); if (replace) for (const r of p.change) before.push({ store: s, rec: await DB.get(s, r.id) }); }
        await RestorePoint.save(null, before, added, 'Restauração de backup de ' + fmtDate(j.date));
        let n = 0;
        try { for (const [s, p] of Object.entries(plan)) for (const r of [...p.add, ...(replace ? p.change : [])]) { if (s === 'media' && typeof r.blob === 'string') r.blob = await b64ToBlob(r.blob); await DB.put(s, r); n++; } }
        catch (e) { toast(`Restauração interrompida após ${n} registros: ${e.message}. Use "Desfazer última importação" se necessário.`, true); }
        await Settings.load(); await Maps.load(); toast(n + ' registro(s) restaurado(s).'); go('inicio');
      };
      $('#rsNew').onclick = () => run(false);
      $('#rsAll').onclick = async () => { if (tot('change') && !await Modal.confirm(`Substituir ${tot('change')} registro(s) existentes pelos do backup?`, 'Substituir', true)) return; run(true); };
    });
  }
};
/* ---------- Ponto de restauração (desfazer importações) ---------- */
const RestorePoint = {
  async save(store, recs, added = [], label) {
    const before = store ? recs.map(rec => ({ store, rec })) : recs;
    await DB.put('kv', { id: 'restorePoint', v: { date: Date.now(), label: label || 'Importação de catálogo', before: before.filter(x => x.rec), added } }, { silent: true });
  },
  async undo() {
    const rp = await DB.kv('restorePoint'); if (!rp) return toast('Não há importação para desfazer.');
    if (!await Modal.confirm(`Desfazer "${rp.label}" (${fmtDate(rp.date)})? ${rp.before.length} registro(s) voltarão ao estado anterior e ${rp.added.length} registro(s) adicionado(s) serão removidos.`, 'Desfazer', true)) return;
    for (const a of rp.added) await DB.del(a.store, a.id); for (const b of rp.before) await DB.put(b.store, b.rec);
    await DB.del('kv', 'restorePoint', { silent: true }); await Settings.load(); await Maps.load(); toast('Importação desfeita.'); go('inicio');
  }
};
/* ==========================================================
   INÍCIO
   ========================================================== */
Views.inicio = {
  async render() {
    const el = $('#v-inicio'), ps = (await DB.all('projects')).filter(p => !p.archived).sort((a, b) => b.updated - a.updated), recs = await Media.list('rec'), ms = await DB.all('matches'), vods = await DB.all('vods');
    const ready = Maps.list.filter(m => Maps.status(m) === 'ok').length;
    el.innerHTML = `<div class="glass hero" style="margin-bottom:14px"><div class="small" style="color:var(--orange);letter-spacing:.2em">ESTÚDIO DE ANÁLISE COMPETITIVA</div>
      <h1 style="font-size:28px;margin:6px 0">ANALISTA TÁTICO PRO</h1><p class="muted" style="max-width:560px">Mapa tático, squad animado, gravação com voz e câmera, edição, VOD, bibliotecas e relatórios — em um só lugar.</p>
      <div class="row"><button class="btn pri" id="hStudio">Abrir Estúdio Tático</button><button class="btn" id="hRec">● Gravar análise</button><button class="btn" id="hVod">Analisar partida</button></div></div>
      ${ready ? '' : `<div class="glass card" style="margin-bottom:14px;border-color:rgba(255,138,48,.4)"><b style="color:var(--orange)">Pendente:</b> nenhum mapa tem imagem importada ainda. <button class="btn sm" id="hMaps">Importar mapas</button></div>`}
      <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));margin-bottom:14px">
        ${[['Projetos', ps.length], ['Mapas prontos', ready + '/' + Maps.list.length], ['Gravações', recs.length], ['Partidas (VOD)', vods.length], ['Partidas registradas', ms.length]].map(([l, v]) => `<div class="glass card"><div class="small muted">${l}</div><div class="kpi">${v}</div></div>`).join('')}</div>
      <div class="glass card"><h3>Projetos recentes</h3>${ps.slice(0, 6).map(p => `<div class="row pcard"><div><b>${esc(p.name)}</b><div class="small muted">${esc(Maps.get(p.mapId)?.name || '')} · ${fmtDate(p.updated)}</div></div><span class="sp"></span><button class="btn sm" data-op="${p.id}">Abrir</button></div>`).join('') || '<div class="empty small">Nenhum projeto salvo.</div>'}</div>`;
    $('#hStudio').onclick = () => go('estudio'); $('#hRec').onclick = () => { go('estudio'); $('#bRecOpen').click(); }; $('#hVod').onclick = () => go('vod');
    const hm = $('#hMaps'); if (hm) hm.onclick = () => go('mapas');
    $$('[data-op]', el).forEach(b => b.onclick = async () => { await Studio.loadProject(ps.find(p => p.id === b.dataset.op)); go('estudio'); });
  }
};
/* ==========================================================
   INICIALIZAÇÃO
   ========================================================== */
(async function boot() {
  const shareId = new URLSearchParams(location.search).get('share');
  buildNav();
  try { await DB.open(); } catch (e) { document.body.insertAdjacentHTML('afterbegin', `<div style="position:fixed;inset:0;z-index:99;background:#07111F;padding:30px">Não foi possível abrir o banco local: ${esc(e.message)}. Verifique se o navegador não está em modo privado.</div>`); return; }
  await Settings.load(); await Maps.load(); await seedLibraries(); await VEditor.load();
  Studio.init(); Recorder.bindCamWin();
  if (shareId) return Cloud.openShare(shareId); // visitante de link público: modo somente leitura
  const last = await DB.kv('lastProject'), lp = last && await DB.get('projects', last);
  if (lp) await Studio.loadProject(lp); else await Studio.setMap('bermuda');
  $('#sideInfo').textContent = 'v' + APP_VERSION + (Settings.data.team ? ' · ' + Settings.data.team : '');
  go(location.hash.slice(1) || 'inicio');
  setInterval(() => {
    if (!Studio.dirtyProject || Recorder.active || Studio.readOnly) return;
    if (Settings.data.autoSave) Studio.saveProject(true, true).catch(e => toast('Salvamento automático falhou: ' + e.message, true));
    else DB.put('kv', { id: 'autosave', v: deep(Studio.p), date: Date.now() }, { silent: true }).catch(() => { }); // rascunho de recuperação
  }, 30000);
  const as = await DB.get('kv', 'autosave');
  if (as && as.v && (!lp || as.v.id !== lp.id || as.date > lp.updated + 1000) && as.v.objects?.length) {
    if (await Modal.confirm(`Foi encontrado um rascunho não salvo ("${as.v.name}", ${fmtDate(as.date)}). Recuperar?`, 'Recuperar')) { await Studio.loadProject(as.v); Studio.dirtyProject = true; go('estudio'); }
    else await DB.del('kv', 'autosave', { silent: true });
  }
  await Recorder.recoverOrphans();
  Cloud.boot();
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('service-worker.js').catch(e => console.warn('SW:', e));
})();
