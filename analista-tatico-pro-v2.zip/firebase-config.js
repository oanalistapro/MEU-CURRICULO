// ANALISTA TÁTICO PRO — configuração pública do Firebase (app Web).
// Console do Firebase → Configurações do projeto → Seus apps → Web → firebaseConfig.
// Estes valores NÃO são segredos; a proteção dos dados vem de firestore.rules e storage.rules.
// Preencha para que login, sincronização e links públicos funcionem em qualquer aparelho.
window.FIREBASE_CONFIG = window.FIREBASE_CONFIG || null;
/* Exemplo:
window.FIREBASE_CONFIG = {
  apiKey: "AIza...",
  authDomain: "seu-projeto.firebaseapp.com",
  projectId: "seu-projeto",
  storageBucket: "seu-projeto.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:xxxxxxxx"
};
*/
